import os
import cv2
import math
import h5py
import torch
import random
import numpy as np
from collections import Counter
from isutils.LDCmodelB4 import LDC

from PIL import Image, ImageStat
from torch.utils import data
from torchvision.io import read_image
from torch.utils.data import DataLoader
from torchvision import transforms, datasets
from torchvision.io.image import ImageReadMode
# os.environ["CUDA_VISIBLE_DEVICES"] = "1"

# for one ablation test
    


def get_additional_channel(img_rgb, add_edge_method = "LDC", add_edge_weight = 0.5, random_add_edge=True, canny_t1=15):
    # we can do this after data augmentation directly
    if add_edge_method == "canny":
        # Image.open is RGB, cv2 BGR
        img_gray = cv2.cvtColor(img_rgb, cv2.COLOR_RGB2GRAY)
        canny_edge = cv2.Canny(np.array(img_gray).astype(np.uint8), canny_t1, canny_t1*3)
        # print(Counter(canny_edge.reshape(-1)))
        canny_edge = (canny_edge.reshape(img_rgb.shape[0], img_rgb.shape[1], 1)).astype(np.float32) 
        
    elif add_edge_method == "LDC":
        
        model = LDC()
        model.cuda()
        model.load_state_dict(torch.load("../ldc_cp/BIPED/16/16_model.pth"))
        # print(img_rgb.shape)
        img_trans = torch.from_numpy(np.transpose(np.array(img_rgb), axes=(2,0,1))).float()
        edge = model(img_trans.unsqueeze(0).cuda())  
        # print(edge[1].shape)                               
    
    # random add edge
    # op1 random weight, random canny threhold
    # op2 random add edge
    # give this edge map a random binary mask
    for i in range(len(edge)):
     
        edge[i] = torch.sigmoid(edge[i]).detach().cpu().squeeze(0).squeeze(0).numpy()
    edge = np.array(edge) # * add_edge_weight # / 255.
    # edge_tensor =  torch.from_numpy(np.transpose(edge, axes=(2,0,1))).float()

    return edge
    

def get_ldc_ed(path="../ldc_cp/BIPED/16/16_model.pth", gpu=False):
    model = LDC()
    model.load_state_dict(torch.load(path))
    model.cuda()
    # model.load_state_dict(torch.load(path, map_location=torch.device('cpu')))
    return model


def ldc_pre_img(img_crop, ldc_model):
    mean_pixel = [103.939,116.779,123.68, 137.86]
    # [103.939,116.779,123.68,137.86] [104.00699, 116.66877, 122.67892]
    # BRIND mean = [104.007, 116.669, 122.679, 137.86]
    # BIPED mean_bgr processed [160.913,160.275,162.239,137.86]
    img_crop = np.array(img_crop).astype(np.float)
    img_crop -= mean_pixel[0:3]
    with torch.no_grad():
        img_trans = torch.from_numpy(np.transpose(np.array(img_crop), axes=(2,0,1))).float()
        ldc_res = ldc_model(img_trans.unsqueeze(0).cuda())  
    return torch.sigmoid(ldc_res[-1])
    

# root_img_path = "/home/xuli/researchfiler/occdata/soccdsf/"
root_img_path = "occdata/PIOD/Aug_JPEGImages/"
store_path = "occdata/ldcpiod/" 
dir_list = os.listdir(root_img_path)
ldc_ed = get_ldc_ed()
# shape_list_vis = list()

for item in dir_list: # range(15076):
    c_path = root_img_path + item

    c_img = cv2.imread(c_path, cv2.IMREAD_UNCHANGED)
    old_shape = c_img.shape
    # shape_list_vis.append(old_shape)
    # continue
    # print(c_img.shape)
    
    # follow the resize method of the original LDC
    # 416 512  / 512 512 / 480, 640
    w_resize = 416 #512
    h_resize = 512
    # cv2.imwrite("./original_img.png", c_img)
    if c_img.shape[0] < c_img.shape[1]:
        c_img_resized = cv2.resize(c_img, (h_resize, w_resize))  #
    else:
        c_img_resized = cv2.resize(c_img, (w_resize, h_resize))  #


    ldc_res = ldc_pre_img(c_img_resized, ldc_ed)
    ldc_res = ldc_res.squeeze().detach().cpu().numpy()
    # cv2.imwrite("./ldc_resized.png", (1-ldc_res)*255)
    ldc_res_r = cv2.resize(ldc_res, (old_shape[1], old_shape[0]))
    # cv2.imwrite("./ldc_res.png", (1-ldc_res_r)*255)

    # print(name33)
    img_save_path = item # item.replace(".jpg, "_ldc.png")            
    if not os.path.exists(store_path):
        os.makedirs(store_path)
    cv2.imwrite(store_path+img_save_path, (1-ldc_res_r)*255) # ldc_res_r)

# print(Counter(shape_list_vis))            

