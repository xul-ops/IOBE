function nmstres = MatlabEdgeNMST(epres, threshold)
    % add path here
    addpath(genpath('./evaTools/doobscripts'));
    % res_list = {}

    % parfor
    % for ires = 1:length(resRootDir)

    % read imgs
    % edge_prob = cell2mat(epres) % resRootDir[ires]
    % epres = cellfun(@imread, epres, 'UniformOutput', false)
    % [h, w] = size(epres)
    % edge_prob = zeros(h, w)
    % for i = 1:h
    %    for j = 1:w
    %         element = epres{i, j}
    %        edge_prob(i,j) = str2double(element)
    %    end
    % end
    edge_prob = imread(epres);
    % class(edge_prob)  fprintf()
    edge_prob = double(edge_prob)/255;
    edge_prob_thin = edge_nms(edge_prob, 0);

    binaryMask = edge_prob_thin >= threshold;
    nmstres = edge_prob_thin .* binaryMask;
% end

end


