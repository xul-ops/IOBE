import cv2
import sys
import numpy as np
from collections import Counter

from isutils.edgeEvalPy.nms_process import nms_process_one_image
# from edgeEvalPy.nms_process import nms_process_one_image
# from .edgeEvalPy import nms_process_one_image

import os
import imageio
import torch
# import matlab.engine
_CURR_DIR = os.path.dirname(os.path.realpath(__file__))


def run_cmd(cmd):
    print("cmd: %s" % cmd)
    os.system(cmd)


def get_matlab_eng(works_num=0):
    eng = matlab.engine.start_matlab()
    # eng.myCluster = eng.parcluster('local')
    # eng.delete(eng.myCluster.Jobs)
    eng.addpath(eng.genpath(_CURR_DIR))
    if works_num == 0:
        eng.parpool('local')
    else:
        eng.parpool('local', works_num)
    return eng


def mb_nmst(epres, threshold, matlab_eng=None):
    if matlab_eng is None:
        eng = get_matlab_eng()
    else:
        eng = matlab_eng
    # print(type(epres.tolist()), type(epres.tolist()[0]))
    # list(pred_list[i].numpy())
    epres_s = epres.type(torch.uint8) * 255
    # cv2.imwrite("./data/tmp/ob.png", epres)
    imageio.imwrite("./data/tmp/ob.png", epres_s)
    nms_res = eng.mbnms("./data/tmp/ob.png", threshold)

    if matlab_eng is None:
        eng.quit()

    return nms_res


def ob_nms_t(image_path, threshold, save=False, save_path="./pynms.png"):

    img_ob = cv2.imread(image_path, cv2.IMREAD_UNCHANGED)
    img_ob = (255 - np.array(img_ob)) / 255
    obnms = nms_process_one_image(img_ob, None, False)
    if save:
        cv2.imwrite(save_path, obnms)

    # obnms_bmap = (obnms[:, :] < (1-threshold)*255) * 1  # (255 - image2[i, j]) / 255 >=  threshold
    # return obnms * obnms_bmap

    obnmst = np.zeros((obnms.shape[0], obnms.shape[1]))
    for i in range(obnms.shape[0]):
        for j in range(obnms.shape[1]):
            if  obnms[i, j] / 255.0 >= threshold:
                obnmst[i,j] = 255
    return obnms, obnmst


def ob_nmst(img_ob, threshold):

    # img_ob = (255 - np.array(img_ob)) / 255
    obnms = nms_process_one_image(np.array(img_ob).astype(np.float64), None, False) / 255
    obnms_bmap = (obnms >= threshold) * 1 
    
    return obnms * obnms_bmap
    # obnmst = np.zeros((obnms.shape[0], obnms.shape[1]))
    # for i in range(obnms.shape[0]):
    #     for j in range(obnms.shape[1]):
    #         if  obnms[i, j] / 255.0 >= threshold:
    #             obnmst[i,j] = 255
    # return obnmst


def get_p_nms(result_dir, threshold):
    nms_list = list()
    for item in result_dir:
        obnmst = ob_nmst(item, threshold)
        nms_list.append(obnmst)
    return nms_list
    

def get_batch_pr(pred_list, gt_list,  threshold, match_radius=4):
    nms_list = list()
    for i in range(pred_list.shape[0]):
        obnmst = ob_nmst(pred_list[i], threshold)
        c_pr_map = get_pr_img(gt_list[i].reshape(obnmst.shape[0], obnmst.shape[1],1), obnmst, is_nmsed=True, radius=match_radius)
        nms_list.append(c_pr_map)
    return nms_list


def get_pr_img(image1, image2, is_nmsed=False, p_threhold=0.7, use_pynms=True, radius=4):
    # assert 
    # image1 : gt
    # image2 : edge pred

    # image2 = 1-np.array(image2)/255
    # nms_map = (image2[:, :] >= 0.9)*1
    # image2 = (image2*nms_map).reshape(image1.shape[0], image1.shape[1], 1)#.astype(np.int)
    # # image2 = edgep_nms(image2)
    # image2 = cv2.Canny(image2, threshold1=110, threshold2=220)
    if not is_nmsed and use_pynms:
        obnms, image2 = ob_nms_t(img_original_projection, p_threhold)
    # img1_bmap = ((np.array(image1[:, :, 0]) > 0)*1).reshape(image1.shape[0], image1.shape[1], 1)
    # print(image1.shape)
    img1_bmap = ((np.array(image1[:, :, 0]) > 0)*1).reshape(image1.shape[0], image1.shape[1], 1)
    # img2_bmap = ((np.array(image2[:, :])/255.0 > p_threhold)*1).reshape(image1.shape[0], image1.shape[1], 1)
    img2_bmap = ((np.array(image2[:, :]) > 0)*1).reshape(image1.shape[0], image1.shape[1], 1)
    # print(Counter(img1_bmap.reshape(-1)))
    # print(Counter(img2_bmap.reshape(-1)))

    img_output = np.zeros((image1.shape[0], image1.shape[1], 3))

    for i in range(image1.shape[0]):
        for j in range(image1.shape[1]):
            if image1[i, j, :].tolist() != [0,0,0] or image2[i, j] != 0:
                # points_neighbors = get_point_neighbors((i, j), image1.shape)
                img1_check = np.sum(img1_bmap[i-radius:i+radius+1, j-radius:j+radius+1 ], axis=(0, 1))[0] > 0
                img2_check = np.sum(img2_bmap[i-radius:i+radius+1, j-radius:j+radius+1 ], axis=(0, 1))[0] > 0
                if img1_check and img2_check:
                    #img_output[i, j, :] = [0, 255, 0]
                    continue
                elif img1_check and not img2_check:
                    img_output[i, j, :] = [0, 0, 255]
                elif not img1_check and img2_check:
                    img_output[i, j, :] = [255, 0, 0]
                else:
                    continue
    # cv2.imwrite("./bpynmst7_r4_pr_gt.png", img_output)
    return img_output    



if __name__ == '__main__':

    # img_original_rgba = "./data/occ/00587/fOB.png"
    # image1 = cv2.imread(img_original_rgba, cv2.IMREAD_UNCHANGED)  # cv2.cvtColor(rgba, cv2.COLOR_RGBA2RGB)

    p_threhold = 0.7
    # img_original_projection = "./00002/00002_nms_t9.png"
    img_original_projection = "./data/piod_ob.png"
    image2 = cv2.imread(img_original_projection, cv2.IMREAD_UNCHANGED)
    obnms, obnmst = ob_nms_t(img_original_projection, p_threhold)
    # # print(image2.shape)
    # # print(Counter(image2.reshape(-1))) 
    
    # get_pr_img(image1, image2, False, p_threhold)
    
    
    
    # for i in range(image1.shape[0]):
    #     for j in range(image1.shape[1]):
    #         # print(image2[i, j, :])
    #         if image1[i, j, :].tolist() != [0, 0, 0]:
    #             image2[i, j, :] = [0, 0, 255] # image2[i, j, :]
    # cv2.imwrite("./gt2nmst9.png", image2)

    # img_output = np.zeros((image1.shape))
    # for i in range(image1.shape[0]):
    #     for j in range(image1.shape[1]):
    #         points_neighbors = get_point_neighbors((i, j), image1.shape)
    #         img1_check = check_neighbors_has(points_neighbors, image1, is_ep=False)
    #         img2_check = check_neighbors_has(points_neighbors, image2, is_ep=True, ep_threshold=p_threhold)
    #         if img1_check and img2_check:
    #             # img_output[i, j, :] = [0, 255, 0]
    #             continue
    #         elif img1_check and not img2_check:
    #             img_output[i, j, :] = [0, 0, 255]
    #         elif not img1_check and img2_check:
    #             img_output[i, j, :] = [255, 0, 0]
    #         else:
    #             continue    
    # cv2.imwrite("./nms_pr_gt.png", img_output)
    
    
    # for i in range(image1.shape[0]):
    #     for j in range(image1.shape[1]):
    #         if image2[i, j, :].tolist() != [0, 0, 0]:
    #             image1[i, j, :] = [0, 0, 255] # image2[i, j, :]
    # cv2.imwrite("../interior.png", image1)

