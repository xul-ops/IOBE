import cv2
import time
import random
import numpy as np
import matplotlib.pyplot as plt

# unused

def bresenham_line2(x1, y1, x2, y2):
    # Calculate differences
    dx = x2 - x1
    dy = y2 - y1
    pixel_points = list()
    
    # Determine signs
    sx = 1 if dx > 0 else -1
    sy = 1 if dy > 0 else -1
    
    # Take absolute values
    dx = abs(dx)
    dy = abs(dy)
    
    
    if dx<=3: #x2 == x1:
        c_max = max(y1, y2)
        c_min = min(y1, y2)
        for i in range(c_min,c_max+1):
            pixel_points.append((x1, i))
        pixel_points.append((x2, i))
        return pixel_points
    elif dy<=3: #: y2 == y1:
        c_max = max(x1, x2)
        c_min = min(x1, x2)
        for i in range(c_min,c_max+1):
            pixel_points.append((i, y1))
        pixel_points.append((i, y2))
        return pixel_points
    
    # Determine traversal direction
    if dx > dy:
        increment_x = True
        # p = 2 * dy - dx
        t = dx
        dx = dy
        dy = t
    else:
        increment_x = False
        # p = 2 * dx - dy
        
    Error = 2*dy - dx
    A = 2*dy
    B = 2*dy - 2*dx
    
    
    # Initialize starting point
    x = x1
    y = y1
    
    # Store the pixel points
    pixel_points = [(x, y)]
    
    # Iterate over the range from 0 to dx
    for i in range(0, dx): # dx times
        if Error < 0:
            if interchange:
                y += sy
            else:
                x += sx
            Error += A
        else:
            y += sy
            x += sx
            Error += B
                  
        # Add the current pixel point to the list
        pixel_points.append((x, y))
    pixel_points.append((x2, y2))
    if len(pixel_points) <= 2:
        print(x1, y1, x2, y2)
    return pixel_points


def calculate_slope_degrees(x1, y1, x2, y2):
    if x1 == x2:
        return None
    radians = math.atan2(y2 - y1, x2 - x1)
    degrees = math.degrees(radians)
    return degrees

def is_vertical_slope(slope, threshold=60):
    return abs(slope) >= threshold

def is_horizontal_slope(slope, threshold=30):
    return abs(slope) <= threshold


def extend_line(point, line_slope, extra_len, is_end=False):
    extend_segment = list()
    x_add = 0
    y_add = 0
    if line_slope is None or is_vertical_slope(line_slope):
        if is_end:
            y_add = 1
        else:
            y_add = -1
    elif line_slope == 0 or is_horizontal_slope(line_slope):
        if is_end:
            x_add = 1
        else:
            x_add = -1   
    else:
        # line_slope near +- 1  
        if is_end:
            x_add, y_add = 1, 1
        else:
            x_add, y_add = -1, -1
    
    c_x0, c_y0 = point    
    for i in range(0, extra_len):
        c_x0, c_y0 = (c_x0+x_add, c_y0+y_add)
        extend_segment.append((c_x0, c_y0))
    return extend_segment
    
    
def generate_scribbles_v2(inter_segment, random_range, keep_random_change=False):
    points_return = list()
    x1, y1 = inter_segment[0]    
    x2, y2 = inter_segment[-1] 
    slope_degrees = calculate_slope_degrees(x1, y1, x2, y2)
    
    
    random_index = random.randint(random_range[0], random_range[1])
    if random_index < 0:            
        extra_len = np.abs(random_index)
        extend_segment = extend_line((x1, y1), slope_degrees, extra_len, is_end=False)
        points_return.extend(extend_segment)
        start_index = 0
      
    else:
        start_index = 0 + random_index
        # icc_x = inter_segment[start_index][0]
        # icc_y = inter_segment[start_index][1]


    random_index = random.randint(random_range[0], random_range[1])
    if random_index < 0:            
        extra_len = np.abs(random_index)
        extend_segment = extend_line((x2, y2), slope_degrees, extra_len, is_end=True)
        # points_return.extend(extend_segment)
        end_index = len(inter_segment)
      
    else:
        end_index = len(inter_segment) - random_index
  
    
    
    random_change_x = random.randint(random_range[0], random_range[1])
    random_change_y = random.randint(random_range[0], random_range[1])
    
    for i in range(start_index, end_index):
        if keep_random_change:
            c_point = (inter_segment[i][0]+random_change_x, inter_segment[i][1]+random_change_y)
        else:
            random_change_x = random.randint(random_range[0], random_range[1])
            random_change_y = random.randint(random_range[0], random_range[1])
            # print(random_change_x, random_change_y)
            c_point = (inter_segment[i][0]+random_change_x, inter_segment[i][1]+random_change_y)
        points_return.append(c_point)
    
    # add end extend
    if random_index < 0:     
        points_return.extend(extend_segment)  

    return points_return     
    

def random_range_direction(random_range, line_slope):
    range_coors = "xy"
    if line_slope is None or is_vertical_slope(line_slope):
        range_coors = "y"
    elif line_slope == 0 or is_horizontal_slope(line_slope):
        range_coors = "x"
    else:
        range_coors = "xy"
    return range_coors

        
def generate_scribbles_v3(inter_segment, random_range, keep_random_change=False):
    points_return = list()
    x1, y1 = inter_segment[0]    
    x2, y2 = inter_segment[-1] 
    slope_degrees = calculate_slope_degrees(x1, y1, x2, y2)
    
    random_index = random.randint(random_range[0], random_range[1])
    if random_index < 0:            
        extra_len = np.abs(random_index)
        extend_segment = extend_line((x1, y1), slope_degrees, extra_len, is_end=False)
        points_return.extend(extend_segment)
        start_index = 0
      
    else:
        start_index = 0 + random_index
        # icc_x = inter_segment[start_index][0]
        # icc_y = inter_segment[start_index][1]


    random_index = random.randint(random_range[0], random_range[1])
    if random_index < 0:            
        extra_len = np.abs(random_index)
        extend_segment = extend_line((x2, y2), slope_degrees, extra_len, is_end=True)
        # points_return.extend(extend_segment)
        end_index = len(inter_segment)
      
    else:
        end_index = len(inter_segment) - random_index
      
    
    random_coors = random_range_direction(random_range, slope_degrees)

    for i in range(start_index, end_index):
        if random_coors=="x":
            random_change_x = random.randint(random_range[0], random_range[1])
            random_change_y = 0
        elif random_coors=="y":
            random_change_y = random.randint(random_range[0], random_range[1])
            random_change_x = 0        
        else:
            random_change_x = random.randint(random_range[0], random_range[1])
            random_change_y = random.randint(random_range[0], random_range[1])
        
        c_point = (inter_segment[i][0]+random_change_x, inter_segment[i][1]+random_change_y)
        points_return.append(c_point)
    
    # add end extend
    if random_index < 0:     
        points_return.extend(extend_segment)  

    return points_return   

def get_random_changes(random_range, random_coors, back_random=-2):
    if random_coors=="x":
        random_change_x = random.randint(random_range[0], random_range[1])
        random_change_y = 0
    elif random_coors=="y":
        random_change_y = random.randint(random_range[0], random_range[1])
        random_change_x = 0        
    else:
        # don't go back far, original should not be (-1, 1)
        random_change_x = random.randint(back_random, random_range[1])
        random_change_y = random.randint(back_random, random_range[1])
    return random_change_x, random_change_y


def ge_bresenham_line(start_point, next_point, points_return, points_pair):
    # two bresenham_line2
    line_1 = bresenham_line2(start_point[0], start_point[1], next_point[0], next_point[1])
    points_return.extend(line_1)

    # (will get two small lines) if not connected
    if line_1[-1][0] != next_point[0] and (line_1[-1][1] != next_point[1]):
        line_2 = bresenham_line2(line_1[-1][0], line_1[-1][1], next_point[0], next_point[1])
        # line_2 = bresenham_line2(next_point[0], next_point[1], inter_segment[end_index][0], nter_segment[end_index][1])
        points_return.extend(line_2)  
        if line_2[-1][0] != next_point[0] and (line_2[-1][1] != next_point[1]):
            print("Two judge falled! use cv2")
            points_pair.extend([line_2[-1], next_point]) 

    return points_return, points_pair


def generate_scribbles_v4(inter_segment, random_range, keep_random_change=False, count_change=10, use_cv2=True):
    """
    
    if use_cv2, we won't get the line points between start and end
    At every count_change , circle center will go through one gt pixel?

    """
    points_return = list()
    points_pair = list()
    x1, y1 = inter_segment[0]    
    x2, y2 = inter_segment[-1] 
    slope_degrees = calculate_slope_degrees(x1, y1, x2, y2)
    random_coors = random_range_direction(random_range, slope_degrees)
    random_change_x, random_change_y = get_random_changes(random_range, random_coors)


    random_index = random.randint(random_range[0], random_range[1])
    if random_index < 0:            
        extra_len = np.abs(random_index)
        extend_segment = extend_line((x1, y1), slope_degrees, extra_len, is_end=False)

        # points_return.extend(extend_segment)
        if keep_random_change:
            for p in extend_segment:
                c_point = (p[0]+random_change_x, p+random_change_y)
                points_return.append(c_point)
        else:
            c_point = (extend_segment[-1][0]+random_change_x, inter_segment[-1][1]+random_change_y)
            if use_cv2:
                points_pair.extend([c_point, (x1, y1)]) 
            else:
                points_return, points_pair = ge_bresenham_line(c_point, (x1, y1), points_return, points_pair)

        start_index = 0
      
    else:
        start_index = 0 + random_index


    random_index = random.randint(random_range[0], random_range[1])
    if random_index < 0:            
        extra_len = np.abs(random_index)
        extend_segment = extend_line((x2, y2), slope_degrees, extra_len, is_end=True)
        end_index = len(inter_segment)

        # points_return.extend(extend_segment)
        if keep_random_change:
            for p in extend_segment:
                c_point = (p[0]+random_change_x, p+random_change_y)
                points_return.append(c_point)
        else:
            random_change_x, random_change_y = get_random_changes(random_range, random_coors)
            c_point = (extend_segment[-1][0]+random_change_x, inter_segment[-1][1]+random_change_y)
            if use_cv2:
                points_pair.extend([(x2, y2), c_point]) 
            else:
                points_return, points_pair = ge_bresenham_line((x2, y2), c_point, points_return, points_pair)
      
    else:
        end_index = len(inter_segment) - random_index
      

    if keep_random_change:
        # same as the simulation which uses two points to generate one scribble, 
        # more stabble for lines but not so good for the curves.
        for i in range(start_index, end_index):
            c_point = (inter_segment[i][0]+random_change_x, inter_segment[i][1]+random_change_y)
            points_return.append(c_point)
    
    else:
        # simulate continous connected small lines 
        # by bresenham_line2
        # or cv2.line (cv2.line will get one small line without circle centers)
        
        start_point = inter_segment[start_index]  
        end_point = inter_segment[end_index]        

        for i in range(start_index + count_change, end_index, count_change):            
            next_x, next_y = get_random_changes(random_range, random_coors)
            next_point = (inter_segment[i][0]+next_x, inter_segment[i][1]+next_y)

            if use_cv2:
                points_pair.extend([start_point, next_point]) 
            else:
                points_return, points_pair = ge_bresenham_line(start_point, next_point, points_return, points_pair)
            
            start_point = next_point  

        # case: next_point != end_point
        if use_cv2:
            points_pair.extend([next_point, end_point]) 
        else:
            points_return, points_pair = ge_bresenham_line(next_point, end_point, points_return, points_pair)

    # # add end extend
    # if random_index < 0:     
    #     points_return.extend(extend_segment)       

    return points_return, points_pair   

def is_curve(start_point, middle_point, end_point, angle_threshold_degrees=30):
    # Calculate vectors from start to middle and middle to end points
    vector1 = np.array(middle_point) - np.array(start_point)
    vector2 = np.array(end_point) - np.array(middle_point)

    # Calculate the angle between the vectors using dot product
    dot_product = np.dot(vector1, vector2)
    magnitude_product = np.linalg.norm(vector1) * np.linalg.norm(vector2)

    # Ensure the denominator is not zero
    if magnitude_product != 0:
        cosine_angle = dot_product / magnitude_product
        # Calculate the angle in radians
        angle_radians = np.arccos(cosine_angle)

        # Convert the angle to degrees
        angle_degrees = np.degrees(angle_radians)

        # Compare the angle to the threshold (30 degrees)
        return angle_degrees <= angle_threshold_degrees

    # If the denominator is zero, it's a straight line (low curvature)
    return True  # Within threshold


def generate_scribbles_v4mix(inter_segment, random_range, keep_random_change=False, count_change=10, use_cv2=True, angle_threshold_degrees=30):
    p1 = inter_segment[0]
    p2 = inter_segment[int(len(inter_segment)/2)]
    p3 = inter_segment[-1]

    # slope_degree1 = calculate_slope_degrees(x1, y1, x2, y2)
    # slope_degree2 = calculate_slope_degrees(x2, y2, x3, y3)
    # # diff_angle = np.abs(slope_degree1-slope_degree2)
    # print(slope_degree1, slope_degree2)
    # diff = ((slope_degree2 - slope_degree1 + 180) % 360) - 180
    # if np.abs(diff) > 30:
    if is_curve(p1, p2, p3, angle_threshold_degrees):
        keep_random_change = False
    else:
        keep_random_change = True
    
    points_return, points_pair = generate_scribbles_v4(inter_segment, random_range, keep_random_change=keep_random_change, 
                                                        count_change=count_change, use_cv2=use_cv2)
    return points_return, points_pair   


def scribbles_encoding_v4(points_circle, points_pair, radius, shape, final_mask=None):
       
    if final_mask is not None:
        s_mask = final_mask
    else:
        s_mask = np.zeros((shape[0], shape[1])).astype(np.uint8)

    for point in points_circle:
        s_mask = cv2.circle(s_mask, (point[1], point[0]), radius, [255, 255, 255], -1)    
    
    if len(points_pair) == 0:
        # use_cv2 == False
        return s_mask

    for i in range(0, len(points_pair)-1, 2): 
        p1, p2 = points_pair[i], points_pair[i+1]
        p1c = (p1[1], p1[0])
        p2c = (p2[1], p2[0])
        s_mask = cv2.line(s_mask, p1c, p2c, [127, 127, 127], radius)
        
    return s_mask


def scribbles_encoding_v2(points, radius, shape, final_mask=None):
    # from skimage import draw
    # assert len(points) % 2 == 0
        
    if final_mask is not None:
        s_mask = final_mask
    else:
        s_mask = np.zeros((shape[0], shape[1])).astype(np.uint8)
    
    for point in points:
        s_mask = cv2.circle(s_mask, (point[1], point[0]), radius, [255, 255, 255], -1)
        
    return s_mask

def scribbles_encoding_v3(points, radius, shape, final_mask=None):


    points_array = np.array(points, dtype=np.int32)

    points_array = points_array.reshape((-1, 1, 2))

    if final_mask is not None:
        s_mask = final_mask
    else:
        s_mask = np.zeros((shape[0], shape[1])).astype(np.uint8)
    
    s_mask = cv2.polylines(s_mask , [points_array], isClosed=False, color=(255, 255, 255), thickness=radius*2)

    return s_mask



if __name__ == '__main__':
    radius = 10
    points = [(i, i) for i in range(30, 230)]
    shape = [320, 320]
    start = time.time()
    s1 = scribbles_encoding_v2(points, radius, shape, final_mask=None)
    print(time.time()-start)
    cv2.imwrite("s1.png", s1)

    start = time.time()
    s1 = scribbles_encoding_v3(points, radius, shape, final_mask=None)
    print(time.time()-start)
    cv2.imwrite("s2.png", s1)
