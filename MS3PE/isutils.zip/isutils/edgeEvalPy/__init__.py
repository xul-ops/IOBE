from .nms_process import nms_process_one_image
