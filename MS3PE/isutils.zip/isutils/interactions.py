import cv2
import pdb
import math
import random
import numpy as np
import networkx as nx

from collections import Counter
from isutils.geprmap import ob_nmst, mb_nmst
from scipy.ndimage import distance_transform_edt

import torch
from torch import nn as nn


###########################################################  functional functions #############################################################################################

def get_point_neighbors(pixel_point, img_shape, num_neighbor=4):
    results = list()
    if num_neighbor == 4:
        if (pixel_point[0] - 1 > 0) and (pixel_point[1] - 1 > 0) and \
                (pixel_point[0] + 1 <= img_shape[0] - 1) and (pixel_point[1] + 1 <= img_shape[1] - 1):
            # keep this order
            results.extend([(pixel_point[0], pixel_point[1] + 1), (pixel_point[0], pixel_point[1] - 1),
                            (pixel_point[0] + 1, pixel_point[1]), (pixel_point[0] - 1, pixel_point[1])])
            return results
        # If the condition is not met, the current pixel is the image boundary point
        else:
            return results

    elif num_neighbor == 8:

        if (pixel_point[0] - 1 > 0) and (pixel_point[1] - 1 > 0) and \
                (pixel_point[0] + 1 <= img_shape[0] - 1) and (pixel_point[1] + 1 <= img_shape[1] - 1):

            results.extend([(pixel_point[0], pixel_point[1] + 1), (pixel_point[0], pixel_point[1] - 1),
                            (pixel_point[0] + 1, pixel_point[1]), (pixel_point[0] - 1, pixel_point[1])])
            results.extend([(pixel_point[0] + 1, pixel_point[1] + 1), (pixel_point[0] + 1, pixel_point[1] - 1),
                            (pixel_point[0] - 1, pixel_point[1] + 1), (pixel_point[0] - 1, pixel_point[1] - 1)])
            return results
        # If the condition is not met, the current pixel is the image boundary point
        else:
            return results
    else:
        raise ValueError("num_neighbor should be 4 or 8!")


def get_legal_neighbors(image_shape, point, radius, edge_graph):
    """
    Get legal neighbors of a point within the specified radius on an image plane.

    Args:
        image_shape (tuple): A tuple containing the shape of the image in the format (height, width).
        point (tuple): The coordinates of the center point (x, y).
        radius (float): The maximum distance to consider a neighbor.

    Returns:
        list: A list of legal neighbor points, each represented as a tuple (x, y).
    """

    height, width = image_shape
    x, y = point
    if point in edge_graph:
        neighbors = [point]
    else:
        neighbors = list()

    for i in range(-radius, radius + 1):
        for j in range(-radius, radius + 1):
            distance = math.sqrt(i**2 + j**2)
            c_point = (x + i, y + j)
            if distance <= radius and (0 <= x + i < width) and (0 <= y + j < height) and (c_point in edge_graph):
                neighbors.append(c_point)

    return neighbors
        
        
def get_corner_neighbors(pixel_point, img_shape):
    results = list()
    if (pixel_point[0] - 1 > 0) and (pixel_point[1] - 1 > 0) and \
            (pixel_point[0] + 1 <= img_shape[0] - 1) and (pixel_point[1] + 1 <= img_shape[1] - 1):

        results.extend([(pixel_point[0] + 1, pixel_point[1] + 1), (pixel_point[0] + 1, pixel_point[1] - 1),
                        (pixel_point[0] - 1, pixel_point[1] + 1), (pixel_point[0] - 1, pixel_point[1] - 1)])
        return results
    # If the condition is not met, the current pixel is the image boundary point
    else:
        return results


def get_soreted_edgeframent(ef_list):
    ef_sorted = sorted(ef_list, key=lambda x:len(x))
    return ef_sorted


def slopee(x1, y1, x2, y2):
    if x1 == x2:
        return None
    return (y2 - y1) / (x2 - x1)


def find_points_on_both_sides(x1, y1, slope, distance):
    y = y1
    x = x1 + distance

    x_left = x1 - distance
    y_left = y1 - slope * distance
    x_right = x1 + distance
    y_right = y1 + slope * distance

    return (int(x_left), int(y_left)), (int(x_right), int(y_right))
    
    
def fuse_lines(line_segments):
    merged_segments = []

    while line_segments:
        current_segment = line_segments.pop(0)
        start, end = current_segment[0], current_segment[-1]
        merged_segment = list(current_segment)

        i = 0
        while i < len(line_segments):
            next_segment = line_segments[i]
            next_start, next_end = next_segment[0], next_segment[-1]

            if end == next_start:
                merged_segment.extend(next_segment[1:])
                end = next_end
                line_segments.pop(i)
                i = 0  # Start checking from the beginning
            elif start == next_end:
                merged_segment = list(next_segment) + merged_segment[1:]
                start = next_start
                line_segments.pop(i)
                i = 0  # Start checking from the beginning
            else:
                i += 1

        merged_segments.append(merged_segment)

    return merged_segments


def count_lines_lengths(line_segments):
    # it's more reasonable to count the line segment lengths instead of number
    all_len = 0
    for item in line_segments:
        all_len += len(item)
    return all_len 


def bresenham_line2(x1, y1, x2, y2):
    # Calculate differences
    dx = x2 - x1
    dy = y2 - y1
    pixel_points = list()
    
    # Determine signs
    sx = 1 if dx > 0 else -1
    sy = 1 if dy > 0 else -1
    
    # Take absolute values
    dx = abs(dx)
    dy = abs(dy)
    
    
    if dx<=3: #x2 == x1:
        c_max = max(y1, y2)
        c_min = min(y1, y2)
        for i in range(c_min,c_max+1):
            pixel_points.append((x1, i))
        pixel_points.append((x2, i))
        return pixel_points
    elif dy<=3: #: y2 == y1:
        c_max = max(x1, x2)
        c_min = min(x1, x2)
        for i in range(c_min,c_max+1):
            pixel_points.append((i, y1))
        pixel_points.append((i, y2))
        return pixel_points
    
    # Determine traversal direction
    if dx > dy:
        increment_x = True
        # p = 2 * dy - dx
        t = dx
        dx = dy
        dy = t
    else:
        increment_x = False
        # p = 2 * dx - dy
        
    Error = 2*dy - dx
    A = 2*dy
    B = 2*dy - 2*dx
    
    
    # Initialize starting point
    x = x1
    y = y1
    
    # Store the pixel points
    pixel_points = [(x, y)]
    
    # Iterate over the range from 0 to dx
    for i in range(0, dx): # dx times
        if Error < 0:
            if interchange:
                y += sy
            else:
                x += sx
            Error += A
        else:
            y += sy
            x += sx
            Error += B
                  
        # Add the current pixel point to the list
        pixel_points.append((x, y))
    pixel_points.append((x2, y2))
    if len(pixel_points) <= 2:
        print(x1, y1, x2, y2)
    return pixel_points



###########################################################  main functions #############################################################################################

# TO DO: Create functions just get interactions' points, and use RITM distmaps, or just split interaction and encoding parts.


def set_random_range(is_radius, allowed_changes=2, fixed=True, fixed_range=(-3, 3)):
    if fixed:
        return fixed_range
        
    if is_radius <= 3:
        return (-1, 1)
    else:
        return (0-is_radius+allowed_changes, is_radius-allowed_changes)
        

def naive_checkv2(ppoint, check_value, c_segment, checked, fnfp_map, recursion_out=100):
    if len(c_segment) >= recursion_out:
        # Recursion out
        return c_segment

    # first check 4 direct neighbors:
    cp_n4 = get_point_neighbors(ppoint, fnfp_map.shape, 4)
    direct_n_count = 0
    for cp_n4_item in cp_n4:
        if fnfp_map[cp_n4_item[0], cp_n4_item[1]] == check_value and (checked[(cp_n4_item[0], cp_n4_item[1])] == 0):
            # if check_direction_change(c_segment, cp_n4_item, angle_threshold=60) == 1:
            # checked.append(cp_n4_item)
            checked[(cp_n4_item[0], cp_n4_item[1])] = [1]
            current_check = cp_n4_item
            direct_n_count += 1
    if direct_n_count >= 4:
        # not clear area
        return c_segment
    elif 3 >= direct_n_count >= 1:
        # checked.append(current_check)
        c_segment.append(current_check)
        # recursion
        c_segment = naive_checkv2(current_check, check_value, c_segment, checked, fnfp_map)
        return c_segment
    else:
        # then check 4 corners
        cp_c4 = get_corner_neighbors(ppoint, fnfp_map.shape)
        corner_n_count = 0
        for cp_c4_item in cp_c4:
            if fnfp_map[cp_c4_item[0], cp_c4_item[1]] == check_value and (checked[(cp_c4_item[0], cp_c4_item[1])] == 0):
                # if check_direction_change(c_segment, cp_c4_item, angle_threshold=60) == 1:
                # checked.append(cp_c4_item)
                checked[(cp_c4_item[0], cp_c4_item[1])] = [1]
                current_check = cp_c4_item
                corner_n_count += 1
        # print(corner_n_count)
        if corner_n_count > 1:
            # not clear area
            return c_segment
        elif corner_n_count == 1:
            # checked.append(current_check)
            c_segment.append(current_check)
            # recursion
            c_segment = naive_checkv2(current_check, check_value, c_segment, checked, fnfp_map)
            return c_segment
        else:
            return c_segment
    

def get_fnfp_candidates(gt, edge_prob, match_radius=4, candidate_len=30, need_sort=True, recursion_outlen=130, vis_img=False, vis_path=None, vis_point_rgb=[[255, 0, 0], [0, 0, 255]]):

    """
    # gt: shape 2, 0, 1
    # edge_prob : edge prob predicted after NMS and filtered by threhold or canny res
    # match_radius: in intial pretrain could be higher??? should be tested
    
    """

    h_size, w_size = gt.shape
    dict_keys = [(i, j) for i in range(h_size) for j in range(w_size)]
    map_checked_dict = dict.fromkeys(dict_keys, 0)    
    checked = list()
    # ef_list = list()
    p_candidate_ef = list()
    # p_candidate_ef_points = list()    
    n_candidate_ef = list()
    # n_candidate_ef_points = list()   

    img1_bmap = ((np.array(gt[:, :]) > 0)*1).reshape(gt.shape[0], gt.shape[1], 1)
    img2_bmap = ((np.array(edge_prob[:, :]) > 0)*1).reshape(gt.shape[0], gt.shape[1], 1)
    # print(Counter(img1_bmap.reshape(-1)))
    # print(Counter(img2_bmap.reshape(-1)))
    img_output = np.zeros((gt.shape[0], gt.shape[1], 3))
    fnfp_map = np.zeros((gt.shape[0], gt.shape[1]))

    for i in range(gt.shape[0]):
        for j in range(gt.shape[1]):
            if gt[i, j] != 0 or edge_prob[i, j] != 0:
                img1_check = np.sum(img1_bmap[i-match_radius:i+match_radius+1, j-match_radius:j+match_radius+1 ], axis=(0, 1))[0] > 0
                img2_check = np.sum(img2_bmap[i-match_radius:i+match_radius+1, j-match_radius:j+match_radius+1 ], axis=(0, 1))[0] > 0
                if img1_check and img2_check:
                    # img_output[i, j, :] = [0, 255, 0]
                    continue
                elif img1_check and not img2_check:
                    img_output[i, j, :] = vis_point_rgb[1]
                    fnfp_map[i, j] = 1
                elif not img1_check and img2_check:
                    img_output[i, j, :] = vis_point_rgb[0]
                    fnfp_map[i, j] = -1
                else:
                    continue
    if vis_img:
        cv2.imwrite(vis_path, img_output)
    
    for i in range(fnfp_map.shape[0]):
        for j in range(fnfp_map.shape[1]):
            c_pixel = (i, j)
            if fnfp_map[i, j] == -1 and (map_checked_dict[(i, j)] == 0):
                map_checked_dict[(i, j)] = 1
                # start to check
                c_segment = naive_checkv2(c_pixel, -1, [c_pixel], map_checked_dict, fnfp_map, recursion_out=recursion_outlen)
                # ef_list.append(c_segment)
                if len(c_segment) >= candidate_len:
                    n_candidate_ef.append(c_segment)
                    # n_candidate_ef_points.extend(c_segment)
            if fnfp_map[i, j] == 1 and (map_checked_dict[(i, j)] == 0):
                map_checked_dict[(i, j)] = 1
                c_segment = naive_checkv2(c_pixel, 1, [c_pixel], map_checked_dict, fnfp_map, recursion_out=recursion_outlen)
                # ef_list.append(c_segment)
                if len(c_segment) >= candidate_len:
                    p_candidate_ef.append(c_segment)
                    # p_candidate_ef_points.extend(c_segment)
     
    # return img_output  
    if need_sort:
        return get_soreted_edgeframent(p_candidate_ef), get_soreted_edgeframent(n_candidate_ef)
    else:
        return p_candidate_ef, n_candidate_ef  


def generate_interaction_maps(segments, prmap_shape, num_points=3, encoding="disk", interaction="scribbles", random_range=(-1, 1), radius=3, op_way="middle", final_mask=None, 
                              epmap=None, **kwargs):
    assert len(segments) == num_points

    """
    support pair (interaction, encoding): 
    (point/points, disk/distance), (bbox, bbox), (scribbles, scribbles/distance), (syn_scribbles, syn_scribbles/syn_scribbles_dis)
    distance : eu, gau, multi circles 
    
    not support yet:  (nmst_syn_scribbles, syn_scribbles/syn_scribbles_dis), might has problems, small low confidence values have no edge pro.
    
    """
    if len(segments) == 0:
        if final_mask is not None:
            return final_mask  # ,  []
        else:
            return np.zeros((prmap_shape[0], prmap_shape[1])) # , []
            
    # get points
    points_iter = list()
    p_weight = list()
    for inter_seg in segments:
        if interaction == "two_points" or interaction == "bbox":
            points_iter.extend(generate_two_points(inter_seg, random_range))
        elif interaction == "multi_points":
            points_iter.extend(generate_multiple_points(inter_seg, random_range))
        elif interaction == "point":
            if op_way == "random":
                points_iter.append(generate_random_point(inter_seg))
            elif op_way == "middle":
                points_iter.append(generate_middle_point(inter_seg, random_range))
        elif interaction == "scribbles":
            # points_iter.extend(generate_scribbles_v2(inter_seg, random_range=random_range, keep_random_change=True))

            # discrete circle center points
            points_iter.extend(generate_scribbles_v3(inter_seg, random_range=random_range, keep_random_change=False))

            # # continous circle center points
            # c_iter, c_weight = generate_scribbles_v4(inter_seg, random_range=random_range, count_change=10)

            # synthetic line
            # points_iter.extend(generate_two_points(inter_seg, random_range))

            # c_iter, c_weight = generate_scribbles_v4mix(inter_seg, random_range=random_range, count_change=10, angle_threshold_degrees=30)

            # points_iter.extend(c_iter)
            # p_weight.extend(c_weight)

        elif interaction == "syn_scribbles":
            # bresenham_line works not good
            # a, b = generate_syn_scribbles(inter_seg, random_range)
            # points_iter.extend(a)
            # p_weight.extend(b)
            
            # nmspoints = generate_nmst_scribbles(inter_seg, epmap, random_range=(-2, 2), threshold=0.1)
            # points_iter.extend(nmspoints)            
            p_weight.extend(generate_two_points(inter_seg, random_range))

        else:
            raise ValueError("Not support yet")
        
    # generate mask
    if encoding == "disk":
        final_mask = disk_encoding(points_iter, radius, prmap_shape, final_mask)
    elif encoding == "scribbles":
        final_mask = scribbles_encoding_v2(points_iter, radius, prmap_shape, final_mask)
        # final_mask = scribbles_encoding_v4(points_iter, p_weight, radius, prmap_shape, final_mask)
    elif encoding == "syn_scribbles":
        # final_mask = scribbles_encoding_syn(points_iter, radius, prmap_shape, p_weight, final_mask=final_mask)
        final_mask = scribbles_encoding_synv2(p_weight, radius, prmap_shape, final_mask=final_mask)

    elif encoding == "eudistance":
        final_mask = eudis_encoding(points_iter, prmap_shape, isdis_radius=30, mode="distance_limit") # full
        # final_mask = disk_encoding(points_iter, radius, prmap_shape, final_mask=final_mask)
    elif encoding == "gaudistance":
        final_mask = gaudis_encoding(points_iter, prmap_shape, sigma=0.04, isdis_radius=30, mode="distance_full") # full
        # final_mask = disk_encoding(points_iter, radius, prmap_shape, final_mask=final_mask)
    elif encoding == "syn_scribbles_dis":
        final_mask = eudis_encoding(points_iter, prmap_shape, isdis_radius=30, mode="distance_limit") # full
        # final_mask = disk_encoding(points_iter/p_weight, radius, prmap_shape, final_mask=final_mask)

    elif encoding == "bbox":
        # radius should higer, loss weight could be higher
        bboxradius = radius * 10
        final_mask = bbox_encoding(points_iter, bboxradius, prmap_shape, final_mask=final_mask, fill_area=False)
    elif encoding == "rectangle":
        # final_mask = ori_rectangle(points_iter, radius, radius*10, prmap_shape, final_mask=final_mask)
        final_mask = rectangle2_encoding(points_iter, radius, radius*10, prmap_shape, final_mask=final_mask)    
        # final_mask = rectangle_encoding(points_iter, radius*2, radius*2, prmap_shape, final_mask=final_mask)
    elif encoding == "orirectangle":
        # final_mask = ori_rectanglev1(points_iter, radius, prmap_shape, fixed_len=None, one_side=True, final_mask=final_mask)
        # final_mask = ori_rectanglev2(points_iter, radius, prmap_shape, fixed_len=None, one_side=True, final_mask=final_mask)
        final_mask = ori_rectanglev3(points_iter, radius, prmap_shape, add_radius=True, final_mask=final_mask)
    elif encoding == "multi_circles":
        final_mask = multi_circles(points_iter, [20, 3], [0.3, 1.0], prmap_shape, final_mask=final_mask) # full
        # final_mask = disk_encoding(points_iter, radius, prmap_shape, final_mask=final_mask)
    elif encoding == "geo_shape":
        final_mask = geo_enconding(points_iter, radius, prmap_shape, geo_type="circle", final_mask=final_mask)

    elif encoding == "edge_path": # ob_path
        final_mask = edge_scribbles_encoding(epmap, points_iter, radius, prmap_shape, path_mode="shortest", final_mask=final_mask)

    else:
        raise ValueError

    return final_mask # , points_iter # .extend(p_weight)


# multi radii
def generate_interaction_maps_multi(segments, prmap_shape, num_points=3, encoding="disk", interaction="scribbles", random_range=(-1, 1), radius=3, op_way="middle", final_mask=None, 
                              epmap=None, multi_radius=False, multi_cands=None,  **kwargs):
    assert len(segments) == num_points

    """
    support pair (interaction, encoding): 
    (point/points, disk/distance), (bbox, bbox), (scribbles, scribbles/distance), (syn_scribbles, syn_scribbles/syn_scribbles_dis)
    distance : eu, gau, multi circles 
    
    not support yet:  (nmst_syn_scribbles, syn_scribbles/syn_scribbles_dis), might has problems, small low confidence values have no edge pro.
    
    """
    if len(segments) == 0:
        if final_mask is not None:
            return final_mask  # ,  []
        else:
            return np.zeros((prmap_shape[0], prmap_shape[1])) # , []

    if multi_cands is not None:
        radius_cands = multi_cands
    else:
        radius_cands = range(5, radius)  

    points_iter_dict = dict()
    p_weight_dict = dict()
    random_range_dict = dict()

    for radius_item in radius_cands:
        points_iter_dict[radius_item] = list()
        p_weight_dict[radius_item] = list()
        random_range_dict[radius_item] = set_random_range(radius_item, allowed_changes=2, fixed=False, fixed_range=(-1, 1))


    for inter_seg in segments:
        radius = random.choice(radius_cands)
        if interaction == "two_points" or interaction == "bbox":
            points_iter_dict[radius].extend(generate_two_points(inter_seg, random_range))
        elif interaction == "multi_points":
            points_iter_dict[radius].extend(generate_multiple_points(inter_seg, random_range))
        elif interaction == "point":
            if op_way == "random":
                points_iter_dict[radius].append(generate_random_point(inter_seg))
            elif op_way == "middle":
                ppoints_iter_dict[radius].append(generate_middle_point(inter_seg, random_range))
        elif interaction == "scribbles":
            # points_iter.extend(generate_scribbles_v2(inter_seg, random_range=random_range, keep_random_change=True))

            # discrete circle center points
            points_iter_dict[radius].extend(generate_scribbles_v3(inter_seg, random_range=random_range, keep_random_change=False))

            # # continous circle center points
            # c_iter, c_weight = generate_scribbles_v4(inter_seg, random_range=random_range, keep_random_change=True, count_change=10, use_cv2=True)
            # c_iter, c_weight = generate_scribbles_v4mix(inter_seg, random_range=random_range, count_change=10, use_cv2=True, angle_threshold_degrees=30)
            # points_iter_dict[radius].extend(c_iter)
            # p_weight_dict[radius].extend(c_weight)

        elif interaction == "syn_scribbles":
            # bresenham_line works not good
            # a, b = generate_syn_scribbles(inter_seg, random_range)
            # points_iter.extend(a)
            # p_weight.extend(b)
            
            # nmspoints = generate_nmst_scribbles(inter_seg, epmap, random_range=(-2, 2), threshold=0.1)
            # points_iter.extend(nmspoints)            
            p_weight_dict.extend(generate_two_points(inter_seg, random_range))

        else:
            raise ValueError("Not support yet")
        
    # generate mask
    for radius, points_iter in points_iter_dict.items():
        p_weight = p_weight_dict[radius_item]
        random_range = random_range_dict[radius]

        if encoding == "disk":
            final_mask = disk_encoding(points_iter, radius, prmap_shape, final_mask)
        elif encoding == "scribbles":
            final_mask = scribbles_encoding_v2(points_iter, radius, prmap_shape, final_mask)
            # final_mask = scribbles_encoding_v4(points_iter, p_weight, radius, prmap_shape, final_mask)
        elif encoding == "bbox":
            # radius should higer, loss weight could be higher
            bboxradius = radius * 10
            final_mask = bbox_encoding(points_iter, bboxradius, prmap_shape, final_mask=final_mask, fill_area=False)
        elif encoding == "eudistance":
            final_mask = eudis_encoding(points_iter, prmap_shape, isdis_radius=30, mode="distance_limit") # full
            # final_mask = disk_encoding(points_iter, radius, prmap_shape, final_mask=final_mask)
        elif encoding == "gaudistance":
            final_mask = gaudis_encoding(points_iter, prmap_shape, sigma=0.04, isdis_radius=30, mode="distance_full") # full
            # final_mask = disk_encoding(points_iter, radius, prmap_shape, final_mask=final_mask)
        elif encoding == "rectangle":
            # final_mask = ori_rectangle(points_iter, radius, radius*10, prmap_shape, final_mask=final_mask)
            final_mask = rectangle2_encoding(points_iter, radius, radius*10, prmap_shape, final_mask=final_mask)    
            # final_mask = rectangle_encoding(points_iter, radius*2, radius*2, prmap_shape, final_mask=final_mask)
        elif encoding == "orirectangle":
            # final_mask = ori_rectanglev1(points_iter, radius, prmap_shape, fixed_len=None, one_side=True, final_mask=final_mask)
            # final_mask = ori_rectanglev2(points_iter, radius, prmap_shape, fixed_len=None, one_side=True, final_mask=final_mask)
            final_mask = ori_rectanglev3(points_iter, radius, prmap_shape, add_radius=True, final_mask=final_mask)
        elif encoding == "multi_circles":
            final_mask = multi_circles(points_iter, [20, 3], [0.3, 1.0], prmap_shape, final_mask=final_mask) # full
            # final_mask = disk_encoding(points_iter, radius, prmap_shape, final_mask=final_mask)
        elif encoding == "syn_scribbles":
            # final_mask = scribbles_encoding_syn(points_iter, radius, prmap_shape, p_weight, final_mask=final_mask)
            final_mask = scribbles_encoding_synv2(p_weight, radius, prmap_shape, final_mask=final_mask)
        elif encoding == "syn_scribbles_dis":
            final_mask = eudis_encoding(points_iter, prmap_shape, isdis_radius=30, mode="distance_limit") # full
            # final_mask = disk_encoding(points_iter/p_weight, radius, prmap_shape, final_mask=final_mask)
        elif encoding == "edge_path": # ob_path
            final_mask = edge_scribbles_encoding(epmap, points_iter, radius, prmap_shape, path_mode="shortest", final_mask=final_mask)
        elif encoding == "geo_shape":
            final_mask = geo_enconding(points_iter, radius, prmap_shape, geo_type="circle", final_mask=final_mask)
        else:
            raise ValueError

    return final_mask # , points_iter # .extend(p_weight)    


def get_batch_masks(pred_list, gt_list, p_threshold=0.7, match_radius=4, candidate_len=30, need_sort=True, cand_num=1, encoding="disk",
                     interaction="scribbles", recursion_outlen=130,  random_range=(-1, 1), radius=2, op_way="middle", 
                     final_pmask=None, final_nmask=None, use_mbnms=False, matlab_engine=None, 
                     epmap=None, epgraph_t=0.1, multi_radius=False, multi_cands=None,  **kwargs):

    # map_list = list()
    fp_masks = list()
    fn_masks = list()
    # no_changes = False
    nmst_list = list()
    pos_nums = list()
    neg_nums = list() 
    neg_nums2 = list()   
        
    for i in range(pred_list.shape[0]):
        if use_mbnms:
           # matlab nms threshold could be higher, and candidate_len should be less
            obnmst = mb_nmst(pred_list[i], p_threshold, matlab_engine)
            obnmst = np.array(obnmst)
        else:
            obnmst = ob_nmst(pred_list[i], p_threshold)
        nmst_list.append(obnmst)
        
        if epmap is None:
            epmap = range(pred_list.shape[0])
        if encoding == "edge_path":
            OBNMS = ob_nmst(pred_list[i], 0.0)
            edge_graph = build_edge_graph(OBNMS, epgraph_t)
            # build_edge_graph(epmap[i], epgraph_t)
        else:
            edge_graph = 0
        
        # count_ones = np.count_nonzero(gt_list[i] == 1)
        count_ones = np.count_nonzero(gt_list[i] != 0)
        count_zeros = np.count_nonzero(gt_list[i] == 0)

        p_candidates, n_candidates = get_fnfp_candidates(gt_list[i], obnmst, match_radius=match_radius, candidate_len=candidate_len, need_sort=need_sort, recursion_outlen=recursion_outlen, **kwargs)
        # map_list.append(c_pr_map)
        
        if len(p_candidates) != 0:
            if cand_num == -1:
                p_len_s = 0
                p_cand_num = len(p_candidates)  
            else:  
                if len(p_candidates) >= cand_num:
                    p_len_s = len(p_candidates) - cand_num
                    p_cand_num = cand_num
                else:
                    p_len_s = 0    
                    p_cand_num = len(p_candidates)     

            if multi_radius:
                cp_mask = generate_interaction_maps_multi(p_candidates[p_len_s:], obnmst.shape, num_points=p_cand_num, encoding=encoding, interaction=interaction, 
                                    random_range=random_range, radius=radius, final_mask=final_pmask[i], epmap=edge_graph,
                                    multi_radius=multi_radius, multi_cands=multi_cands)
            else:
                cp_mask = generate_interaction_maps(p_candidates[p_len_s:], obnmst.shape, num_points=p_cand_num, encoding=encoding, interaction=interaction, 
                                                    random_range=random_range, radius=radius, final_mask=final_pmask[i], epmap=edge_graph,)

            fp_masks.append(cp_mask)
            real_num = count_lines_lengths(p_candidates[p_len_s:])
            pos_nums.append(real_num/count_ones)

            # print(real_num, count_ones)
            # real_num = fuse_lines(p_candidates[p_len_s:])
            # pos_nums.append(len(real_num))

        else:
            fp_masks.append(final_pmask[i])
            pos_nums.append(0)
   

        if len(n_candidates) != 0:
            if cand_num == -1:
                n_len_s = 0 
                n_cand_num = len(n_candidates)
            else:
                if len(n_candidates) >= cand_num:
                    n_len_s = len(n_candidates) - cand_num
                    n_cand_num = cand_num
                else:
                    n_len_s = 0 
                    n_cand_num = len(n_candidates)

            if multi_radius:
                cn_mask = generate_interaction_maps_multi(n_candidates[n_len_s:], obnmst.shape, num_points=n_cand_num, encoding=encoding, interaction=interaction, 
                                                random_range=random_range, radius=radius, final_mask=final_nmask[i], epmap=edge_graph,
                                                multi_radius=multi_radius, multi_cands=multi_cands)          
            else:      
                cn_mask = generate_interaction_maps(n_candidates[n_len_s:], obnmst.shape, num_points=n_cand_num, encoding=encoding, interaction=interaction, 
                                                random_range=random_range, radius=radius, final_mask=final_nmask[i], epmap=edge_graph,)

            fn_masks.append(cn_mask)
            # neg_nums.append(n_cand_num)   
            real_num = count_lines_lengths(n_candidates[n_len_s:])  
            neg_nums.append(real_num/count_zeros) 

            if count_ones != 0:
                neg_nums2.append(real_num/count_ones) 
            # else:
            #     neg_nums2.append(0)    
                          
            # real_num = fuse_lines(n_candidates[n_len_s:])
            # neg_nums.append(len(real_num))     
                   
        else:
            fn_masks.append(final_nmask[i])          
            neg_nums.append(0) 
            neg_nums2.append(0)  

    fp_masks, fn_masks, nmst_list = np.array(fp_masks)[:, np.newaxis, :, :], np.array(fn_masks)[:, np.newaxis, :, :], np.array(nmst_list)[:, np.newaxis, :, :]            
    return fp_masks, fn_masks, nmst_list, pos_nums, neg_nums, neg_nums2
 
    

def get_batch_masks_cdnet(pred_list, gt_list, p_threshold=0.7, match_radius=4, candidate_len=30, need_sort=True, cand_num=1, encoding="disk",
                     interaction="scribbles", recursion_outlen=130,  random_range=(-1, 1), radius=2, op_way="middle", 
                     final_pmask=None, final_nmask=None, use_mbnms=False, matlab_engine=None, 
                     epmap=None, epgraph_t=0.1, multi_radius=False, multi_cands=None, cdnet_fdm_mask=False, fdm_final_pmask=None, fdm_final_nmask=None,  **kwargs):
    
    # map_list = list()
    fp_masks = list()
    fn_masks = list()
    # no_changes = False
    nmst_list = list()
    pos_nums = list()
    neg_nums = list() 
    neg_nums2 = list()
    # print(fdm_final_nmask)
    if cdnet_fdm_mask:
        fdm_fp_masks = list()
        fdm_fn_masks = list()       
        
    for i in range(pred_list.shape[0]):
        if use_mbnms:
           # matlab nms threshold could be higher, and candidate_len should be less
            obnmst = mb_nmst(pred_list[i], p_threshold, matlab_engine)
            obnmst = np.array(obnmst)
        else:
            obnmst = ob_nmst(pred_list[i], p_threshold)
        nmst_list.append(obnmst)
        
        if epmap is None:
            epmap = range(pred_list.shape[0])
        if encoding == "edge_path":
            OBNMS = ob_nmst(pred_list[i], 0.0)
            edge_graph = build_edge_graph(OBNMS, epgraph_t)
            # build_edge_graph(epmap[i], epgraph_t)
        else:
            edge_graph = 0
        

        count_ones = np.count_nonzero(gt_list[i] == 1)
        count_zeros = np.count_nonzero(gt_list[i] == 0)

        p_candidates, n_candidates = get_fnfp_candidates(gt_list[i], obnmst, match_radius=match_radius, candidate_len=candidate_len, need_sort=need_sort, recursion_outlen=recursion_outlen, **kwargs)
        # map_list.append(c_pr_map)
        
        if len(p_candidates) != 0:
            if cand_num == -1:
                p_len_s = 0
                p_cand_num = len(p_candidates)  
            else:  
                if len(p_candidates) >= cand_num:
                    p_len_s = len(p_candidates) - cand_num
                    p_cand_num = cand_num
                else:
                    p_len_s = 0    
                    p_cand_num = len(p_candidates)     

            
            cp_mask = generate_interaction_maps(p_candidates[p_len_s:], obnmst.shape, num_points=p_cand_num, encoding=encoding, interaction=interaction, 
                                                random_range=random_range, radius=radius, final_mask=final_pmask[i], epmap=edge_graph,
                                                multi_radius=multi_radius, multi_cands=multi_cands)
            fp_masks.append(cp_mask)
            if cdnet_fdm_mask:
                fdm_cp_mask = generate_interaction_maps(p_candidates[p_len_s:], obnmst.shape, num_points=p_cand_num, encoding=encoding, interaction=interaction, random_range=random_range, radius=24, final_mask=final_pmask[i], epmap=edge_graph)
                fdm_fp_masks.append(fdm_cp_mask)            
            real_num = count_lines_lengths(p_candidates[p_len_s:])
            pos_nums.append(real_num/count_ones)
            # real_num = fuse_lines(p_candidates[p_len_s:])
            # pos_nums.append(len(real_num))
        else:
            fp_masks.append(final_pmask[i])
            pos_nums.append(0)
            if cdnet_fdm_mask:
                fdm_fp_masks.append(fdm_final_pmask[i])                 
   


        if len(n_candidates) != 0:
            if cand_num == -1:
                n_len_s = 0 
                n_cand_num = len(n_candidates)
            else:
                if len(n_candidates) >= cand_num:
                    n_len_s = len(n_candidates) - cand_num
                    n_cand_num = cand_num
                else:
                    n_len_s = 0 
                    n_cand_num = len(n_candidates)
            cn_mask = generate_interaction_maps(n_candidates[n_len_s:], obnmst.shape, num_points=n_cand_num, encoding=encoding, interaction=interaction, 
                                                random_range=random_range, radius=radius, final_mask=final_nmask[i], epmap=edge_graph,
                                                multi_radius=multi_radius, multi_cands=multi_cands)
            fn_masks.append(cn_mask)

            if cdnet_fdm_mask:
                fdm_cn_mask = generate_interaction_maps(n_candidates[n_len_s:], obnmst.shape, num_points=n_cand_num, encoding=encoding, interaction=interaction, random_range=random_range, radius=24, final_mask=final_nmask[i], epmap=edge_graph)
                fdm_fn_masks.append(fdm_cn_mask)   


            # neg_nums.append(n_cand_num)   
            real_num = count_lines_lengths(n_candidates[n_len_s:])  
            neg_nums.append(real_num/count_zeros)    
            if count_ones != 0:
                # print(real_num, count_ones)
                neg_nums2.append(real_num/count_ones) 
            # else:
            #    neg_nums2.append(0)     
                            
            # real_num = fuse_lines(n_candidates[n_len_s:])
            # neg_nums.append(len(real_num))            
        else:
            fn_masks.append(final_nmask[i])          
            neg_nums.append(0) 
            neg_nums2.append(0) 
            if cdnet_fdm_mask:
                fdm_fn_masks.append(fdm_final_nmask[i])               

    fp_masks, fn_masks, nmst_list = np.array(fp_masks)[:, np.newaxis, :, :], np.array(fn_masks)[:, np.newaxis, :, :], np.array(nmst_list)[:, np.newaxis, :, :]            

    if cdnet_fdm_mask:
        fdm_fp_masks, fdm_fn_masks = np.array(fdm_fp_masks)[:, np.newaxis, :, :], np.array(fdm_fn_masks)[:, np.newaxis, :, :]
        return fp_masks, fn_masks, nmst_list, pos_nums, neg_nums, fdm_fp_masks, fdm_fn_masks, neg_nums2                           
    
    return fp_masks, fn_masks, nmst_list, pos_nums, neg_nums, neg_nums2
        
        
###########################################################  interactions' encodings ###################################################################################

def eudis_encoding(points, shape, isdis_radius=20, mode="distance_limit"):
    tmpDist = 255 * np.ones((shape[0],shape[1]))
    [mx, my] = np.meshgrid(np.arange(shape[1]),np.arange(shape[0]))  
   
    if mode == "distance_full":
        for i in range(len(points)):
            tmpX = mx-points[i][1]
            tmpY = my-points[i][0]
            tmpDist = np.minimum(tmpDist, np.sqrt(np.square(tmpX)+np.square(tmpY)))

    elif mode == "distance_limit":
        b_mask = np.zeros((shape[0], shape[1], 3)) 
        for i in range(len(points)):
            tmpX = mx-points[i][1]
            tmpY = my-points[i][0]
            tmpDist = np.minimum(tmpDist, np.sqrt(np.square(tmpX)+np.square(tmpY)))
            b_mask = cv2.circle(b_mask, (points[i][1], points[i][0]), isdis_radius, [255, 255, 255], -1)

        b_mask_m = b_mask[:, :, 0] / 255
        # # print(Counter(tmpDist.reshape(-1)))
        # print(tmpDist.shape, b_mask_m.shape)
        # cv2.imwrite("./bmask.png", b_mask)
        tmpDist = tmpDist*b_mask_m

    tmpRst = np.array(tmpDist)
    tmpRst[np.where(tmpRst > 255)] = 255
    return tmpRst


def gaudis_encoding(points, shape, sigma=0.04, isdis_radius=20, mode="distance_limit"):
    """
    Paper: Interactive Boundary Prediction for Object Selection
    :param sigma: 0.02, 0.04, 0.08
    a small σ value provides exact information about the location of selection
    a larger σ value tends to encourage the network to learn features at larger scopes
    :return: 255 interaction map
    """
    L = min(shape[0], shape[1])
    tmpDist = np.zeros((shape[0], shape[1]))  # * 255
    [mx, my] = np.meshgrid(np.arange(shape[1]), np.arange(shape[0]))

    if mode == "distance_full":
        for i in range(len(points)):
            tmpX = mx - points[i][1]
            tmpY = my - points[i][0]
            eudis2 = np.square(tmpX) + np.square(tmpY)
            gaudis = np.exp(-(eudis2) / (2 * np.square(sigma*L)))
            tmpDist = np.maximum(tmpDist, gaudis)

    elif mode == "distance_limit":
        b_mask = np.zeros((shape[0], shape[1], 3))
        for i in range(len(points)):
            tmpX = mx - points[i][1]
            tmpY = my - points[i][0]
            eudis2 = np.square(tmpX) + np.square(tmpY)
            gaudis = np.exp(-(eudis2) / (2 * np.square(sigma * L)))
            tmpDist = np.maximum(tmpDist, gaudis) 
            b_mask = cv2.circle(b_mask, (points[i][1], points[i][0]), isdis_radius, [255, 255, 255], -1)

        b_mask_m = b_mask[:, :, 0] / 255
        tmpDist = (tmpDist) * b_mask_m

    tmpRst = np.array(tmpDist)
    tmpRst[np.where(tmpRst > 255)] = 255
    return tmpRst * 255
    
    
def multi_circles(points, radius_list, colors_list, shape, final_mask=None, adding_mode="add"):
    assert len(radius_list) == len(colors_list)
    
    if final_mask is not None:
        s_mask = final_mask
    else:
        # s_mask = np.zeros((shape[0], shape[1], 3)).astype(np.uint8)
        s_mask = np.zeros((shape[0], shape[1])).astype(np.uint8)
        
    if adding_mode == "add":
        for point in points:
            point = (int(point[1]), int(point[0]))

            for i in range(len(radius_list)):
                c = [colors_list[i]*255, colors_list[i]*255, colors_list[i]*255]
                c_mask = np.zeros((shape[0], shape[1])).astype(np.uint8)
                cv2.circle(c_mask, point, int(radius_list[i]), c, -1)
                s_mask = s_mask + c_mask
        s_mask = np.clip(s_mask, 0, 255)
    else:
        for point in points:
            point = (int(point[1]), int(point[0]))

            for i in range(len(radius_list)):
                c = [colors_list[i]*255, colors_list[i]*255, colors_list[i]*255]
                cv2.circle(s_mask, point, int(radius_list[i]), c, -1)

    return s_mask


def bbox_encoding(points, radius, shape, fill_area=False, final_mask=None, filled_rate=0.3):
    # from skimage import draw
    assert len(points) % 2 == 0
        
    if final_mask is not None:
        s_mask = final_mask
    else:
        s_mask = np.zeros((shape[0], shape[1])).astype(np.uint8)
    
    filled_color = [255, 255, 255] * filled_rate
    
    areas = list()
    for i in range(0, len(points), 2):
        point1 = points[i]
        point2 = points[i+1]
        if point1[0] == point2[0]:
            area = np.array([[point1[1], point1[0]+radius], [point1[1], point1[0]-radius],
                             [point2[1], point2[0]+radius], [point2[1], point2[0]-radius] ])
            if fill_area:
                s_mask = cv2.rectangle(s_mask, [point1[1], point1[0]+radius], [point2[1], point2[0]-radius], filled_color, -1)
            else:
                s_mask = cv2.rectangle(s_mask, [point1[1], point1[0]+radius], [point2[1], point2[0]-radius], filled_color, 1)
            # s_mask = cv2.fillConvexPoly(s_mask, area, [255, 255, 255])

            areas.append(area)
        elif point1[1] == point2[1]:
            area = np.array([[point1[1]+radius, point1[0]], [point1[1]-radius, point1[0]],
                             [point2[1]+radius, point2[0]], [point2[1]-radius, point2[0]]])
            areas.append(area)

            if fill_area:
                s_mask = cv2.rectangle(s_mask, [point1[1]+radius, point1[0]], [point2[1]-radius, point2[0]], filled_color, -1)
            else:
                s_mask = cv2.rectangle(s_mask, [point1[1]+radius, point1[0]], [point2[1]-radius, point2[0]], filled_color, 1)
            
        else:
            #
            c_slopee = slopee(point1[1], point1[0], point2[1], point2[0])
            p1, p2 = find_points_on_both_sides(point1[1], point1[0], -1/c_slopee, radius)
            p3, p4 = find_points_on_both_sides(point2[1], point2[0], -1/c_slopee, radius)
            areas.append(np.array([p1, p2, p3, p4]))
            s_mask = cv2.rectangle(s_mask, p1, p4, filled_color, 1)
            if fill_area:
                s_mask = cv2.rectangle(s_mask, p1, p4, filled_color, -1)
            else:
                s_mask = cv2.rectangle(s_mask, p1, p4, filled_color, 1)

    # s_mask = cv2.fillPoly(s_mask, areas, filled_color)
    return s_mask
    

def scribbles_encoding_v2(points, radius, shape, final_mask=None):
    # from skimage import draw
    # assert len(points) % 2 == 0
        
    if final_mask is not None:
        s_mask = final_mask
    else:
        s_mask = np.zeros((shape[0], shape[1])).astype(np.uint8)
    
    for point in points:
        s_mask = cv2.circle(s_mask, (point[1], point[0]), radius, [255, 255, 255], -1)
        
    return s_mask


def scribbles_encoding_v4(points_circle, points_pair, radius, shape, final_mask=None):
       
    if final_mask is not None:
        s_mask = final_mask
    else:
        s_mask = np.zeros((shape[0], shape[1])).astype(np.uint8)

    for point in points_circle:
        s_mask = cv2.circle(s_mask, (point[1], point[0]), radius, [255, 255, 255], -1)    
    
    if len(points_pair) == 0:
        # use_cv2 == False
        return s_mask

    for i in range(0, len(points_pair)-1, 2): 
        p1, p2 = points_pair[i], points_pair[i+1]
        p1c = (p1[1], p1[0])
        p2c = (p2[1], p2[0])
        s_mask = cv2.line(s_mask, p1c, p2c, [255, 255, 255], radius*2) # +1 + 3 ?
        
    return s_mask
        
        
def scribbles_encoding_syn(points, radius, shape, weighted_list, final_mask=None):
    # from skimage import draw
    # assert len(points) % 2 == 0
        
    if final_mask is not None:
        s_mask = final_mask
    else:
        s_mask = np.zeros((shape[0], shape[1])).astype(np.uint8)
    
    for point in points:
        s_mask = cv2.circle(s_mask, (point[1], point[0]), radius, [127, 127, 127], -1)
    for point in  weighted_list:
        s_mask = cv2.circle(s_mask, (point[1], point[0]), radius, [255, 255, 255], -1)
    return s_mask
    
    
def scribbles_encoding_synv2(weighted_list, radius, shape, final_mask=None):
    # from skimage import draw
    # assert len(points) % 2 == 0
    # use cv2.line create syn line
        
    if final_mask is not None:
        s_mask = final_mask
    else:
        s_mask = np.zeros((shape[0], shape[1])).astype(np.uint8)
    

    for i in range(0, len(weighted_list)-1, 2): 
        p1, p2 = weighted_list[i], weighted_list[i+1]
        p1c = (p1[1], p1[0])
        p2c = (p2[1], p2[0])
        s_mask = cv2.line(s_mask, p1c, p2c, [127, 127, 127], radius*2)
        
    for point in  weighted_list:
        s_mask = cv2.circle(s_mask, (point[1], point[0]), radius, [255, 255, 255], -1)     
    return s_mask
    
    
def disk_encoding(points, radius, shape, final_mask=None):
    
    if final_mask is not None:
        disk_map = final_mask
    else:
        disk_map = np.zeros((shape[0], shape[1])).astype(np.uint8)
    for point in points:
        disk_map = cv2.circle(disk_map, (point[1], point[0]), radius, [255, 255, 255], -1)
    return disk_map


def rectangle_encoding(points, radius_h, radius_w, shape, final_mask=None):
    
    if final_mask is not None:
        disk_map = final_mask
    else:
        disk_map = np.zeros((shape[0], shape[1])).astype(np.uint8)
    # print(disk_map.shape, type(disk_map))
    for point in points:
        p1 = (point[1]- radius_h, point[0]- radius_w)
        p2 = (point[1]+ radius_h, point[0]+ radius_w)
        disk_map = cv2.rectangle(disk_map, p1, p2, [255, 255, 255], -1)
    return disk_map


def rectangle2_encoding(points, radius_h, radius_w, shape, final_mask=None):
    
    if final_mask is not None:
        disk_map = final_mask
    else:
        disk_map = np.zeros((shape[0], shape[1])).astype(np.uint8)
    # print(disk_map.shape, type(disk_map))
    for point in points:
        p1 = (point[1]- radius_w, point[0]- radius_h)
        p2 = (point[1]+ radius_w, point[0]+ radius_h)
        p3 = (point[1]- radius_h, point[0]- radius_w)
        p4 = (point[1]+ radius_h, point[0]+ radius_w)
        disk_map = cv2.rectangle(disk_map, p1, p2, [127, 127, 127], -1)
        disk_map = cv2.rectangle(disk_map, p3, p4, [127, 127, 127], -1)
    return disk_map


def multi_rectangles(points, radius_hs, radius_ws, colors, shape, final_mask=None):
    # what is the right direction, height direct or width direct
    # multi circle not good
    assert len(radius_hs) == len(colors) and len(radius_ws) == len(colors)
    
    if final_mask is not None:
        disk_map = final_mask
    else:
        disk_map = np.zeros((shape[0], shape[1])).astype(np.uint8)
    # print(disk_map.shape, type(disk_map))
    for point in points:
        for i in range(len(colors)):

            p1 = (point[1]- radius_ws[i], point[0]- radius_hs[i])
            p2 = (point[1]+ radius_ws[i], point[0]+ radius_hs[i])
            # p3 = (point[1]- radius_hs[i], point[0]- radius_ws[i])
            # p3 = (point[1]+ radius_hs[i], point[0]+ radius_ws[i])
            disk_map = cv2.rectangle(disk_map, p1, p2, colors[i], -1)
            # disk_map = cv2.rectangle(disk_map, p3, p4, colors[i], -1)
    return disk_map


def ori_rectangle(points, radius_s, radius_l, shape, dis_allowed=3, final_mask=None):
    
    if final_mask is not None:
        disk_map = final_mask
    else:
        disk_map = np.zeros((shape[0], shape[1])).astype(np.uint8)
    # print(disk_map.shape, type(disk_map))

    for i in range(0, len(points)-1, 2):
        dis_x = np.abs(points[i][0] - points[i+1][0])
        dis_y = np.abs(points[i][1] - points[i+1][0])
        if dis_x <= dis_allowed and dis_y > dis_allowed:
            p1 = (points[i][1]- radius_s, points[i][0]- radius_l)
            p2 = (points[i][1]+ radius_s, points[i][0]+ radius_l)
            p3 = (points[i+1][1]- radius_s, points[i+1][0]- radius_l)
            p4 = (points[i+1][1]+ radius_s, points[i+1][0]+ radius_l)
        elif dis_x > dis_allowed and dis_y <= dis_allowed:
            p1 = (points[i][1]- radius_l, points[i][0]- radius_s)
            p2 = (points[i][1]+ radius_l, points[i][0]+ radius_s)
            p3 = (points[i+1][1]- radius_l, points[i+1][0]- radius_s)
            p4 = (points[i+1][1]+ radius_l, points[i+1][0]+ radius_s)
        elif dis_x <= dis_allowed and dis_y <= dis_allowed:
            print("Basically won't happen if candidate_len is big!")
            raise ValueError("Add new codes here!")
        elif dis_x > dis_allowed and dis_y > dis_allowed:
            # the best here is get the code - check_direction_change back
            # otherwise get bigger dis_x or dis_y
            # option 2 is use old generate_scribblles get rectangles // bbox
            if dis_x >= dis_y:
                p1 = (points[i][1]- radius_l, points[i][0]- radius_s)
                p2 = (points[i][1]+ radius_l, points[i][0]+ radius_s)
                p3 = (points[i+1][1]- radius_l, points[i+1][0]- radius_s)
                p4 = (points[i+1][1]+ radius_l, points[i+1][0]+ radius_s)
            else:
                p1 = (points[i][1]- radius_s, points[i][0]- radius_l)
                p2 = (points[i][1]+ radius_s, points[i][0]+ radius_l)
                p3 = (points[i+1][1]- radius_s, points[i+1][0]- radius_l)
                p4 = (points[i+1][1]+ radius_s, points[i+1][0]+ radius_l)


        disk_map = cv2.rectangle(disk_map, p1, p2, [255, 255, 255], -1)
        disk_map = cv2.rectangle(disk_map, p3, p4, [255, 255, 255], -1)
    return disk_map


def edge_scribbles_encoding(edge_graph, points, radius, shape, path_mode="shortest", need_num=2, final_mask=None):
    if final_mask is not None:
        disk_map = final_mask
    else:
        disk_map = np.zeros((shape[0], shape[1])).astype(np.uint8)

    for i in range(0, len(points)-1, 2):
        point1 = (points[i][0], points[i][1])
        point2 = (points[i+1][0], points[i+1][1])
        cps =  find_graph_path(edge_graph, point1, point2, shape, mode=path_mode, need_num=need_num)
        if len(cps) != 0 :
            if path_mode == "shortest":
                disk_map = scribbles_encoding_syn(cps[0], radius, shape, [point1, point2], final_mask=disk_map)
            elif path_mode == "all_paths":
                for c_path in sorted(cps):
                    disk_map = scribbles_encoding_syn(c_path, radius, shape, [point1, point2], final_mask=disk_map)
            else:
                raise ValueError
        else:
            disk_map = scribbles_encoding_synv2([point1, point2], radius, shape, final_mask=disk_map)        
        
    return disk_map


def ori_rectanglev1(points, radius, shape, fixed_len=None, one_side=False, final_mask=None):
    
    if final_mask is not None:
        disk_map = final_mask
    else:
        disk_map = np.zeros((shape[0], shape[1])).astype(np.uint8)
    # print(disk_map.shape, type(disk_map))

    for i in range(0, len(points)-1, 2):
        dis_x = np.abs(points[i][0] - points[i+1][0])
        dis_y = np.abs(points[i][1] - points[i+1][1])
        if dis_x >= dis_y:
            if fixed_len is not None:
                radius_o = fixed_len
            else:
                radius_o = int(dis_y/2)
            if one_side:
                if points[i][1] > points[i+1][1]:
                    p1 = (points[i][1]- radius_o, points[i][0]- radius)
                    p2 = (points[i][1] + radius, points[i][0]+ radius)
                    p3 = (points[i+1][1]- radius, points[i+1][0]- radius)
                    p4 = (points[i+1][1]+ radius_o, points[i+1][0]+ radius)
                else:
                    p1 = (points[i][1]- radius, points[i][0]- radius)
                    p2 = (points[i][1] + radius_o, points[i][0]+ radius)
                    p3 = (points[i+1][1]- radius_o, points[i+1][0]- radius)
                    p4 = (points[i+1][1]+ radius, points[i+1][0]+ radius)
            else:
                p1 = (points[i][1]- radius_o, points[i][0]- radius)
                p2 = (points[i][1]+ radius_o, points[i][0]+ radius)
                p3 = (points[i+1][1]- radius_o, points[i+1][0]- radius)
                p4 = (points[i+1][1]+ radius_o, points[i+1][0]+ radius)
        else:
            if fixed_len is not None:
                radius_o = fixed_len
            else:
                radius_o = int(dis_x/2)
            if one_side:
                if points[i][0] > points[i+1][0]:
                    p1 = (points[i][1]- radius, points[i][0]- radius_o)
                    p2 = (points[i][1] + radius, points[i][0]+ radius)
                    p3 = (points[i+1][1]- radius, points[i+1][0]- radius)
                    p4 = (points[i+1][1]+ radius, points[i+1][0]+ radius_o)
                else:
                    p1 = (points[i][1]- radius, points[i][0]- radius)
                    p2 = (points[i][1] + radius, points[i][0]+ radius_o)
                    p3 = (points[i+1][1]- radius, points[i+1][0]- radius_o)
                    p4 = (points[i+1][1]+ radius, points[i+1][0]+ radius)
            else:
                p1 = (points[i][1]- radius_o, points[i][0]- radius_o)
                p2 = (points[i][1]+ radius_o, points[i][0]+ radius_o)
                p3 = (points[i+1][1]- radius_o, points[i+1][0]- radius_o)
                p4 = (points[i+1][1]+ radius_o, points[i+1][0]+ radius_o)

        disk_map = cv2.rectangle(disk_map, p1, p2, [255, 255, 255], -1)
        disk_map = cv2.rectangle(disk_map, p3, p4, [255, 255, 255], -1)
    return disk_map
 
 
def ori_rectanglev2(points, radius, shape, fixed_len=None, one_side=False, final_mask=None):
    
    if final_mask is not None:
        disk_map = final_mask
    else:
        disk_map = np.zeros((shape[0], shape[1])).astype(np.uint8)
    # print(disk_map.shape, type(disk_map))
    
    radius_is = radius
    for i in range(0, len(points)-1, 2):
        dis_x = np.abs(points[i][0] - points[i+1][0])
        dis_y = np.abs(points[i][1] - points[i+1][1])
        if dis_x >= dis_y:
            if fixed_len is not None:
                radius_o = fixed_len
            else:
                radius_o = int(dis_y/2) + radius_is
                radius = int(dis_x/2) + radius_is
            if one_side:
                if points[i][1] > points[i+1][1]:
                    p1 = (points[i][1]- radius_o, points[i][0]- radius)
                    p2 = (points[i][1] + radius, points[i][0]+ radius)
                    p3 = (points[i+1][1]- radius, points[i+1][0]- radius)
                    p4 = (points[i+1][1]+ radius_o, points[i+1][0]+ radius)
                else:
                    p1 = (points[i][1]- radius, points[i][0]- radius)
                    p2 = (points[i][1] + radius_o, points[i][0]+ radius)
                    p3 = (points[i+1][1]- radius_o, points[i+1][0]- radius)
                    p4 = (points[i+1][1]+ radius, points[i+1][0]+ radius)
            else:
                p1 = (points[i][1]- radius_o, points[i][0]- radius)
                p2 = (points[i][1]+ radius_o, points[i][0]+ radius)
                p3 = (points[i+1][1]- radius_o, points[i+1][0]- radius)
                p4 = (points[i+1][1]+ radius_o, points[i+1][0]+ radius)
        else:
            if fixed_len is not None:
                radius_o = fixed_len
            else:
                radius_o = int(dis_x/2) + radius_is
                radius = int(dis_y/2) + radius_is
            if one_side:
                if points[i][0] > points[i+1][0]:
                    p1 = (points[i][1]- radius, points[i][0]- radius_o)
                    p2 = (points[i][1] + radius, points[i][0]+ radius)
                    p3 = (points[i+1][1]- radius, points[i+1][0]- radius)
                    p4 = (points[i+1][1]+ radius, points[i+1][0]+ radius_o)
                else:
                    p1 = (points[i][1]- radius, points[i][0]- radius)
                    p2 = (points[i][1] + radius, points[i][0]+ radius_o)
                    p3 = (points[i+1][1]- radius, points[i+1][0]- radius_o)
                    p4 = (points[i+1][1]+ radius, points[i+1][0]+ radius)
            else:
                p1 = (points[i][1]- radius_o, points[i][0]- radius_o)
                p2 = (points[i][1]+ radius_o, points[i][0]+ radius_o)
                p3 = (points[i+1][1]- radius_o, points[i+1][0]- radius_o)
                p4 = (points[i+1][1]+ radius_o, points[i+1][0]+ radius_o)

        disk_map = cv2.rectangle(disk_map, p1, p2, [255, 255, 255], -1)
        disk_map = cv2.rectangle(disk_map, p3, p4, [255, 255, 255], -1)
    return disk_map  
    
    
def ori_rectanglev3(points, radius, shape, add_radius=True, final_mask=None):
    
    if final_mask is not None:
        disk_map = final_mask
    else:
        disk_map = np.zeros((shape[0], shape[1])).astype(np.uint8)
    # print(disk_map.shape, type(disk_map))

    for i in range(0, len(points)-1, 2):
        if add_radius:
            p1 = (points[i][1]-radius, points[i][0]-radius)
            p2 = (points[i+1][1]+radius, points[i+1][0]+radius)
        else:
            p1 = (points[i][1], points[i][0])
            p2 = (points[i+1][1], points[i+1][0])
        disk_map = cv2.rectangle(disk_map, p1, p2, [255, 255, 255], -1)
    return disk_map
              


def draw_shape(mask, center_x, center_y, radius, height=None, color=(255, 255, 255), thickness=-1, draw_shape="circle", p1=None, p2=None):
    if draw_shape == "circle":
        mask = cv2.circle(mask, (center_x, center_y), radius+height, color, thickness)
    elif draw_shape == "diamond":
        width = height*2+radius
        height = height*2+radius
        # Define the four vertices of the diamond
        top = (center_x, center_y - height // 2)
        right = (center_x + width // 2, center_y)
        bottom = (center_x, center_y + height // 2)
        left = (center_x - width // 2, center_y)
        # top = (center_x- height // 2, center_y)
        # right = (center_x, center_y+ width // 2)
        # bottom = (center_x+ height // 2, center_y)
        # left = (center_x, center_y - width // 2)
        # Define the points to form a filled polygon (diamond)
        points = np.array([top, right, bottom, left], np.int32)

        # Reshape points for cv2.fillPoly
        points = points.reshape((-1, 1, 2))

        # Draw a filled diamond on the image
        mask = cv2.fillPoly(mask, [points], color)
    elif draw_shape == "oval":
        x1, y1 = p1
        x2, y2 = p2
        dx = np.abs(x1-x2)
        dy = np.abs(y1-y2)
        if dy > dx:
            h, w = dy + 1, height + radius # int(height/2 + radius)
        else:
            h, w = height + radius, dx + 1
        mask = cv2.ellipse(mask, (center_x, center_y), (w, h), 0, 0, 360, color, thickness)

    return mask


def geo_enconding(points, radius, shape, geo_type="circle", final_mask=None):
    assert len(points) % 2 == 0
        
    if final_mask is not None:
        s_mask = final_mask
    else:
        s_mask = np.zeros((shape[0], shape[1])).astype(np.uint8)
    
    areas = list()
    for i in range(0, len(points), 2):
        point1 = points[i]
        point2 = points[i+1]
        center_x, center_y, height = find_circle_properties(point1, point2)
        s_mask = draw_shape(s_mask, int(center_y), int(center_x), radius, height=int(height), draw_shape=geo_type, p1=point1, p2=point2)
    
    return s_mask


###########################################################   interactions  ################################################################################################

def generate_middle_point(inter_segment, random_range=(-1, 1)):
    mid_index = int(len(inter_segment)/2)
    random_index = random.randint(random_range[0], random_range[1])

    initial_center_circle = mid_index + random_index
    # print()
    # print(len(inter_segment), random_index, initial_center_circle) # inter_segment[initial_center_circle])
    # print(inter_segment[initial_center_circle])
    # print()
    icc_x = inter_segment[initial_center_circle][0]
    icc_y = inter_segment[initial_center_circle][1]

    random_change_x = random.randint(random_range[0], random_range[1])
    random_change_y = random.randint(random_range[0], random_range[1])
    final_center_circle = (icc_x+random_change_x, icc_y+random_change_y)
    # encoding_map = disk_encoding([final_center_circle], radius, pr_map_shape)
    # encoding_map = euclidean_distance_encoding([final_center_circle], pr_map_shape)
    # print(Counter(encoding_map.reshape(-1)))
    # print(icc_x, icc_y, final_center_circle)
    return final_center_circle


def find_circle_properties(point1, point2):
    """
    Find the center point and radius of the circle given two points.

    Args:
        point1 (tuple): The coordinates of the first point (x1, y1).
        point2 (tuple): The coordinates of the second point (x2, y2).

    Returns:
        tuple: A tuple containing the center point (x, y) and the radius of the circle.
    """
    x1, y1 = point1
    x2, y2 = point2

    # Calculate the midpoint between the two points
    center_x = (x1 + x2) / 2
    center_y = (y1 + y2) / 2

    # Calculate the distance (radius) between one of the points and the midpoint
    radius = math.sqrt((x2 - center_x)**2 + (y2 - center_y)**2)

    return (center_x, center_y, radius)


def build_edge_graph(edge_pro, threshold):
    graph_edge = nx.Graph()
    for i in range(edge_pro.shape[0]):
        for j in range(edge_pro.shape[1]):
            c_pixel = (i, j)
            if edge_pro[i, j] < threshold:
                continue
            else:
                c_neighbors = get_point_neighbors(c_pixel, edge_pro.shape, 8)
                for n in c_neighbors:
                    n = (n[0], n[1])
                    # print(edge_pro[n[0], n[1]])
                    if edge_pro[n[0], n[1]] < threshold:
                        continue
                    else:
                        # c_nodes = [(str(c_pixel), {"ep": edge_pro[i, j]}), (str(n), {"ep": edge_pro[n[0], n[1]]})]
                        c_nodes = [c_pixel, n]
                        # print(c_nodes)
                        graph_edge.add_nodes_from(c_nodes)
                        graph_edge.add_edges_from([(c_pixel, n), (n, c_pixel)])
                        # c_weight = 1 if n <= 3 else 1.4
                        # graph_edge.add_edge(c_pixel, n, weight=c_weight)
                        # graph_edge.add_edge(n, c_pixel, weight=c_weight)
    return graph_edge


def find_graph_path(edge_graph, point1, point2, shape, search_radius=2, mode="shortest", need_num=2):
    # all path ???
    # https://networkx.org/documentation/stable/reference/algorithms/shortest_paths.html#module-networkx.algorithms.shortest_paths.generic
    # point1 = (points[i][0], points[i][1])
    # point2 = (points[i+1][0], points[i+1][1])
    # p1_neighbors = get_point_neighbors(point1, shape, 8)
    shape = [shape[0], shape[1]]
    p1_neighbors = get_legal_neighbors(shape, point1, search_radius, edge_graph)
    p2_neighbors = get_legal_neighbors(shape, point2, search_radius, edge_graph)
    if len(p1_neighbors) == 0 or len(p2_neighbors) == 0:
        return []
    
    # print(point1, point2)
    # print(p1_neighbors, p2_neighbors)
    
    for item in p1_neighbors:
        for item_2 in p2_neighbors:
            if nx.has_path(edge_graph, item, item_2):
                if mode == "shortest":
                    points_list = nx.bidirectional_shortest_path(edge_graph, item, item_2)
                    return [points_list]
                elif mode == "all_paths":
                    points_list = list()
                    # too slow
                    # for path in sorted(nx.all_simple_edge_paths(edge_graph, item, item_2)):
                    c_path = nx.bidirectional_shortest_path(edge_graph, item, item_2)
                    points_list = [c_path]
                    edge_graph_copy = edge_graph.copy()
                    # print(len(c_path))
                    # print(c_path)
                    # print("-"*50)
                    # will add noise for some cases, and cannot always give the two most wantted edge,  ex. 2008_002712
                    for count in range(need_num-1):
                        try:
                            edge_graph_copy.remove_edge(c_path[0], c_path[1])
                            if len(c_path) >= 4:
                                edge_graph_copy.remove_edge(c_path[1], c_path[2])
                                edge_graph_copy.remove_edge(c_path[2], c_path[3])
                            c_path = nx.bidirectional_shortest_path(edge_graph_copy, item, item_2)
                            # print(len(c_path))
                            # print(c_path)
                            # print("-"*50)
                            points_list.append(c_path)
                        except nx.exception.NetworkXNoPath as e:
                            break
                    # print(name333)   
                    return points_list
            else:
                continue
    else:
        return []


def generate_random_point(inter_segment):
    random_index = random.randint(0, len(inter_segment)-1)
    icc_x = inter_segment[random_index][0]
    icc_y = inter_segment[random_index][1]
    random_change_x = random.randint(-1, 1)
    random_change_y = random.randint(-1, 1)
    final_center_circle = (icc_x+random_change_x, icc_y+random_change_y)
    # encoding_map = disk_encoding([final_center_circle], radius, pr_map_shape)
    return final_center_circle


# or check other connected candidate, or record direction change positions
def generate_multiple_points(inter_segment, random_range=(-1, 1), points_num=3):
    points_list = generate_two_points(inter_segment, random_range=random_range)
    middle_point = generate_middle_point(inter_segment, random_range=random_range)
    points_list.append(middle_point)
    # too many points are useless unless direction changes
    return points_list
    

def generate_two_points(inter_segment, random_range=(-1, 1)):
    start_index = 0
    # for now don't let it exceed the segment range
    random_index = random.randint(0, random_range[1])
    
    initial_center_circle = start_index+ random_index
    icc_x = inter_segment[initial_center_circle][0]
    icc_y = inter_segment[initial_center_circle][1]

    random_change_x = random.randint(-1, 1)
    random_change_y = random.randint(-1, 1)
    final_center_circle = (icc_x+random_change_x, icc_y+random_change_y)

    end_index = len(inter_segment) - 1
    # for now don't let it exceed the segment range
    random_index = random.randint(random_range[0], 0)
    
    initial_center_circle_e = end_index + random_index
    icc_x_e = inter_segment[initial_center_circle_e][0]
    icc_y_e = inter_segment[initial_center_circle_e][1]
    final_center_circle_e = (icc_x_e+random_change_x, icc_y_e+random_change_y)

    return [final_center_circle, final_center_circle_e]


def calculate_slope_degrees(x1, y1, x2, y2):
    if x1 == x2:
        return None
    radians = math.atan2(y2 - y1, x2 - x1)
    degrees = math.degrees(radians)
    return degrees

def is_vertical_slope(slope, threshold=60):
    return abs(slope) >= threshold

def is_horizontal_slope(slope, threshold=30):
    return abs(slope) <= threshold


def extend_line(point, line_slope, extra_len, is_end=False):
    extend_segment = list()
    x_add = 0
    y_add = 0
    if line_slope is None or is_vertical_slope(line_slope):
        if is_end:
            y_add = 1
        else:
            y_add = -1
    elif line_slope == 0 or is_horizontal_slope(line_slope):
        if is_end:
            x_add = 1
        else:
            x_add = -1   
    else:
        # line_slope near +- 1  
        if is_end:
            x_add, y_add = 1, 1
        else:
            x_add, y_add = -1, -1
    
    c_x0, c_y0 = point    
    for i in range(0, extra_len):
        c_x0, c_y0 = (c_x0+x_add, c_y0+y_add)
        extend_segment.append((c_x0, c_y0))
    return extend_segment
    
    
def generate_scribbles_v2(inter_segment, random_range, keep_random_change=False):
    points_return = list()
    x1, y1 = inter_segment[0]    
    x2, y2 = inter_segment[-1] 
    slope_degrees = calculate_slope_degrees(x1, y1, x2, y2)
    
    
    random_index = random.randint(random_range[0], random_range[1])
    if random_index < 0:            
        extra_len = np.abs(random_index)
        extend_segment = extend_line((x1, y1), slope_degrees, extra_len, is_end=False)
        points_return.extend(extend_segment)
        start_index = 0
      
    else:
        start_index = 0 + random_index
        # icc_x = inter_segment[start_index][0]
        # icc_y = inter_segment[start_index][1]


    random_index = random.randint(random_range[0], random_range[1])
    if random_index < 0:            
        extra_len = np.abs(random_index)
        extend_segment = extend_line((x2, y2), slope_degrees, extra_len, is_end=True)
        # points_return.extend(extend_segment)
        end_index = len(inter_segment)
      
    else:
        end_index = len(inter_segment) - random_index
  
    
    
    random_change_x = random.randint(random_range[0], random_range[1])
    random_change_y = random.randint(random_range[0], random_range[1])
    
    for i in range(start_index, end_index):
        if keep_random_change:
            c_point = (inter_segment[i][0]+random_change_x, inter_segment[i][1]+random_change_y)
        else:
            random_change_x = random.randint(random_range[0], random_range[1])
            random_change_y = random.randint(random_range[0], random_range[1])
            # print(random_change_x, random_change_y)
            c_point = (inter_segment[i][0]+random_change_x, inter_segment[i][1]+random_change_y)
        points_return.append(c_point)
    
    # add end extend
    if random_index < 0:     
        points_return.extend(extend_segment)  

    return points_return     
    

def random_range_direction(random_range, line_slope):
    range_coors = "xy"
    if line_slope is None or is_vertical_slope(line_slope):
        range_coors = "y"
    elif line_slope == 0 or is_horizontal_slope(line_slope):
        range_coors = "x"
    else:
        range_coors = "xy"
    return range_coors

        
def generate_scribbles_v3(inter_segment, random_range, keep_random_change=False):
    points_return = list()
    x1, y1 = inter_segment[0]    
    x2, y2 = inter_segment[-1] 
    slope_degrees = calculate_slope_degrees(x1, y1, x2, y2)
    
    random_index = random.randint(random_range[0], random_range[1])
    if random_index < 0:            
        extra_len = np.abs(random_index)
        extend_segment = extend_line((x1, y1), slope_degrees, extra_len, is_end=False)
        points_return.extend(extend_segment)
        start_index = 0
      
    else:
        start_index = 0 + random_index
        # icc_x = inter_segment[start_index][0]
        # icc_y = inter_segment[start_index][1]


    random_index = random.randint(random_range[0], random_range[1])
    if random_index < 0:            
        extra_len = np.abs(random_index)
        extend_segment = extend_line((x2, y2), slope_degrees, extra_len, is_end=True)
        # points_return.extend(extend_segment)
        end_index = len(inter_segment)
      
    else:
        end_index = len(inter_segment) - random_index
      
    
    random_coors = random_range_direction(random_range, slope_degrees)

    for i in range(start_index, end_index):
        if random_coors=="x":
            random_change_x = random.randint(random_range[0], random_range[1])
            random_change_y = 0
        elif random_coors=="y":
            random_change_y = random.randint(random_range[0], random_range[1])
            random_change_x = 0        
        else:
            random_change_x = random.randint(random_range[0], random_range[1])
            random_change_y = random.randint(random_range[0], random_range[1])
        
        c_point = (inter_segment[i][0]+random_change_x, inter_segment[i][1]+random_change_y)
        points_return.append(c_point)
    
    # add end extend
    if random_index < 0:     
        points_return.extend(extend_segment)  

    return points_return       
    
def get_random_changes(random_range, random_coors, back_random=-2):
    if random_coors=="x":
        random_change_x = random.randint(random_range[0], random_range[1])
        random_change_y = 0
    elif random_coors=="y":
        random_change_y = random.randint(random_range[0], random_range[1])
        random_change_x = 0        
    else:
        # don't go back far, original should not be (-1, 1)
        random_change_x = random.randint(back_random, random_range[1])
        random_change_y = random.randint(back_random, random_range[1])
    return random_change_x, random_change_y


def ge_bresenham_line(start_point, next_point, points_return, points_pair):
    # two bresenham_line2
    line_1 = bresenham_line2(start_point[0], start_point[1], next_point[0], next_point[1])
    points_return.extend(line_1)

    # (will get two small lines) if not connected
    if line_1[-1][0] != next_point[0] and (line_1[-1][1] != next_point[1]):
        line_2 = bresenham_line2(line_1[-1][0], line_1[-1][1], next_point[0], next_point[1])
        # line_2 = bresenham_line2(next_point[0], next_point[1], inter_segment[end_index][0], nter_segment[end_index][1])
        points_return.extend(line_2)  
        if line_2[-1][0] != next_point[0] and (line_2[-1][1] != next_point[1]):
            print("Two judge falled! use cv2")
            points_pair.extend([line_2[-1], next_point]) 

    return points_return, points_pair


def generate_scribbles_v4(inter_segment, random_range, keep_random_change=False, count_change=10, use_cv2=True):
    """
    
    if use_cv2, we won't get the line points between start and end
    At every count_change , circle center will go through one gt pixel?

    """
    points_return = list()
    points_pair = list()
    x1, y1 = inter_segment[0]    
    x2, y2 = inter_segment[-1] 
    slope_degrees = calculate_slope_degrees(x1, y1, x2, y2)
    random_coors = random_range_direction(random_range, slope_degrees)
    random_change_x, random_change_y = get_random_changes(random_range, random_coors)
    if random_change_x == 0 and random_change_y ==0:
        random_change_x, random_change_y = get_random_changes(random_range, random_coors)


    random_index = random.randint(random_range[0], random_range[1])
    if random_index < 0:            
        extra_len = np.abs(random_index)
        extend_segment = extend_line((x1, y1), slope_degrees, extra_len, is_end=False)

        # points_return.extend(extend_segment)
        if keep_random_change:
            for p in extend_segment:
                c_point = (p[0]+random_change_x, p[1]+random_change_y)
                points_return.append(c_point)
        else:
            c_point = (extend_segment[-1][0]+random_change_x, inter_segment[-1][1]+random_change_y)
            if use_cv2:
                points_pair.extend([c_point, (x1, y1)]) 
            else:
                points_return, points_pair = ge_bresenham_line(c_point, (x1, y1), points_return, points_pair)

        start_index = 0
      
    else:
        start_index = 0 + random_index


    random_index = random.randint(random_range[0], random_range[1])
    if random_index < 0:            
        extra_len = np.abs(random_index)
        extend_segment = extend_line((x2, y2), slope_degrees, extra_len, is_end=True)
        end_index = len(inter_segment)

        # points_return.extend(extend_segment)
        if keep_random_change:
            for p in extend_segment:
                c_point = (p[0]+random_change_x, p[1]+random_change_y)
                points_return.append(c_point)
        else:
            random_change_x, random_change_y = get_random_changes(random_range, random_coors)
            c_point = (extend_segment[-1][0]+random_change_x, inter_segment[-1][1]+random_change_y)
            if use_cv2:
                points_pair.extend([(x2, y2), c_point]) 
            else:
                points_return, points_pair = ge_bresenham_line((x2, y2), c_point, points_return, points_pair)
      
    else:
        end_index = len(inter_segment) - random_index
      

    if keep_random_change:
        # same as the simulation which uses two points to generate one scribble, 
        # more stabble for lines but not so good for the curves.
        for i in range(start_index, end_index):
            c_point = (inter_segment[i][0]+random_change_x, inter_segment[i][1]+random_change_y)
            points_return.append(c_point)
    
    else:
        # simulate continous connected small lines 
        # by bresenham_line2
        # or cv2.line (cv2.line will get one small line without circle centers)
        
        start_point = inter_segment[start_index]  
        end_index = end_index-1 if random_index <= 0 else end_index
        end_point = inter_segment[end_index-1]        

        for i in range(start_index + count_change, end_index, count_change):            
            next_x, next_y = get_random_changes(random_range, random_coors)
            next_point = (inter_segment[i][0]+next_x, inter_segment[i][1]+next_y)

            if use_cv2:
                try:
                    points_pair.extend([next_point, end_point])
                except UnboundLocalError:
                    points_pair.extend([start_point, end_point])
            else:
                points_return, points_pair = ge_bresenham_line(start_point, next_point, points_return, points_pair)
            
            start_point = next_point  

        # case: next_point != end_point
        if use_cv2:
            points_pair.extend([next_point, end_point]) 
        else:
            points_return, points_pair = ge_bresenham_line(next_point, end_point, points_return, points_pair)

    # # add end extend
    # if random_index < 0:     
    #     points_return.extend(extend_segment)       

    return points_return, points_pair   

def is_curve(start_point, middle_point, end_point, angle_threshold_degrees=30):
    # Calculate vectors from start to middle and middle to end points
    vector1 = np.array(middle_point) - np.array(start_point)
    vector2 = np.array(end_point) - np.array(middle_point)

    # Calculate the angle between the vectors using dot product
    dot_product = np.dot(vector1, vector2)
    magnitude_product = np.linalg.norm(vector1) * np.linalg.norm(vector2)

    # Ensure the denominator is not zero
    if magnitude_product != 0:
        cosine_angle = dot_product / magnitude_product
        # Calculate the angle in radians
        angle_radians = np.arccos(cosine_angle)

        # Convert the angle to degrees
        angle_degrees = np.degrees(angle_radians)

        # Compare the angle to the threshold (30 degrees)
        return angle_degrees <= angle_threshold_degrees

    # If the denominator is zero, it's a straight line (low curvature)
    return True  # Within threshold

def is_curve_v2(segment_points, curvature_threshold_degrees=30):
    # Ensure there are at least 3 points for curvature calculation
    if len(segment_points) < 3:
        return False  # Not enough points for curvature calculation

    # Calculate the angles at each point in the segment
    curvatures = []
    for i in range(1, len(segment_points) - 1):
        # Calculate vectors from the neighboring points
        vector1 = np.array(segment_points[i-1]) - np.array(segment_points[i])
        vector2 = np.array(segment_points[i+1]) - np.array(segment_points[i])

        # Calculate the angle between the vectors using dot product
        dot_product = np.dot(vector1, vector2)
        magnitude_product = np.linalg.norm(vector1) * np.linalg.norm(vector2)

        # Ensure the denominator is not zero
        if magnitude_product != 0:
            cosine_angle = dot_product / magnitude_product
            # Calculate the angle in radians
            angle_radians = np.arccos(cosine_angle)

            # Convert the angle to degrees
            angle_degrees = np.degrees(angle_radians)

            # Calculate the curvature as the reciprocal of the angle
            curvature = 1 / angle_degrees
            curvatures.append(curvature)

    # Check if any curvature exceeds the threshold
    return any(curvature > 1 / curvature_threshold_degrees)


def generate_scribbles_v4mix(inter_segment, random_range, keep_random_change=False, count_change=10, use_cv2=True, angle_threshold_degrees=30):
    p1 = inter_segment[0]
    p2 = inter_segment[int(len(inter_segment)/2)]
    p3 = inter_segment[-1]

    # slope_degree1 = calculate_slope_degrees(x1, y1, x2, y2)
    # slope_degree2 = calculate_slope_degrees(x2, y2, x3, y3)
    # # diff_angle = np.abs(slope_degree1-slope_degree2)
    # print(slope_degree1, slope_degree2)
    # diff = ((slope_degree2 - slope_degree1 + 180) % 360) - 180
    # if np.abs(diff) > 30:
    
    # not so accurate, may be need more line segment for judge
    if is_curve(p1, p2, p3, angle_threshold_degrees):
        keep_random_change = False
    else:
        keep_random_change = True
    
    points_return, points_pair = generate_scribbles_v4(inter_segment, random_range, keep_random_change=keep_random_change, 
                                                        count_change=count_change, use_cv2=use_cv2)
    return points_return, points_pair 


###########################################################   vis functions  #################################################################################################

def vis_np_mask(vis_img, p_mask, n_mask, store_path, p_points=[], n_points=[]):
    p_mask = p_mask * [1, 1, 1]
    n_mask = n_mask * [1, 1, 1]
    color_points = list()
    for i in range(vis_img.shape[0]):
        for j in range(vis_img.shape[1]):
            if p_mask[i, j, :].tolist() != [0, 0, 0]:
                vis_img[i, j, :] = [0, 0, 255]
            if n_mask[i, j, :].tolist() != [0, 0, 0]:
                vis_img[i, j, :] = [255, 0, 0]
    
    color_points.extend(p_points)  
    color_points.extend(n_points)    
    for i in color_points:
        try:
            vis_img[i[0], i[1], :] = [0, 255, 0]
        except:
            continue                           
    cv2.imwrite(store_path+"_fnfp.png", vis_img)
    # cv2.imwrite("./crop_examples/"+img_name+"_gt_crop.png", gt_crop*255)
    # cv2.imwrite(store_path+"_p_mask.png", p_mask)
    # cv2.imwrite(store_path+"_n_mask.png", n_mask)
    
    
def vis_inter(vis_img, p_mask, n_mask, store_path):
    mean = [0.485, 0.456, 0.406]  # [0.780, 0.771, 0.771]
    std = [0.229, 0.224, 0.225]  # [0.203, 0.206, 0.217]
    vis_img = (vis_img * std + mean) * 255
    p_mask = p_mask * [1, 1, 1]
    n_mask = n_mask * [1, 1, 1]
    for i in range(vis_img.shape[0]):
        for j in range(vis_img.shape[1]):
            if p_mask[i, j, :].tolist() != [0, 0, 0]:
                vis_img[i, j, :] = [0, 0, 255]
            if n_mask[i, j, :].tolist() != [0, 0, 0]:
                vis_img[i, j, :] = [255, 0, 0]
    cv2.imwrite(store_path+"_ifnfp.png", vis_img)  
    


###########################################################   unused functions #################################################################################

# from isutils.cythonutils import get_dist_maps
# from geprmap import ob_nmst, mb_nmst
# from cythonutils import get_dist_maps
    

class DistMaps(nn.Module):
    def __init__(self, norm_radius, spatial_scale=1.0, cpu_mode=False, use_disks=False):
        super(DistMaps, self).__init__()
        self.spatial_scale = spatial_scale
        self.norm_radius = norm_radius
        self.cpu_mode = cpu_mode
        self.use_disks = use_disks
        if self.cpu_mode:
            # from isegm.utils.cython import get_dist_maps
            self._get_dist_maps = get_dist_maps

    def get_coord_features(self, points, batchsize, rows, cols):
        if self.cpu_mode:
            coords = []
            for i in range(batchsize):
                norm_delimeter = 1.0 if self.use_disks else self.spatial_scale * self.norm_radius
                coords.append(self._get_dist_maps(points[i].cpu().float().numpy(), rows, cols,
                                                  norm_delimeter))
            coords = torch.from_numpy(np.stack(coords, axis=0)).to(points.device).float()
        else:
            num_points = points.shape[1] // 2
            points = points.view(-1, points.size(2))
            points, points_order = torch.split(points, [2, 1], dim=1)

            invalid_points = torch.max(points, dim=1, keepdim=False)[0] < 0
            row_array = torch.arange(start=0, end=rows, step=1, dtype=torch.float32, device=points.device)
            col_array = torch.arange(start=0, end=cols, step=1, dtype=torch.float32, device=points.device)

            coord_rows, coord_cols = torch.meshgrid(row_array, col_array)
            coords = torch.stack((coord_rows, coord_cols), dim=0).unsqueeze(0).repeat(points.size(0), 1, 1, 1)

            add_xy = (points * self.spatial_scale).view(points.size(0), points.size(1), 1, 1)
            coords.add_(-add_xy)
            if not self.use_disks:
                coords.div_(self.norm_radius * self.spatial_scale)
            coords.mul_(coords)

            coords[:, 0] += coords[:, 1]
            coords = coords[:, :1]

            coords[invalid_points, :, :, :] = 1e6

            coords = coords.view(-1, num_points, 1, rows, cols)
            coords = coords.min(dim=1)[0]  # -> (bs * num_masks * 2) x 1 x h x w
            coords = coords.view(-1, 2, rows, cols)

        if self.use_disks:
            coords = (coords <= (self.norm_radius * self.spatial_scale) ** 2).float()
        else:
            coords.sqrt_().mul_(2).tanh_()

        return coords

    def forward(self, x, coords):
        return self.get_coord_features(coords, x.shape[0], x.shape[2], x.shape[3])


def check_direction_change(segment, new_point, angle_threshold=45):
    # 2, 3, 4
    if len(segment) <= 3:
        return 1
    
    # should check twice for the jugged line???
    # segment_p1 = segment[0]
    # segment_p2 = segment[1]
    initial_angle = get_line_angle(segment[0], segment[1])
    second_angle = get_line_angle(segment[0], segment[2])
    new_angle_p = get_line_angle(segment[-2], segment[-1])
    new_angle = get_line_angle(segment[0], new_point)
    if (np.abs(new_angle - initial_angle) >= angle_threshold) \
        and (np.abs(new_angle_p-new_angle) >= angle_threshold):
        return 0
    else:
        return 1


def get_line_angle(point1, point2):
    if point2[1]-point1[1] == 0:
        return -90
    if point2[0]-point1[0] == 0:
        return 0
        
    x = math.atan2(point2[1]-point1[1], point2[0]-point1[0])
    x= x*180/np.pi
    # print(x)
    return x


def get_point_distance(point1, point2):
    distance_points = np.sqrt(np.power((point1[0]-point2[0]), 2) + np.power((point1[1]-point2[1]), 2))
    return distance_points


# def gaussian_distance_encoding(points, shape):
#     # not working
#     mask=np.zeros((shape[0], shape[1])).astype(np.uint8)
#     mask[points[0][0], points[0][1]] = 1
#
#     max_dist=255
#     points_mask_dist = distance_transform_edt(1-mask)
#     points_mask_dist = np.minimum(points_mask_dist, max_dist)
#     points_mask_dist = points_mask_dist*255
#     return points_mask_dist

# def get_points_mask(size, points):
#     mask=np.zeros(size[::-1]).astype(np.uint8)
#     if len(points)!=0:
#         points=np.array(points)
#         mask[points[:,1], points[:,0]]=1
#     return mask



def euclidean_distance_encoding(points, shape):
    #print points.shape[1];
    tmpDist= 255 * np.ones((shape[0],shape[1]))
    [mx,my]= np.meshgrid(np.arange(shape[1]),np.arange(shape[0]))      
    for i in range(len(points)):
        tmpX = mx-points[i][1]
        tmpY = my-points[i][0]
        tmpDist = np.minimum(tmpDist,np.sqrt(np.square(tmpX)+np.square(tmpY)))
    tmpRst = np.array(tmpDist)
    tmpRst[np.where(tmpRst > 255)] = 255
    return tmpRst
 

def get_random_sample_click(binary_mask, radius, min_distance=30):
    # binary_mask = ((np.array(gt_map[:, :, 0]) > 0 ) * 1).reshape(1080, 1080, 1)
    radius = radius + 1
    negative_choices = list()
    for i in range(radius, binary_mask.shape[0]-radius, radius*2):
        for j in range(radius, binary_mask.shape[1]-radius, radius*2):
            area_count = None
            xmin = i - radius 
            xmax = i + radius  +1
            ymin = j - radius  
            ymax = j +radius +1 
            area_count = np.sum(binary_mask[xmin:xmax, ymin:ymax, :], axis=(0, 1))[0] 
            if area_count == 0: #  and (len(negtive_choices) == 0 or ):
                negative_choices.append((i, j))
          
    return negative_choices        
           
def hand_map():   
    return 



if __name__ == '__main__':
    
    pr_map = cv2.imread("./data/source/mexample.png") # ("./bpynmst7_pr_gt.png")  # ("./mexample.png")
    p_candidate_ef, n_candidate_ef = split_edge_frament(pr_map[0:320, 640:960])
    cv2.imwrite("crop.png", pr_map[0:320, 640:960])
    p_ef_s = get_soreted_edgeframent(p_candidate_ef)
    print(len(p_ef_s[0]), len(p_ef_s[-1]))
    p_mask = generate_two_points(p_ef_s[-1])
    print(p_mask)
    n_mask = generate_two_points(n_candidate_ef[1])
    p_mask = np.array([[p_mask[0][0], p_mask[0][1]], [n_mask[0][0], n_mask[0][1]]]).astype(np.float32)
    dist_map = get_dist_maps(p_mask, 320, 320, 5)
    print(dist_map.shape)
    cv2.imwrite("m_p_i2.png", np.transpose(dist_map, (1,2, 0))[:, :, 1])
    cv2.imwrite("m_n_i2.png", np.transpose(dist_map, (1,2, 0))[:, :, 0])
