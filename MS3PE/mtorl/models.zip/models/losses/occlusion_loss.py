import torch
from mtorl.models.losses.cceloss import CCELoss, CCELossMask
from mtorl.models.losses.oorloss import OORLoss
from mtorl.models.losses.loss_p2orm import AttentionLoss, FocalLoss, FocalLossV2


class OcclousionLoss(torch.nn.Module):

    def __init__(self,
                 boundary_weights=[0.5, 0.5, 0.5, 0.5, 1.1, 1.2],
                 boundary_lambda=1.0,
                 orientation_weight=1.1):
        super().__init__()

        self.boundary_weights = boundary_weights
        self.orientation_weight = orientation_weight

        self.b_loss = CCELoss(b_lambda=boundary_lambda, reduction='mean')
        self.o_loss = OORLoss(reduction='mean')

    def forward(self, boundary_x_list, orientation_x, labels):
      
        boundary_y, orientation_y = labels[:, 0], labels[:, 1]
        # print(labels.shape)
        # print(boundary_y.shape)
        # print(boundary_x_list[0].shape)
        # print(len(boundary_x_list), len(self.boundary_weights))
        b_blance_pos = float(torch.sum(boundary_y == 1)) / float(torch.numel(boundary_y))
        b_blance_neg = float(torch.sum(boundary_y == 0)) / float(torch.numel(boundary_y))
        b_blance = [b_blance_pos, b_blance_neg]

        assert len(boundary_x_list) == len(self.boundary_weights)

        boundary_losses = [b_w * self.b_loss(b_x, boundary_y, b_blance)
                           for b_x, b_w in zip(boundary_x_list, self.boundary_weights)]
        # orientation_loss = self.orientation_weight * self.o_loss(orientation_x, orientation_y, boundary_y)

        return boundary_losses, boundary_losses[-1] # orientation_loss
        

# unused   
class OcclousionLossMask(torch.nn.Module):

    def __init__(self,
                 boundary_weights=[0.5, 0.5, 0.5, 0.5, 1.1, 1.2],
                 boundary_lambda=1.0,
                 orientation_weight=1.1,
                 mask_loss_weight=0.2):
        super().__init__()

        self.boundary_weights = boundary_weights
        self.orientation_weight = orientation_weight
        self.mask_loss_weights = [item*mask_loss_weight for item in boundary_weights]

        self.b_loss = CCELoss(b_lambda=boundary_lambda, reduction='mean')
        self.b_loss_mask = CCELossMask(b_lambda=boundary_lambda, reduction='mean')
        self.o_loss = OORLoss(reduction='mean')

    def forward(self, boundary_x_list, orientation_x, labels, mask):
      
        boundary_y, orientation_y = labels[:, 0], labels[:, 1]
        # print(labels.shape)
        # print(boundary_y.shape)
        # print(boundary_x_list[0].shape)
        # print(len(boundary_x_list), len(self.boundary_weights))
        b_blance_pos = float(torch.sum(boundary_y == 1)) / float(torch.numel(boundary_y))
        b_blance_neg = float(torch.sum(boundary_y == 0)) / float(torch.numel(boundary_y))
        b_blance = [b_blance_pos, b_blance_neg]

        assert len(boundary_x_list) == len(self.boundary_weights)

        boundary_losses = [b_w * self.b_loss(b_x, boundary_y, b_blance)
                           for b_x, b_w in zip(boundary_x_list, self.boundary_weights)]
        boundary_losses_mask = [b_w * self.b_loss_mask(b_x, boundary_y, b_blance, mask)
                           for b_x, b_w in zip(boundary_x_list, self.mask_loss_weights)]

        # orientation_loss = self.orientation_weight * self.o_loss(orientation_x, orientation_y, boundary_y)

        return boundary_losses+boundary_losses_mask, boundary_losses[-1] # orientation_loss
        
        
        
class OcclousionFLLoss(torch.nn.Module):

    def __init__(self,
                 boundary_weights=[0.5, 0.5, 0.5, 0.5, 1.1, 1.2],
                 boundary_lambda=1.0,
                 orientation_weight=0.4):
        super().__init__()

        self.boundary_weights = boundary_weights
        self.orientation_weight = orientation_weight

        self.b_loss = CCELoss(b_lambda=boundary_lambda, reduction='mean')
        self.o_loss = FocalLossV2()

    def forward(self, boundary_x_list, orientation_x, labels):
      
        boundary_y, orientation_y = labels[:, 0], labels[:, 1]

        b_blance_pos = float(torch.sum(boundary_y == 1)) / float(torch.numel(boundary_y))
        b_blance_neg = float(torch.sum(boundary_y == 0)) / float(torch.numel(boundary_y))
        b_blance = [b_blance_pos, b_blance_neg]

        assert len(boundary_x_list) == len(self.boundary_weights)

        boundary_losses = [b_w * self.b_loss(b_x, boundary_y, b_blance)
                           for b_x, b_w in zip(boundary_x_list, self.boundary_weights)]
        orientation_loss = self.orientation_weight * self.o_loss(orientation_x, boundary_y)

        return boundary_losses, orientation_loss  
        
        
class FLLoss(torch.nn.Module):

    def __init__(self,
                 boundary_weights=[0.5, 0.5, 0.5, 0.5, 1.1, 1.2],
                 boundary_lambda=1.0,
                 orientation_weight=0.4):
        super().__init__()

        self.boundary_weights = boundary_weights
        self.orientation_weight = orientation_weight

        self.b_loss = FocalLossV2()
        self.o_loss = FocalLossV2()

    def forward(self, boundary_x_list, orientation_x, labels):
      
        boundary_y, orientation_y = labels[:, 0], labels[:, 1]

        assert len(boundary_x_list) == len(self.boundary_weights)

        boundary_losses = [b_w * self.b_loss(b_x, boundary_y)
                           for b_x, b_w in zip(boundary_x_list, self.boundary_weights)]
        orientation_loss = self.orientation_weight * self.o_loss(orientation_x, boundary_y)

        return boundary_losses, orientation_loss                 


# from mtorl.models.losses.isloss import NormalizedFocalLossSigmoid as NFL

# class NormalizedFocalLossSigmoid(nn.Module):
#     def __init__(self, axis=-1, alpha=0.25, gamma=2, max_mult=-1, eps=1e-12,
#                  from_sigmoid=False, detach_delimeter=True,
#                  batch_axis=0, weight=None, size_average=True,
#                  ignore_label=-1):
#         super(NormalizedFocalLossSigmoid, self).__init__()
#         self._axis = axis
#         self._alpha = alpha
#         self._gamma = gamma
#         self._ignore_label = ignore_label
#         self._weight = weight if weight is not None else 1.0
#         self._batch_axis = batch_axis

#         self._from_logits = from_sigmoid
#         self._eps = eps
#         self._size_average = size_average
#         self._detach_delimeter = detach_delimeter
#         self._max_mult = max_mult
#         self._k_sum = 0
#         self._m_max = 0

#     def forward(self, pred, label):
#         one_hot = label > 0.5
#         sample_weight = label != self._ignore_label

#         if not self._from_logits:
#             pred = torch.sigmoid(pred)
            
#         # pred = torch.clamp(pred, self._eps, 1-self._eps)  # according to caffe code
#         alpha = torch.where(one_hot, self._alpha * sample_weight, (1 - self._alpha) * sample_weight)
#         pt = torch.where(sample_weight, 1.0 - torch.abs(label - pred), torch.ones_like(pred))
#         # print(pt)
#         beta = (1 - pt) ** self._gamma

#         sw_sum = torch.sum(sample_weight, dim=(-2, -1), keepdim=True)
#         beta_sum = torch.sum(beta, dim=(-2, -1), keepdim=True)
#         mult = sw_sum / (beta_sum + self._eps)
#         if self._detach_delimeter:
#             mult = mult.detach()
#         beta = beta * mult
#         if self._max_mult > 0:
#             beta = torch.clamp_max(beta, self._max_mult)

#         with torch.no_grad():
#             ignore_area = torch.sum(label == self._ignore_label, dim=tuple(range(1, label.dim()))).cpu().numpy()
#             sample_mult = torch.mean(mult, dim=tuple(range(1, mult.dim()))).cpu().numpy()
#             if np.any(ignore_area == 0):
#                 self._k_sum = 0.9 * self._k_sum + 0.1 * sample_mult[ignore_area == 0].mean()

#                 beta_pmax, _ = torch.flatten(beta, start_dim=1).max(dim=1)
#                 beta_pmax = beta_pmax.mean().item()
#                 self._m_max = 0.8 * self._m_max + 0.2 * beta_pmax

#         loss = -alpha * beta * torch.log(torch.min(pt + self._eps, torch.ones(1, dtype=torch.float).to(pt.device)))
#         loss = self._weight * (loss * sample_weight)
        
#         # loss = torch.clamp(loss, self._eps, 1-self._eps)  # according to caffe code
#         loss_nan_map = torch.isnan(loss)
#         loss[loss_nan_map] = 0.0

#         if self._size_average:
#             bsum = torch.sum(sample_weight, dim=misc.get_dims_with_exclusion(sample_weight.dim(), self._batch_axis))
#             loss = torch.sum(loss, dim=misc.get_dims_with_exclusion(loss.dim(), self._batch_axis)) / (bsum + self._eps)
            
#         else:
#             loss = torch.sum(loss, dim=misc.get_dims_with_exclusion(loss.dim(), self._batch_axis))

#         return loss

#     def log_states(self, sw, name, global_step):
#         sw.add_scalar(tag=name + '_k', value=self._k_sum, global_step=global_step)
#         sw.add_scalar(tag=name + '_m', value=self._m_max, global_step=global_step)


# class SigmoidBinaryCrossEntropyLoss(nn.Module):
#     def __init__(self, from_sigmoid=False, weight=None, batch_axis=0, ignore_label=-1):
#         super(SigmoidBinaryCrossEntropyLoss, self).__init__()
#         self._from_sigmoid = from_sigmoid
#         self._ignore_label = ignore_label
#         self._weight = weight if weight is not None else 1.0
#         self._batch_axis = batch_axis

#     def forward(self, pred, label):
#         label = label.view(pred.size())
#         sample_weight = label != self._ignore_label
#         label = torch.where(sample_weight, label, torch.zeros_like(label))

#         if not self._from_sigmoid:
#             loss = torch.relu(pred) - pred * label + F.softplus(-torch.abs(pred))
#         else:
#             eps = 1e-12
#             loss = -(torch.log(pred + eps) * label
#                      + torch.log(1. - pred + eps) * (1. - label))

#         loss = self._weight * (loss * sample_weight)
#         # loss = torch.clamp(loss, self._eps, 1-self._eps)  # according to caffe code
#         # loss_nan_map = torch.isnan(loss)
#         # loss[loss_nan_map] = 0.0
#         return torch.mean(loss, dim=misc.get_dims_with_exclusion(loss.dim(), self._batch_axis))


# class OcclousionLoss(torch.nn.Module):

#     def __init__(self,
#                  boundary_weights=[0.5, 0.5, 0.5, 0.5, 1.1, 1.2],
#                  boundary_lambda=1.0,
#                  orientation_weight=1.1):
#         super().__init__()

#         self.boundary_weights = boundary_weights
#         self.orientation_weight = orientation_weight

#         self.b_loss = NFL(alpha=0.5, gamma=2) 
#         self.o_loss = OORLoss(reduction='mean')

#     def forward(self, boundary_x_list, orientation_x, labels):
      
#         boundary_y, orientation_y = labels[:, 0], labels[:, 1]
#         b_blance_pos = float(torch.sum(boundary_y == 1)) / float(torch.numel(boundary_y))
#         b_blance_neg = float(torch.sum(boundary_y == 0)) / float(torch.numel(boundary_y))
#         b_blance = [b_blance_pos, b_blance_neg]

#         assert len(boundary_x_list) == len(self.boundary_weights)

#         boundary_losses = [b_w * self.b_loss(b_x, boundary_y)
#                            for b_x, b_w in zip(boundary_x_list, self.boundary_weights)]

#         return boundary_losses, boundary_losses[-1] 