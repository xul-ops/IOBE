import torch
# from torch.nn import functional
# from isegm.utils.exp_imports.default import *
from mtorl.models.losses.loss_p2orm import AttentionLoss, FocalLoss, FocalLossV2
from mtorl.models.losses.cceloss import CCELoss

# should correct the model output
# from mtorl.models.losses.diceloss import make_one_hot, BinaryDiceLoss

"""
Current change instance_loss and intance_aux loss to occ loss
"""



class RITMLoss(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.instance_loss = NormalizedFocalLossSigmoid(alpha=0.5, gamma=2) # from_sigmoid=False
        self.instance_loss_weight = 1.0
        self.instance_aux_loss = SigmoidBinaryCrossEntropyLoss() # from_sigmoid=False
        self.instance_aux_loss_weight = 0.4

    def forward(self, net_output, labels, click_map=None):
        labels = labels #.squeeze(1)
        instance_pred = net_output['instances'] #.squeeze(1)
        instance_aux_pred = net_output['instances_aux']# .squeeze(1)
        losses = self.instance_loss_weight * self.instance_loss(instance_pred, labels)
        if instance_aux_pred is not None:
            aux_loss = self.instance_aux_loss_weight * self.instance_aux_loss(instance_aux_pred, labels)
            losses += aux_loss

        return losses


class RITM_OccLoss(torch.nn.Module):
    def __init__(self, loss_type="AL", from_sigmoid=False, boundary_lambda=1.7):
        super().__init__()
        self.loss_type = loss_type
        self.from_sigmoid = False
        self.instance_loss_weight = 1.0
        self.instance_aux_loss_weight = 0.4
        if loss_type == "AL":
            self.instance_loss = AttentionLoss()
            self.instance_aux_loss = AttentionLoss()
        elif loss_type == "FL":
            self.instance_loss = FocalLossV2()  # FocalLoss()
            self.instance_aux_loss = FocalLossV2() # FocalLoss()
        elif loss_type == "CCE":
            print("CCE loss boundary lambda : ", boundary_lambda)
            self.instance_loss = CCELoss(b_lambda=boundary_lambda, reduction='mean')
            self.instance_aux_loss = CCELoss(b_lambda=boundary_lambda, reduction='mean')
        # elif loss_type == "NFL":
        #     # same as the original...
        #     self.instance_loss = NormalizedFocalLossSigmoid(alpha=0.5, gamma=2)
        #    self.instance_aux_loss = NormalizedFocalLossSigmoid(alpha=0.5, gamma=2)


    def forward(self, net_output, labels, click_map=None):
        labels = labels
        instance_pred = net_output['instances']
        instance_aux_pred = net_output['instances_aux']
        if not self.from_sigmoid and self.loss_type == "AL":
            instance_pred = torch.sigmoid(instance_pred)
            instance_aux_pred = torch.sigmoid(instance_aux_pred)        
        
        # print(labels.shape, instance_pred.shape, instance_aux_pred.shape)
        if self.loss_type == "CCE":
            boundary_y = labels
            b_blance_pos = float(torch.sum(boundary_y == 1)) / float(torch.numel(boundary_y))
            b_blance_neg = float(torch.sum(boundary_y == 0)) / float(torch.numel(boundary_y))
            b_blance = [b_blance_pos, b_blance_neg]
            # b_blance = [0.1, 0.01]
            losses = self.instance_loss_weight * self.instance_loss(instance_pred, labels.squeeze(1), b_blance)
        else:    
            losses = self.instance_loss_weight * self.instance_loss(instance_pred, labels)
        
        if instance_aux_pred is not None:
            if self.loss_type == "CCE":
                aux_loss = self.instance_aux_loss(instance_aux_pred, labels.squeeze(1), b_blance)
            else:
                aux_loss = self.instance_aux_loss(instance_aux_pred, labels)
                
            losses += self.instance_aux_loss_weight * aux_loss

        return losses
        
        
class CDNetLoss(torch.nn.Module):
    def __init__(self, use_diversity_loss=True):
        super().__init__()
        
        self.use_diversity_loss = use_diversity_loss
                
        self.instance_loss = NormalizedFocalLossSigmoid(alpha=0.5, gamma=2) # from_sigmoid=False
        self.instance_loss_weight = 1
        self.fdm_instances_loss = NormalizedFocalLossSigmoid(alpha=0.5, gamma=2, from_sigmoid=True) # SigmoidBinaryCrossEntropyLoss(from_sigmoid=True)
        self.fdm_instances_loss_weight = 0.4
        self.diversity_loss = DiversityLoss()
        self.diversity_loss_weight = 1
    

    def forward(self, net_output, labels, click_map=None):
        labels = labels #.squeeze(1)
        # print(labels.shape, instance_pred.shape)
        instance_pred = net_output['instances'] #.squeeze(1)
        fdm_instances_pred = net_output['fdm_instances']# .squeeze(1)
        latent_instances_pred = net_output['latent_instances']# .squeeze(1)
        losses = self.instance_loss_weight * self.instance_loss(instance_pred, labels) + self.fdm_instances_loss_weight *  self.fdm_instances_loss(fdm_instances_pred, labels) 
        
        if self.use_diversity_loss:
            losses += self.diversity_loss_weight * self.diversity_loss(latent_instances_pred, labels, click_map)

        return losses        
        
        
class CDNet_OccLoss(torch.nn.Module):
    """
    change_diversity: change diversity loss to AL / FL / CCE?
    
    """
    def __init__(self, loss_type="AL", use_diversity_loss=True, boundary_lambda=1.7,  change_diversity=False, from_sigmoid=False):
        super().__init__()

        self.loss_type = loss_type
        self.from_sigmoid = from_sigmoid
        
        self.instance_loss_weight = 1
        self.fdm_instances_loss_weight = 0.4
        
        self.use_diversity_loss = use_diversity_loss        
        self.diversity_loss = DiversityLoss()
        self.diversity_loss_weight = 1

        if loss_type == "AL":
            self.instance_loss = AttentionLoss()
            self.fdm_instances_loss = AttentionLoss()
        elif loss_type == "FL":
            self.instance_loss = FocalLossV2()
            self.fdm_instances_loss = FocalLossV2()
        elif loss_type == "CCE":
            print("CCE loss boundary lambda : ", boundary_lambda)
            self.instance_loss = CCELoss(b_lambda=boundary_lambda, reduction='mean')
            self.fdm_instances_loss = CCELoss(b_lambda=boundary_lambda, reduction='mean')

    def forward(self, net_output, labels, click_map=None):
    
        labels = labels #.squeeze(1)
        instance_pred = net_output['instances'] #.squeeze(1)
        fdm_instances_pred = net_output['fdm_instances']# .squeeze(1)
        latent_instances_pred = net_output['latent_instances']# .squeeze(1)

        if not self.from_sigmoid and self.loss_type == "AL":
            instance_pred = torch.sigmoid(instance_pred)
            # fdm_instances_pred, from sigmoid True
            latent_instances_pred = torch.sigmoid(latent_instances_pred)
        
        # print(labels.shape, instance_pred.shape, instance_aux_pred.shape)
        if self.loss_type == "CCE":
            boundary_y = labels
            b_blance_pos = float(torch.sum(boundary_y == 1)) / float(torch.numel(boundary_y))
            b_blance_neg = float(torch.sum(boundary_y == 0)) / float(torch.numel(boundary_y))
            b_blance = [b_blance_pos, b_blance_neg]
            # b_blance = [0.1, 0.01]
            losses = self.instance_loss_weight * self.instance_loss(instance_pred, labels.squeeze(1), b_blance) + self.fdm_instances_loss_weight *  self.fdm_instances_loss(fdm_instances_pred, labels.squeeze(1), b_blance)
        else:    
            losses = self.instance_loss_weight * self.instance_loss(instance_pred, labels) + self.fdm_instances_loss_weight * self.fdm_instances_loss(fdm_instances_pred, labels)
        

        if self.use_diversity_loss:
            losses += self.diversity_loss_weight * self.diversity_loss(latent_instances_pred, labels, click_map)


        return losses        


class FocalLoss(torch.nn.Module):
    """
    backbone could be segformer or hrnet
    """
    def __init__(self, is_segformer=True, with_refine=False):
        super().__init__()
                
        self.instance_loss = NormalizedFocalLossSigmoid(alpha=0.5, gamma=2)
        self.instance_loss_weight = 1.0
        
        if is_segformer:
            self.instance_refine_loss = WFNL(alpha=0.5, gamma=2, w=0.5)
            self.instance_aux_loss_weight = None
        else:   
            self.instance_refine_loss = WFNL(alpha=0.5, gamma=2)
            self.instance_aux_loss = SigmoidBinaryCrossEntropyLoss()
            self.instance_aux_loss_weight = 0.4  
                
        self.trimap_loss = nn.BCEWithLogitsLoss() # NormalizedFocalLossSigmoid(alpha=0.5, gamma=2)
        self.with_refine = with_refine
        if self.with_refine:
            self.trimap_loss_weight = 1.0  
            self.instance_refine_loss_weight = 1.0 
        else:
            self.trimap_loss_weight = None
            self.instance_refine_loss_weight = None       
        

    def forward(self, net_output, labels, click_map=None):
        labels = labels
        instance_pred = net_output['instances']
        # instance_aux_pred = net_output['instances_aux']    
        if not self.with_refine:
            losses = self.instance_loss_weight * self.instance_loss(instance_pred, labels)

        return losses      
        

class Focal_OccLoss(torch.nn.Module):
    """
    backbone could be segformer or hrnet
    """
    def __init__(self, loss_type="AL", is_segformer=True, boundary_lambda=1.7, with_refine=False):
        super().__init__()
        self.loss_type = loss_type
                        
        # self.instance_loss = NormalizedFocalLossSigmoid(alpha=0.5, gamma=2)
        self.instance_loss_weight = 1.0
        # self.instance_aux_loss = SigmoidBinaryCrossEntropyLoss()
        
        if loss_type == "AL":
            self.instance_loss = AttentionLoss()
            self.instance_aux_loss = AttentionLoss()
        elif loss_type == "FL":
            self.instance_loss = FocalLossV2()
            self.instance_aux_loss = FocalLossV2()
        elif loss_type == "CCE":
            print("CCE loss boundary lambda : ", boundary_lambda)
            self.instance_loss = CCELoss(b_lambda=boundary_lambda, reduction='mean')
            self.instance_aux_loss = CCELoss(b_lambda=boundary_lambda, reduction='mean')        
        
        if is_segformer:
            self.instance_refine_loss = WFNL(alpha=0.5, gamma=2, w=0.5)
            self.instance_aux_loss_weight = None
        else:   
            self.instance_refine_loss = WFNL(alpha=0.5, gamma=2)
            self.instance_aux_loss_weight = 0.4
            
        self.trimap_loss = nn.BCEWithLogitsLoss() # NormalizedFocalLossSigmoid(alpha=0.5, gamma=2)
        
        self.with_refine = with_refine

        if self.with_refine:
            self.trimap_loss_weight = 1.0  
            self.instance_refine_loss_weight = 1.0 
        else:
            self.trimap_loss_weight = None
            self.instance_refine_loss_weight = None       

    def forward(self, net_output, labels, click_map=None):
        labels = labels
        instance_pred = net_output['instances']
        # instance_aux_pred = net_output['instances_aux']    
        if not self.with_refine:
            if self.loss_type == "CCE":
                boundary_y = labels
                b_blance_pos = float(torch.sum(boundary_y == 1)) / float(torch.numel(boundary_y))
                b_blance_neg = float(torch.sum(boundary_y == 0)) / float(torch.numel(boundary_y))
                b_blance = [b_blance_pos, b_blance_neg]
                losses = self.instance_loss_weight * self.instance_loss(instance_pred, labels.squeeze(1), b_blance)
            else:
                losses = self.instance_loss_weight * self.instance_loss(instance_pred, labels)

        return losses    
      
        
class SimpleLoss(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.instance_loss = NormalizedFocalLossSigmoid(alpha=0.5, gamma=2) # from_sigmoid=False
        self.instance_loss_weight = 1.0


    def forward(self, net_output, labels, click_map=None):
        labels = labels #.squeeze(1)
        instance_pred = net_output['instances'] #.squeeze(1)
        losses = self.instance_loss_weight * self.instance_loss(instance_pred, labels)

        return losses


class Simple_OccLoss(torch.nn.Module):
    def __init__(self, loss_type="AL", from_sigmoid=False, boundary_lambda=1.7):
        super().__init__()
        self.loss_type = loss_type
        self.from_sigmoid = False
        self.instance_loss_weight = 1.0

        if loss_type == "AL":
            self.instance_loss = AttentionLoss()
        elif loss_type == "FL":
            self.instance_loss = FocalLossV2()  # FocalLoss()

        elif loss_type == "CCE":
            print("CCE loss boundary lambda : ", boundary_lambda)
            self.instance_loss = CCELoss(b_lambda=boundary_lambda, reduction='mean')


    def forward(self, net_output, labels, click_map=None):
        labels = labels
        instance_pred = net_output['instances']
        if not self.from_sigmoid and self.loss_type == "AL":
            instance_pred = torch.sigmoid(instance_pred)       
        
        if self.loss_type == "CCE":
            boundary_y = labels
            b_blance_pos = float(torch.sum(boundary_y == 1)) / float(torch.numel(boundary_y))
            b_blance_neg = float(torch.sum(boundary_y == 0)) / float(torch.numel(boundary_y))
            b_blance = [b_blance_pos, b_blance_neg]
            # b_blance = [0.1, 0.01]
            losses = self.instance_loss_weight * self.instance_loss(instance_pred, labels.squeeze(1), b_blance)
        else:    
            losses = self.instance_loss_weight * self.instance_loss(instance_pred, labels)
        

        return losses                      

class GPCIS_OccLoss(torch.nn.Module):
    def __init__(self, loss_type="AL", from_sigmoid=False, boundary_lambda=1.7):
        super().__init__()
        self.loss_type = loss_type
        self.from_sigmoid = False
        self.instance_loss_weight = 1.0

        if loss_type == "AL":
            self.instance_loss = AttentionLoss()
        elif loss_type == "FL":
            self.instance_loss = FocalLossV2()  # FocalLoss()

        elif loss_type == "CCE":
            self.instance_loss = CCELoss(b_lambda=boundary_lambda, reduction='mean')


    def forward(self, net_output, labels, click_map=None):
        labels = labels
        instance_pred = net_output['instances']
        if not self.from_sigmoid and self.loss_type == "AL":
            instance_pred = torch.sigmoid(instance_pred)       
        
        if self.loss_type == "CCE":
            boundary_y = labels
            b_blance_pos = float(torch.sum(boundary_y == 1)) / float(torch.numel(boundary_y))
            b_blance_neg = float(torch.sum(boundary_y == 0)) / float(torch.numel(boundary_y))
            b_blance = [b_blance_pos, b_blance_neg]
            # b_blance = [0.1, 0.01]
            losses = self.instance_loss_weight * self.instance_loss(instance_pred, labels.squeeze(1), b_blance)
        else:    
            losses = self.instance_loss_weight * self.instance_loss(instance_pred, labels)
        
        if 'u_loss' in output.keys():
            losses += net_output['u_loss'].mean()

        return losses    
        
        
class Adaptiveclick_OccLoss(torch.nn.Module):

    def __init__(self, loss_type="AL", from_sigmoid=False, boundary_lambda=1.7):
        super().__init__()
        self.loss_type = loss_type
        self.from_sigmoid = False
        self.instance_loss_weight = 2.0
        self.pred_mask = 5.0
        self.pred_logits = 5.0

        if loss_type == "CCE":
            print("CCE loss boundary lambda : ", boundary_lambda)
            self.instance_loss = CCELoss(b_lambda=boundary_lambda, reduction='mean')
            self.mask_loss = CCELoss(b_lambda=boundary_lambda, reduction='mean')
            self.logits_loss = CCELoss(b_lambda=boundary_lambda, reduction='mean')
            

    def forward(self, net_output, labels, click_map=None):
        labels = labels
        
        instance_pred = net_output['instances']
        pred_logits = net_output['predictions']["pred_logits"]
        pred_mask = net_output['predictions']["pred_masks"]
        
        mask_target =  torch.nn.functional.interpolate(
                labels,
                size=(pred_mask.shape[2:]),
                mode="bilinear",
                align_corners=False,
            )
        
        # print(instance_pred.shape, pred_logits.shape, pred_mask.shape)        

        if self.loss_type == "CCE":
            boundary_y = labels
            b_blance_pos = float(torch.sum(boundary_y == 1)) / float(torch.numel(boundary_y))
            b_blance_neg = float(torch.sum(boundary_y == 0)) / float(torch.numel(boundary_y))
            b_blance = [b_blance_pos, b_blance_neg]
            # b_blance = [0.1, 0.01]
            losses = self.instance_loss_weight * self.instance_loss(instance_pred, labels.squeeze(1), b_blance)
            

            aux_loss = self.mask_loss(pred_mask, mask_target.squeeze(1), b_blance)
            losses += self.pred_mask * aux_loss
            # aux_loss = self.logits_loss(pred_logits, labels.squeeze(1), b_blance)     
            # losses += self.pred_logits * aux_loss

        return losses


class OccLoss(torch.nn.Module):
    def __init__(self, loss_type="CCE", from_sigmoid=False, boundary_lambda=1.7):
        super().__init__()
        self.loss_type = loss_type
        self.from_sigmoid = from_sigmoid
        self.instance_loss_weight = 1.0
        self.instance_aux_loss_weight = 0.4

        if loss_type == "AL":
            self.instance_loss = AttentionLoss()
            self.instance_aux_loss = AttentionLoss()
        elif loss_type == "FL":
            self.instance_loss = FocalLossV2()  # FocalLoss()
            self.instance_aux_loss = FocalLossV2() # FocalLoss()
        elif loss_type == "CCE":
            print("CCE loss boundary lambda : ", boundary_lambda)
            self.instance_loss = CCELoss(b_lambda=boundary_lambda, reduction='mean')
            self.instance_aux_loss = CCELoss(b_lambda=boundary_lambda, reduction='mean')


    def forward(self, net_output, labels, click_map=None):
        labels = labels

        instance_pred = net_output['instances']
        instance_aux_pred = net_output['instances_aux']

        if not self.from_sigmoid and self.loss_type == "AL":
            instance_pred = torch.sigmoid(instance_pred)
            instance_aux_pred = torch.sigmoid(instance_aux_pred)        
        
        # print(labels.shape, instance_pred.shape, instance_aux_pred.shape)
        if self.loss_type == "CCE":
            boundary_y = labels
            b_blance_pos = float(torch.sum(boundary_y == 1)) / float(torch.numel(boundary_y))
            b_blance_neg = float(torch.sum(boundary_y == 0)) / float(torch.numel(boundary_y))
            b_blance = [b_blance_pos, b_blance_neg]
            # b_blance = [0.1, 0.01]
            losses =  self.instance_loss_weight * self.instance_loss(instance_pred, labels.squeeze(1), b_blance)
        else:    
            losses = self.instance_loss_weight * self.instance_loss(instance_pred, labels)
        
        if instance_aux_pred is not None:
            if self.loss_type == "CCE":
                aux_loss = self.instance_aux_loss(instance_aux_pred, labels.squeeze(1), b_blance)
            else:
                aux_loss = self.instance_aux_loss(instance_aux_pred, labels)
                
            losses += self.instance_aux_loss_weight * aux_loss

        return losses
