# --------------------------------------------------------
# P2ORM: Formulation, Inference & Application
# modifed
# --------------------------------------------------------
# define loss terms for occlusion edge/order detection

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from collections import Counter
# from utils.losses.oorloss import OORLoss
from mtorl.models.losses.oorloss import OORLoss
PI = 3.1416


def get_criterion(config, args, loss_type="ALoss"):
    """get relevant loss for train"""
    if loss_type == 'CCELoss':

        cls_weights = torch.tensor(config.TRAIN.class_weights, dtype=torch.float32)
        criterion = CCELoss(config, args.gpus[0], cls_weights=cls_weights,
                            spatial_weights=config.TRAIN.spatial_weighting, size_average=True)
    elif loss_type == 'ALoss':
        criterion = AL_and_L1()
    elif loss_type == 'FLoss':
        criterion = FocalLoss()
    else:
        # no balance CE
        criterion = nn.CrossEntropyLoss().cuda()

    return criterion


class CCELoss(nn.Module):
    """class-balanced cross entropy loss for classification with given class weights"""
    def __init__(self, config, gpu_id, cls_weights='None', spatial_weights='None', size_average=True):
        super(CCELoss, self).__init__()
        self.config = config
        self.spatial_weights = spatial_weights
        self.size_average = size_average
        self.loss_CE = nn.CrossEntropyLoss(weight=cls_weights, reduction='none').cuda(gpu_id)

    def forward(self, net_out, target, mask):
        """
        :param net_out: N,C,H,W
        :param target: N,H,W; [0,1,2]
        :param mask: N,H,W; [0,1]
        :return:
        """
        loss = self.loss_CE(net_out, target)  # N,C,H,W => N,H,W
        loss = loss.view(-1)  # N,H,W => N*H*W,

        if self.spatial_weights != 'None':
            if self.config.TRAIN.mask_is_edge:  # where on occlusion edge pixels
                weight_mask = mask
            else:  # where curr occlusion order exists
                weight_mask = (target.clone().detach() != 1)

            weight_mask = weight_mask.view(-1).float()  # N,H,W => N*H*W,
            weight_mask[weight_mask == 1.] = self.spatial_weights[1]
            weight_mask[weight_mask == 0.] = self.spatial_weights[0]

            loss = weight_mask * loss

        if self.size_average:
            return loss.mean()
        else:
            return loss.sum()


class FocalLoss(nn.Module):
    """
    focal loss for classification task
    derived from https://github.com/clcarwin/focal_loss_pytorch/blob/master/focalloss.py
    """
    def __init__(self, gamma=0., alpha='None', size_average=True):
        super(FocalLoss, self).__init__()
        self.gamma = gamma  # default:2 ; for RetinaNet: [0.5, 5]
        self.alpha = alpha  # hyper-param(list) or inverse class frequency
        if isinstance(alpha, (float, int)):  # binary case
            self.alpha = torch.Tensor([alpha, 1 - alpha])
        if isinstance(alpha, list):
            self.alpha = torch.Tensor(alpha)
        self.size_average = size_average

    def forward(self, net_out, target):
        cls_ind = torch.arange(0, net_out.size(1), dtype=torch.long).tolist()
        if net_out.dim() > 2:
            net_out = net_out.view(net_out.size(0), net_out.size(1), -1)  # N,C,H,W => N,C,H*W
            net_out = net_out.transpose(1, 2)  # N,C,H*W => N,H*W,C
            net_out = net_out.contiguous().view(-1, net_out.size(2))  # N,H*W,C => N*H*W,C
        # target = target.view(-1, 1)  # N,H,W => N*H*W,1

        log_pt = F.log_softmax(net_out, dim=1)  # log(softmax(net_out))
        log_pt = log_pt.gather(1, target)  # N*H*W,C => N*H*W,1 gather along axis 1
        log_pt = log_pt.view(-1)  # N*H*W,
        pt = log_pt.data.exp()  # softmax(net_out)

        if self.alpha == 'None':
            # use mini-batch inverse class frequency as alpha
            cls_num = torch.tensor([target.cpu().eq(cls_idx).sum() for cls_idx in cls_ind])
            # alpha = target.cpu().numel() / cls_num.float()  # C,
            alpha = 1 + torch.log(target.cpu().numel() / cls_num.float())  # C,
        else:
            alpha = self.alpha
        if alpha.type() != net_out.data.type():
            alpha = alpha.type_as(net_out.data)

        at = alpha.gather(0, target.data.view(-1))  # N*H*W,
        log_pt = log_pt * at  # alpha * log(softmax(net_out))
        loss = -1 * ((1 - pt) ** self.gamma) * log_pt  # N*H*W,
        if self.size_average:
            return loss.mean()  # average over each loss elem
        else:
            return loss.sum()


class FocalLossV2(nn.Module):
    """
    focal loss for classification task
    derived from https://github.com/CoinCheung/pytorch-loss/blob/master/focal_loss.py
    """

    def __init__(self,
                 alpha=None,
                 gamma=2,
                 reduction='sum'):
        super(FocalLossV2, self).__init__()
        self.alpha = alpha
        self.gamma = gamma
        self.reduction = reduction
        self.eps = 1e-8
        # self.crit = nn.BCEWithLogitsLoss(reduction='none')

    def forward(self, logits, label):

        # create mask to identify pixels at boundary
        edge     = (label == 1).float()
        non_edge = (label != 1).float()

        if self.alpha is None:
            alpha = non_edge.sum() / (non_edge.sum() + edge.sum())
        else:
            alpha = self.alpha
        
        probs = torch.sigmoid(logits)
        probs = torch.clamp(probs, self.eps, 1-self.eps)
        coeff = torch.abs(label - probs).pow(self.gamma).neg()
        log_probs = torch.where(logits >= 0, F.softplus(logits, -1, 50), logits - F.softplus(logits, 1, 50))
        log_1_probs = torch.where(logits >= 0, -logits + F.softplus(logits, -1, 50), -F.softplus(logits, 1, 50))
        loss = label * alpha * log_probs + (1. - label) * (1. - alpha) * log_1_probs
        loss = loss * coeff

        if self.reduction == 'mean':
            loss = loss.mean()
        if self.reduction == 'sum':
            loss = loss.sum()
        return loss


class FL_and_L1(nn.Module):
    """FocalLoss + SmoothL1 for occlusion edge/ori estimation"""
    def __init__(self, args):
        super(FL_and_L1, self).__init__()
        # 0.25
        self.FocalLoss = FocalLossV2(gamma=2.0, alpha=None) # FocalLoss()
        self.NO_MASK_ORI = args.NO_MASK_ORI

        self.SmoothL1Loss = SmoothL1Loss(args.sigma, avg_method=args.avg_method)
        self.lamda = args.lamda

    def forward(self, out_b, out_o, targets):

        occ_edge_gt = targets[:, 0, :, :].unsqueeze(dim=1)
        occ_ori_gt = targets[:, 1, :, :].unsqueeze(dim=1)

        if self.NO_MASK_ORI:
            mask_ones = np.ones((occ_edge_gt.size()))
            mask_ones_tensor = torch.tensor(mask_ones).cuda()
            occ_ori_loss = self.SmoothL1Loss(out_o, occ_ori_gt, mask_ones_tensor)
        else:
            occ_ori_loss = self.SmoothL1Loss(out_o, occ_ori_gt, occ_edge_gt)

        occ_edge_gt = targets[:, 0, :, :].reshape(-1, 1) # .view(-1, 1)
        # occ_edge_pred = out_b.squeeze(dim=1).reshape(-1, 1)
        occ_edge_pred = out_b.view(out_b.size(0), out_b.size(1), -1)  # N,C,H,W => N,C,H*W
        occ_edge_pred = occ_edge_pred.transpose(1, 2)  # N,C,H*W => N,H*W,C
        occ_edge_pred = occ_edge_pred.contiguous().view(-1, out_b.size(1))  # N,H*W,C => N*H*W,C
        # print(out_o.shape, out_o.shape, occ_edge_pred.shape)
        # batch avg
        occ_edge_loss = self.FocalLoss(occ_edge_pred, occ_edge_gt) / out_b.size(0)

        return self.lamda[0] * occ_edge_loss, self.lamda[1] * occ_ori_loss


class AL_and_L1(nn.Module):
    """Attention loss + SmoothL1 for occlusion edge/ori estimation"""
    def __init__(self, args):
        super(AL_and_L1, self).__init__()
        self.AttentionLoss = AttentionLoss(gamma_beta=args.gamma_beta, alpha=None, avg_method=args.avg_method)
        # sigma = 3.0
        self.NO_MASK_ORI = args.NO_MASK_ORI

        self.SmoothL1Loss = SmoothL1Loss(args.sigma, avg_method=args.avg_method)
        self.lamda = args.lamda

    def forward(self, out_b, out_o, targets):
        occ_edge_pred = out_b
        occ_ori_pred = out_o
        occ_edge_gt = targets[:, 0, :, :].unsqueeze(dim=1)
        occ_ori_gt = targets[:, 1, :, :].unsqueeze(dim=1)
        # print(out_o.shape, occ_ori_pred.shape, occ_ori_gt.shape)

        if self.NO_MASK_ORI:
            mask_ones = np.ones((occ_edge_gt.size()))
            mask_ones_tensor = torch.tensor(mask_ones).cuda()
            occ_ori_loss = self.SmoothL1Loss(occ_ori_pred, occ_ori_gt, mask_ones_tensor)
        else:
            occ_ori_loss = self.SmoothL1Loss(occ_ori_pred, occ_ori_gt, occ_edge_gt)

        occ_edge_loss = self.AttentionLoss(occ_edge_pred, occ_edge_gt)
  
        return self.lamda[0] * occ_edge_loss, self.lamda[1] * occ_ori_loss
        

class AL_and_OOR(nn.Module):
    """Attention loss + OOR loss for occlusion edge/ori estimation"""
    def __init__(self, args):
        super(AL_and_OOR, self).__init__()
        self.AttentionLoss = AttentionLoss(gamma_beta=args.gamma_beta, alpha=None, avg_method=args.avg_method)
        # sigma = 3.0
        self.NO_MASK_ORI = args.NO_MASK_ORI

        # self.SmoothL1Loss = SmoothL1Loss(args.sigma, avg_method=args.avg_method)
        self.o_loss = OORLoss(reduction='mean')
        self.lamda = args.lamda

    def forward(self, out_b, out_o, targets):
        occ_edge_pred = out_b
        occ_ori_pred = out_o
        occ_edge_gt = targets[:, 0, :, :].unsqueeze(dim=1)
        occ_ori_gt = targets[:, 1, :, :].unsqueeze(dim=1)
        # print(out_o.shape, occ_ori_pred.shape, occ_ori_gt.shape)

        if self.NO_MASK_ORI:
            mask_ones = np.ones((occ_edge_gt.size()))
            mask_ones_tensor = torch.tensor(mask_ones).cuda()
            occ_ori_loss = self.o_loss(occ_ori_pred, occ_ori_gt, mask_ones_tensor)
        else:
            occ_ori_loss = self.o_loss(occ_ori_pred, occ_ori_gt, occ_edge_gt)

        occ_edge_loss = self.AttentionLoss(occ_edge_pred, occ_edge_gt)
  
        return self.lamda[0] * occ_edge_loss, self.lamda[1] * occ_ori_loss        


class AttentionLoss(nn.Module):
    """
    binary attention loss introduced in DOOBNet https://arxiv.org/pdf/1806.03772.pdf
    extension of focal loss by adding modulating param beta
    """

    def __init__(self, gamma_beta=(0.5, 4), alpha=None, size_average=True, avg_method='batch'):
        """
        :param gamma_beta:
        :param alpha: None or a float
        :param size_average:
        """
        super(AttentionLoss, self).__init__()
        self.gamma = gamma_beta[0]
        self.beta  = gamma_beta[1]
        self.alpha = alpha
        self.size_average = size_average
        self.avg_method   = avg_method
        self.eps = 1e-8

    def forward(self, net_out, target):
        """
        :param net_out:# net_out: (N, 1, H, W) ; activation passed by sigmoid [0~1]
        :param target: (N, 1, H, W)
        :return:
        """
        N, C, H, W = target.shape
        assert net_out.size(1) == 1

        # create mask to identify pixels at boundary
        edge     = (target == 1).float()
        non_edge = (target != 1).float()

        if self.alpha is None:
            alpha = non_edge.sum() / (non_edge.sum() + edge.sum())
        else:
            alpha = self.alpha

        # net_out = torch.sigmoid(net_out)
        net_out = torch.clamp(net_out, self.eps, 1-self.eps)  # according to caffe code

        # in loss_bkp.py
        # loss = -alpha * target * 4 ** ((1.0 - net_out) ** 0.5) * torch.log(net_out + 1e-8) - \
        #        (1.0 - alpha) * (1.0 - target) * 4 ** (net_out ** 0.5) * torch.log(1.0 - net_out + 1e-8)
        # loss_al = torch.sum(loss)

        # scale_edge    = alpha * torch.pow(self.beta, torch.pow((1 - net_out), self.gamma))
        scale_edge = alpha * torch.pow(self.beta, torch.pow((1 - net_out), self.gamma))
        scale_nonedge = (1 - alpha) * torch.pow(self.beta, torch.pow(net_out, self.gamma))

        log_p = net_out.log()
        # log_p = (net_out + self.eps).log()
        log_m_p = (1 - net_out).log()
        # log_m_p = (1 - net_out + self.eps).log()

        loss = - edge * scale_edge * log_p - non_edge * scale_nonedge * log_m_p
        # print(loss)
        # print(loss.sum())
        
        # loss = torch.clamp(loss, self._eps, 1-self._eps)  # according to caffe code
        loss_nan_map = torch.isnan(loss)
        loss[loss_nan_map] = 0.0

        if self.size_average:
            if self.avg_method == 'batch':
                loss = loss.view(N, -1).sum(-1)
            return loss.mean()
        else:
            return loss.sum()  # too big loss may result in too big grad


class SmoothL1Loss(nn.Module):
    def __init__(self, sigma, avg_method):
        super(SmoothL1Loss, self).__init__()
        self.sigma = sigma
        self.avg_method = avg_method

    def forward(self, pred, gt, mask, size_average=True):
        """
        compute smoothL1 loss for orientation regression on given mask=1 pixels as in DOOBNet
        :param pred: N,1,H,W; float
        :param gt: N,1,H,W
        :param mask: N,1,H,W; [0, 1.]; int
        :param type:
        :return:
        """
        N, C, H, W = gt.shape
        valid_elem = (mask == 1.).sum()
        gt = gt.float()
        mask = mask.float()

        mask_sum_pos = (pred > PI) * (gt > 0.)
        mask_sum_neg = (pred < -PI) * (gt <= 0.)

        sum = pred + gt
        diff = pred - gt
        x = diff
        x[mask_sum_pos] = sum[mask_sum_pos]
        x[mask_sum_neg] = sum[mask_sum_neg]

        x = x * mask
        x_abs = torch.abs(x)

        mask_in  = (x_abs < (1 / self.sigma**2)).float()  # caffe code thresh: 1 / sigma**2; but thresh 1 works better
        mask_out = (x_abs >= (1 / self.sigma**2)).float()

        loss_in  = 0.5 * (self.sigma**2) * (x**2)
        loss_out = x_abs - 0.5 / (self.sigma**2)
        loss = loss_in * mask_in + loss_out * mask_out
        # print(loss)

        if size_average:
            if self.avg_method == 'batch':
                loss = torch.sum(loss.view(N, -1), dim=1)
                return loss.mean()
            elif self.avg_method == 'mean':
                return loss.sum() / valid_elem
        else:
            return loss.sum()


