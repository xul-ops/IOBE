import math
import os
import pdb

import torch
import torch.nn as nn
import torch.nn.functional as F

from mtorl.utils.modifiers import LRMult
from mtorl.utils.serialization import serialize
from mtorl.models.backbones.resnet import resnetv2
from mtorl.models.backbones import resnest, hrnet, segformer, swinformer, plainvit

from mtorl.models.basic_components import (BasicDecoder, ConvBnRelu, ConvBnRelu2, crop, opm, osm, FEM)
from mtorl.utils.log import logger


class TPENet(nn.Module):
    def __init__(self,
                 backbone_name='resnet50',
                 num_ori_out=2,
                 use_pixel_shuffle=True,
                 orientation_path=False,
                 lite=False,
                 in_channels=6,
                 deep_fusion=True,
                 bbfeatures_scale=1,
                 use_res50_shape=False,
                 use_fuse_head=True,
                 backbone_path=''):

        # C64
        super().__init__()

        self.osm = None       
        self.deep_stem = True
        self.deep_fusion = deep_fusion
        self.backbone_name = backbone_name
        self.bbfeatures_scale = bbfeatures_scale          
        self.use_res50_shape = use_res50_shape
        self.orientation_path = orientation_path        
        res50_shape = [1024, 512, 256, 128]
        res50_scale = [1, 2, 4, 8]
        self.is_inplanes = 64
        self.concat_deep = True
                

        # fusion path
        if backbone_name.startswith("hrnet"):
            self.backbone, self.feats_shape = hrnet(backbone_name, backbone_path)
 
        elif backbone_name.startswith("resnet"):
            if backbone_name == "resnet34":
                self.deep_stem=False
                self.feats_shape = [256, 128, 64, 64]
                self.osm = osm(feature_channels=[512, 256], upsample_scale_factors=[2, 1])
            elif backbone_name == "resnet50":
                self.feats_shape = [1024, 512, 256, 128]
                self.osm = osm(feature_channels=[2048, 1024], upsample_scale_factors=[2, 1])
            elif backbone_name == "resnet101":
                self.feats_shape = [1024, 512, 256, 128]
                self.osm = osm(feature_channels=[2048, 1024], upsample_scale_factors=[2, 1])

            self.backbone = resnetv2(backbone_name, in_channels, deep_stem=self.deep_stem)                    
            self.is_inplanes = 128 if self.deep_stem and self.concat_deep else 64    
                         
        elif backbone_name.startswith("segformer"):
            self.backbone, self.feats_shape = segformer(backbone_name, backbone_path) 
            
        elif backbone_name.startswith("swinformer"):
            self.backbone, self.feats_shape = swinformer(backbone_name, backbone_path, in_chans=in_channels-3) 
        
        elif backbone_name.startswith("plainvit_"):  # base large, cannot huge   
            self.backbone, self.feats_shape = plainvit(backbone_name, backbone_path) 
            if backbone_name.startswith("plainvit_large"):
                self.deep_fusion = False
                             
        elif backbone_name.startswith("resnest50"): 
            self.backbone = resnest(backbone_name) 
            self.feats_shape = [1024, 512, 256, 64]
            self.osm = osm(feature_channels=[2048, 1024], upsample_scale_factors=[2, 1])   
            self.additional_cbr = ConvBnRelu(64, 64, 1, stride=2)
            self.conv_upsampling = nn.Sequential(  
                    nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True),
                    ConvBnRelu(64, 128, 1))              
                         
        else:
            raise ValueError('Wrong backbone name! Please check. ')  

        if self.use_res50_shape or (self.backbone_name == "resnet50"):
            out_shape = res50_shape
            num_decoder_end_c = [16, 64]
            bb_feature_scales = [16, 8, 4, 2, 1]
        else:
            out_shape = self.feats_shape * bbfeatures_scale
            
            if self.backbone_name.startswith("resnest"):
                out_shape = [1024, 512, 256, 128]
            
            num_decoder_end_c = [int(out_shape[-1]/8), int(out_shape[-1]/2)]   
            count =  num_decoder_end_c[1]        
            bb_feature_scales = [16, 8, 4, 2, 1]

        
        self.bbfeatures_sides = nn.ModuleList()    
        for i in range(4):
            layer = nn.Sequential(  
                    nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True),
                    ConvBnRelu(self.feats_shape[i], out_shape[i], 1)
                    )        

            # swinl v2 in supp   
            # layer = nn.Sequential(  
            #         ConvBnRelu(self.feats_shape[i], self.feats_shape[i]*4, 1),
            #         nn.PixelShuffle(2),
            #         ConvBnRelu(self.feats_shape[i], out_shape[i], 1)
            #         )  
            self.bbfeatures_sides.append(layer)          
        
    
        self.is_instride = 2 if self.concat_deep else 1
        simple_map = "v2"
        
        print()
        print("Interactive TPENet parmas: deep_fusion concat_deep, simple_map_version")
        print(self.deep_fusion, self.concat_deep, simple_map)
        print()        
        print("Backbone name - ", backbone_name, " backbone features shape - ", self.feats_shape, " out shape - ", out_shape, 
                "num decoder end c - ", num_decoder_end_c, "current features scale - ", bb_feature_scales)
        print()

        # InP part 1
        if simple_map == "v1":                               
            mt_layers = [
                nn.Conv2d(in_channels=in_channels-3, out_channels=64, kernel_size=1),
                nn.BatchNorm2d(64),
                nn.ReLU(inplace=True),
                nn.Conv2d(64, self.is_inplanes, kernel_size=3, stride=self.is_instride, padding=1, bias=False)
                ]
        elif simple_map == "v2":
            mt_layers = [
                nn.Conv2d(in_channels=in_channels-3, out_channels=64, kernel_size=1),
                nn.BatchNorm2d(64),
                nn.ReLU(inplace=True),
                nn.Conv2d(64, 64, kernel_size=3, stride=1, padding=1, bias=False),
                nn.BatchNorm2d(64), 
                nn.ReLU(inplace=True), 
                nn.Conv2d(64, self.is_inplanes, kernel_size=3, stride=self.is_instride, padding=1, bias=False)
                ]
        self.maps_transform = nn.Sequential(*mt_layers)    

        # task is ori
        if self.orientation_path:
            self.ori_convolution = torch.nn.Sequential(
                ConvBnRelu(in_channels, num_decoder_end_c[0], 1),
                ConvBnRelu(num_decoder_end_c[0], num_decoder_end_c[0], 3),
                ConvBnRelu(num_decoder_end_c[0], num_decoder_end_c[0], 3),
                ConvBnRelu(num_decoder_end_c[0], num_decoder_end_c[0], 3),
                ConvBnRelu(num_decoder_end_c[0], num_decoder_end_c[0], 3),
                ConvBnRelu(num_decoder_end_c[0], num_decoder_end_c[0], 3),
                ConvBnRelu(num_decoder_end_c[0], num_decoder_end_c[0], 3),
                ConvBnRelu(num_decoder_end_c[0], num_decoder_end_c[1], 1)
                )
    
            self.ori_decoder = BasicDecoder(
                feature_channels=[out_shape[0], out_shape[2], num_decoder_end_c[1]],
                feature_scales=bb_feature_scales[::2],
                path_name='ori',
                num_end_out=num_ori_out,
                use_pixel_shuffle=False,
            )
              
        # ImP
        self.boundary_convolution = torch.nn.Sequential(
            ConvBnRelu(3, num_decoder_end_c[0], 3),
            ConvBnRelu(num_decoder_end_c[0], num_decoder_end_c[0], 3),
            ConvBnRelu(num_decoder_end_c[0], num_decoder_end_c[0], 3),
            ConvBnRelu(num_decoder_end_c[0], num_decoder_end_c[0], 3),
            ConvBnRelu(num_decoder_end_c[0], num_decoder_end_c[0], 3),
            ConvBnRelu(num_decoder_end_c[0], num_decoder_end_c[0], 3),
            ConvBnRelu(num_decoder_end_c[0], num_decoder_end_c[0], 3),
            ConvBnRelu(num_decoder_end_c[0], num_decoder_end_c[1], 1)
        )


        self.boundary_decoder = BasicDecoder(
            feature_channels=[out_shape[0], out_shape[1], out_shape[2], out_shape[3], num_decoder_end_c[1]],
            feature_scales=bb_feature_scales,
            path_name='boundary',
            num_end_out=1,
            use_pixel_shuffle=use_pixel_shuffle
        )

        # InP part2
        # this place conv is ok       
        self.is_trans_1 = ConvBnRelu2(self.is_inplanes, out_shape[3], kernel_size=3, stride=1) 
        self.is_trans_2 = ConvBnRelu2(out_shape[3], out_shape[2], kernel_size=3, stride=2) 
        self.is_trans_3 = ConvBnRelu2(out_shape[2], out_shape[1], kernel_size=3, stride=2) 
        self.is_trans_4 = ConvBnRelu2(out_shape[1], out_shape[0], kernel_size=3, stride=2) 

        self.encoder_sides = nn.ModuleList()
        self.fem_has = ['fem', 'no', 'fem', 'no']
        if backbone_name.startswith("swinformer") and backbone_name.endswith("large"):
            sc = [3, 9]
        else:
            sc = [5, 7]
        print("fem strip layer", sc)

        for num_c, l_name in zip(out_shape, self.fem_has):
            # layer = BA_Block(num_c, num_c) if l_name == 'bab' else torch.nn.Sequential()
            layer = FEM(num_c, 1, sc[0], sc[1]) if l_name == 'fem' else torch.nn.Sequential()
            # layer = opm(num_c) if l_name == 'opm' else torch.nn.Sequential()
            self.encoder_sides.append(layer)


        self.fuse = torch.nn.Sequential(conv1x1(5, 1))

        self._initialize_weights()

    def forward(self, inputs):

        x_rgb = inputs[:, 0:3, :, :]
        x_is = inputs[:, 3:, :, :]
        x_is_f = self.maps_transform(x_is)
        
        if self.backbone_name.startswith("resnet"):
            features = self.backbone(x_rgb, x_is_f, self.concat_deep)
        elif self.backbone_name.startswith("resnest"):
            x_is_f_2 = self.additional_cbr(x_is_f)
            features = self.backbone(x_rgb, x_is_f_2)
            features[0] = self.conv_upsampling(features[0])
        elif self.backbone_name.startswith("segformer") or self.backbone_name.startswith("swinformer") or self.backbone_name.startswith("plainvit_") :
            features = self.backbone(x_rgb, x_is)
        else:
            features = self.backbone(x_rgb, x_is_f)   

        features = list(features[::-1])
        
        # for resnet
        if self.osm is not None:
            osm_x = self.osm(features[:2])
            side_features = [osm_x] + features[2:]
        else:
            side_features = [layer(feat) for feat, layer in zip(features, self.bbfeatures_sides)]
       

        assert len(side_features) == len(self.encoder_sides)

        
        if self.deep_fusion:
            is_t_1 = self.is_trans_1(x_is_f)
            is_t_2 = self.is_trans_2(is_t_1)
            is_t_3 = self.is_trans_3(is_t_2)
            is_t_4 = self.is_trans_4(is_t_3)
            is_side_features = [is_t_4, is_t_3, is_t_2, is_t_1]

            for i in range(len(side_features)):
                if self.fem_has[i] == "fem":
                    side_features[i] = side_features[i] + crop(is_side_features[i], side_features[i])
               
        side_features = [layer(feat) for feat, layer in zip(side_features, self.encoder_sides)]

        x_inputs = x_rgb
        boundary_outsides = self.boundary_decoder(side_features + [self.boundary_convolution(x_inputs)])
        boundary_outsides = [crop(boundary_outside, inputs)
                             for boundary_outside in boundary_outsides]

        boundary_fuse = self.fuse(torch.cat(boundary_outsides, 1)) 
        boundary_outsides.append(boundary_fuse)

        orientation_x = None
        if self.orientation_path:
            orientation_x = self.ori_decoder([side_features[0], side_features[2], self.ori_convolution(inputs)])[0]
        return boundary_outsides, orientation_x

    @staticmethod
    def getOrientation(orientation_x):
        return torch.atan2(orientation_x[:, 0], orientation_x[:, 1]).unsqueeze(1)

    @staticmethod
    def getBoundary(boundary_outsides):
        return torch.sigmoid(boundary_outsides[-1])

    def load_backbone_pretrained(self, pretrained_path='data/resnet50-25c4b509.pth'):
        # print(os.getcwd())
        keys = self.backbone.load_state_dict(torch.load(pretrained_path), strict=False)
        if len(keys.missing_keys) > 0:
            logger.info(f"=> Pretrained: missing_keys [{', '.join(keys.missing_keys)}]")
        if len(keys.unexpected_keys) > 0:
            logger.info(f"=> Pretrained: unexpected_keys [{', '.join(keys.unexpected_keys)}]")
        logger.info(f'=> Backbone pretrained: loaded from {pretrained_path}\n')

    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_uniform_(m.weight, a=math.sqrt(5))
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)



#### seperate modules
class FusionPath(nn.Module):
    def __init__(self,
                 backbone_name='resnet50',
                 in_channels=6,
                 bbfeatures_scale=1,
                 use_res50_shape=False,
                 **kwargs):  
        super().__init__()

        self.osm = None       
        self.deep_stem = True
        self.backbone_name = backbone_name
        self.bbfeatures_scale = bbfeatures_scale          
        self.use_res50_shape = use_res50_shape     
        res50_shape = [1024, 512, 256, 128]
        res50_scale = [1, 2, 4, 8]
        self.is_inplanes = 64
        self.concat_deep = True
                

        if backbone_name.startswith("hrnet"):
            self.backbone, self.feats_shape = hrnet(backbone_name)
 
        elif backbone_name.startswith("resnet"):
            self.backbone = resnetv2(backbone_name, in_channels, deep_stem=self.deep_stem)                   
            self.feats_shape = [1024, 512, 256, 128]  
            self.osm = osm(feature_channels=[2048, 1024], upsample_scale_factors=[2, 1])    
            self.is_inplanes = 128 if self.deep_stem and self.concat_deep else 64    
                         
        elif backbone_name.startswith("segformer"):
            self.backbone, self.feats_shape = segformer(backbone_name) 
            
        elif backbone_name.startswith("swinformer"):
            self.backbone, self.feats_shape = swinformer(backbone_name) 
        
        # base large, cannot huge 
        elif backbone_name.startswith("plainvit_"):   
            self.backbone, self.feats_shape = plainvit(backbone_name) 
                             
        elif backbone_name.startswith("resnest"):
            self.backbone = resnest(backbone_name) 
            # only support resnest50 here
            self.feats_shape = [1024, 512, 256, 64]
            self.osm = osm(feature_channels=[2048, 1024], upsample_scale_factors=[2, 1])   
            # nn.PixelShuffle(scale_factor)
            self.conv_upsampling = nn.Sequential(  
                                   nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True),
                                   ConvBnRelu(64, 128, 1))            
                         
        else:
            # backbone_name.startswith("hrformer"):
            raise ValueError('Wrong backbone name! Please check')  

        if self.use_res50_shape:
            out_shape = res50_shape
            num_decoder_end_c = [16, 64]
            bb_feature_scales = [16, 8, 4, 2, 1]
        else:
            out_shape = self.feats_shape * bbfeatures_scale
            
            if self.backbone_name.startswith("resnest"):
                out_shape = [1024, 512, 256, 128]
            
            # should we keep the feature scale rate?
            num_decoder_end_c = [int(out_shape[-1]/8), int(out_shape[-1]/2)]   
            # count =  num_decoder_end_c[1]        
            # bb_feature_scales = [int(item/count) for item in out_shape]
            # bb_feature_scales.append(1)
            bb_feature_scales = [16, 8, 4, 2, 1]

        print()        
        print("Backbone is ", backbone_name, " backbone features shape is ", self.feats_shape, " changed out shape is ", out_shape, 
                "num decoder end c is ", num_decoder_end_c, "current features scale is ", bb_feature_scales)
        print()

        self.out_shape = out_shape
        self.num_decoder_end_c = num_decoder_end_c
        self.bb_feature_scales = bb_feature_scales

        # keep the features map H W same as resnet50
        self.bbfeatures_sides = nn.ModuleList()    
        for i in range(4):

            layer = nn.Sequential(  
                    # ConvBnRelu(self.feats_shape[i], out_shape[i], 1)
                    # nn.PixelShuffle(scale_factor)
                    nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True),
                    ConvBnRelu(self.feats_shape[i], out_shape[i], 1)
                    )           
            self.bbfeatures_sides.append(layer)           

    def get_params(self):
        return self.num_decoder_end_c, self.bb_feature_scales, self.out_shape, self.is_inplanes

    def forward(self, imgs, iter_feats=None):
        
        if self.backbone_name.startswith("resnet"):
            features = self.backbone(imgs, iter_feats, self.concat_deep)
        elif self.backbone_name.startswith("resnest"):
            features = self.backbone(imgs, iter_feats)
            features[0] = self.conv_upsampling(features[0])
        else:
            features = self.backbone(imgs, iter_feats)  

        features = list(features[::-1])

               
        if self.osm is not None:
            osm_x = self.osm(features[:2])
            side_features = [osm_x] + features[2:]
        else:
            side_features = [layer(feat) for feat, layer in zip(features, self.bbfeatures_sides)]

        return side_features


class InP(nn.Module):
    def __init__(self,
                 out_shape,
                 in_channels=6,
                 is_inplanes=64,
                 backbone_name='resnet50',
                 deep_fusion=True,
                 simple_map="v2",
                 **kwargs):  
        super().__init__()

        self.deep_fusion = deep_fusion
        self.backbone_name = backbone_name
        # self.is_instride = 2 if self.concat_deep else 1

        if backbone_name.startswith("resnest"): 
            self.additional_cbr = ConvBnRelu(64, 64, 1, stride=2)  

        if backbone_name.startswith("resnet"):
            self.is_inplanes = 128 # if self.deep_stem and self.concat_deep else 64                  
            
        if simple_map == "v0":
            self.maps_transform = nn.Conv2d(in_channels=in_channels-3, out_channels=is_inplanes, kernel_size=3, stride=2, padding=1)
        elif simple_map == "v1":                               
            mt_layers = [
                nn.Conv2d(in_channels=in_channels-3, out_channels=64, kernel_size=1),
                nn.BatchNorm2d(64),
                nn.ReLU(inplace=True),
                nn.Conv2d(64, is_inplanes, kernel_size=3, stride=2, padding=1, bias=False)
                ]
            self.maps_transform = nn.Sequential(*mt_layers)
        elif simple_map == "v2":
            mt_layers = [
                nn.Conv2d(in_channels=in_channels-3, out_channels=64, kernel_size=1),
                nn.BatchNorm2d(64),
                nn.ReLU(inplace=True),
                nn.Conv2d(64, 64, kernel_size=3, stride=1, padding=1, bias=False),
                nn.BatchNorm2d(64), 
                nn.ReLU(inplace=True), 
                nn.Conv2d(64, is_inplanes, kernel_size=3, stride=2, padding=1, bias=False)
                ]
            self.maps_transform = nn.Sequential(*mt_layers)  

        if deep_fusion:
            self.is_trans_1 = ConvBnRelu(is_inplanes, out_shape[3], kernel_size=3, stride=1) 
            self.is_trans_2 = ConvBnRelu(out_shape[3], out_shape[2], kernel_size=3, stride=2) 
            self.is_trans_3 = ConvBnRelu(out_shape[2], out_shape[1], kernel_size=3, stride=2) 
            self.is_trans_4 = ConvBnRelu(out_shape[1], out_shape[0], kernel_size=3, stride=2)             

    def forward(self, itermap):

        itermap_feat = self.maps_transform(itermap)

        if self.deep_fusion:
            # add iter features before opm module
            itermap_feat_1 = self.is_trans_1(itermap_feat)
            itermap_feat_2 = self.is_trans_2(itermap_feat_1)
            itermap_feat_3 = self.is_trans_3(itermap_feat_2)
            itermap_feat_4 = self.is_trans_4(itermap_feat_3)
            iter_side_feats = [itermap_feat_4, itermap_feat_3, itermap_feat_2, itermap_feat_1]
            # print(is_t_1.shape, is_t_2.shape, is_t_3.shape, is_t_4.shape)
            # pdb.set_trace() 
        else:
            iter_side_feats = None
    
        if self.backbone_name.startswith("segformer") or self.backbone_name.startswith("swinformer") or self.backbone_name.startswith("plainvit_"):
            return itermap, iter_side_feats
        elif self.backbone_name.startswith("resnest"):
            itermap_feat = self.additional_cbr(itermap_feat)
            return itermap_feat, iter_side_feats
        else:
            return itermap_feat, iter_side_feats 


class IterDecoder(nn.Module):
    def __init__(self,
                 out_shape,
                 num_decoder_end_c, 
                 bb_feature_scales,
                 num_ori_out=1,
                 use_pixel_shuffle=True,
                 orientation_path=False,
                 in_channels=6,
                 deep_fusion=True,
                 **kwargs):

        super().__init__()

        self.orientation_path = orientation_path    
        self.deep_fusion = deep_fusion

        if self.orientation_path:
            # in_channels or just rgb 3
            self.ori_convolution = torch.nn.Sequential(
                ConvBnRelu(in_channels, num_decoder_end_c[0], 1),
                ConvBnRelu(num_decoder_end_c[0], num_decoder_end_c[0], 3),
                ConvBnRelu(num_decoder_end_c[0], num_decoder_end_c[0], 3),
                ConvBnRelu(num_decoder_end_c[0], num_decoder_end_c[0], 3),
                ConvBnRelu(num_decoder_end_c[0], num_decoder_end_c[0], 3),
                ConvBnRelu(num_decoder_end_c[0], num_decoder_end_c[0], 3),
                ConvBnRelu(num_decoder_end_c[0], num_decoder_end_c[0], 3),
                ConvBnRelu(num_decoder_end_c[0], num_decoder_end_c[1], 1)
                )
    
            self.ori_decoder = BasicDecoder(
                feature_channels=[out_shape[0], out_shape[2], num_decoder_end_c[1]],
                feature_scales=bb_feature_scales[::2],
                path_name='ori',
                num_end_out=num_ori_out,
                use_pixel_shuffle=False,
            )
              

        self.ImP = torch.nn.Sequential(
            ConvBnRelu(3, num_decoder_end_c[0], 3),
            ConvBnRelu(num_decoder_end_c[0], num_decoder_end_c[0], 3),
            ConvBnRelu(num_decoder_end_c[0], num_decoder_end_c[0], 3),
            ConvBnRelu(num_decoder_end_c[0], num_decoder_end_c[0], 3),
            ConvBnRelu(num_decoder_end_c[0], num_decoder_end_c[0], 3),
            ConvBnRelu(num_decoder_end_c[0], num_decoder_end_c[0], 3),
            ConvBnRelu(num_decoder_end_c[0], num_decoder_end_c[0], 3),
            ConvBnRelu(num_decoder_end_c[0], num_decoder_end_c[1], 1)
        )

        self.boundary_decoder = BasicDecoder(
            feature_channels=[out_shape[0], out_shape[1], out_shape[2], out_shape[3], num_decoder_end_c[1]],
            feature_scales=bb_feature_scales,
            path_name='boundary',
            num_end_out=1,
            use_pixel_shuffle=use_pixel_shuffle
        )

        self.encoder_sides = nn.ModuleList()
        self.fem_has = ['fem', 'no', 'fem', 'no']
        if backbone_name.startswith("swinformer") and backbone_name.endswith("large"):
            sc = [3, 9]
        else:
            sc = [5, 7]
        # print("fem layer", sc)

        for num_c, l_name in zip(out_shape, self.fem_has):
            layer = FEM(num_c, 1, sc[0], sc[1]) if l_name == 'fem' else torch.nn.Sequential()
            self.encoder_sides.append(layer)

        # deep fuse?: two layers?
        self.fuse = torch.nn.Sequential(
            conv1x1(5, 1)
        )

    def forward(self, inputs, side_feats, iter_feats):

        imgs = inputs[:, 0:3, :, :]

        assert len(side_feats) == len(self.encoder_sides)
        
        if self.deep_fusion:
            for i in range(len(side_feats)):
                if self.fem_has[i] == "fem":
                    side_feats[i] = side_feats[i] + iter_feats[i]
               
        side_feats = [layer(feat) for feat, layer in zip(side_feats, self.encoder_sides)]
     
        boundary_outsides = self.boundary_decoder(side_feats + [self.ImP(imgs)])
        boundary_outsides = [crop(boundary_outside, inputs)
                             for boundary_outside in boundary_outsides]

        boundary_fuse = self.fuse(torch.cat(boundary_outsides, 1))
        boundary_outsides.append(boundary_fuse)

        orientation_x = None
        if self.orientation_path:
            orientation_x = self.ori_decoder([side_feats[0], side_feats[2], self.ori_convolution(inputs)])[0]
        return boundary_outsides, orientation_x


class iTPENet(nn.Module):
    # @serialize
    def __init__(self,
                 backbone_name='resnet50',
                 num_ori_out=1,
                 use_pixel_shuffle=True,
                 orientation_path=False,
                 lite=False,
                 in_channels=6,
                 deep_fusion=True,
                 bbfeatures_scale=1,
                 use_res50_shape=False,
                 use_fuse_head=True,
                 backbone_lr_mult=1.0, 
                 **kwargs,
                 ):

        super().__init__()
        
        # if backbone_name.startswith("plainvit_"):   
        #     deep_fusion = False 
        self.backbone = FusionPath(backbone_name=backbone_name,
                                      in_channels=in_channels,
                                      bbfeatures_scale=bbfeatures_scale,
                                      use_res50_shape=False,
                                      **kwargs)

        num_decoder_end_c, bb_feature_scales, out_shape, is_inplanes = self.backbone.get_params()

        self.interHead = InP(out_shape,
                                        in_channels=in_channels,
                                        backbone_name=backbone_name,
                                        deep_fusion=deep_fusion,
                                        is_inplanes=is_inplanes,
                                        simple_map="v2",
                                        **kwargs)

        self.occDecoder = IterDecoder(out_shape,
                                      num_decoder_end_c, 
                                      bb_feature_scales,
                                      num_ori_out=num_ori_out,
                                      use_pixel_shuffle=use_pixel_shuffle,
                                      orientation_path=orientation_path,
                                      in_channels=in_channels,
                                      deep_fusion=deep_fusion,
                                      **kwargs)


        # backbone learning rate
        # if backbone_lr_mult != 1.0:
        # self.backbone.apply(LRMult(0.1))
        #     print("Change backbone lr rate to {}".format(backbone_lr_mult))

        self._initialize_weights()

    def forward(self, inputs):
        imgs = inputs[:, 0:3, :, :]
        itermap = inputs[:, 3:, :, :]  

        itermap_feat, iter_side_feats = self.interHead(itermap)
        side_feats = self.backbone(imgs, itermap_feat)
        boundary_outsides, orientation_x = self.occDecoder(inputs, side_feats, iter_side_feats)

        return boundary_outsides, orientation_x

    @staticmethod
    def getOrientation(orientation_x):
        return torch.atan2(orientation_x[:, 0], orientation_x[:, 1]).unsqueeze(1)

    @staticmethod
    def getBoundary(boundary_outsides):
        return torch.sigmoid(boundary_outsides[-1])

    def load_backbone_pretrained(self, pretrained_path='data/resnet50-25c4b509.pth'):
        # print(os.getcwd())
        keys = self.backbone.load_state_dict(torch.load(pretrained_path), strict=False)
        if len(keys.missing_keys) > 0:
            logger.info(f"=> Pretrained: missing_keys [{', '.join(keys.missing_keys)}]")
        if len(keys.unexpected_keys) > 0:
            logger.info(f"=> Pretrained: unexpected_keys [{', '.join(keys.unexpected_keys)}]")
        logger.info(f'=> Backbone pretrained: loaded from {pretrained_path}\n')

    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_uniform_(m.weight, a=math.sqrt(5))
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)

                
def conv3x3(in_planes, out_planes, stride=1):
    """3x3 convolution with padding"""
    return nn.Conv2d(in_planes, out_planes, kernel_size=3, stride=stride,
                     padding=1, bias=True)


def conv1x1(in_planes, out_planes, stride=1):
    """1x1 convolution"""
    return nn.Conv2d(in_planes, out_planes, kernel_size=1, stride=stride, bias=True)

