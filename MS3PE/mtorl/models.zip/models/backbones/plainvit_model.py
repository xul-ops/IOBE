import math
import torch.nn as nn

import numpy as np

from .models_vit import VisionTransformer, PatchEmbed
# from .swin_transformer import SwinTransfomerSegHead
from .transformer_helper.cross_entropy_loss import CrossEntropyLoss
from .pos_embed import interpolate_pos_embed, interpolate_pos_embed_inference


def plainvit(MODEL_NAME, backbone_path=None, random_crop_size=(320, 320), **kwargs):
    # num_max_points = 24
    crop_size = (320, 320) # (448, 448) # random_crop_size # (1024, 768)   
    patch_size=(16,16) # (20,20)
         
    upsample = "x1"
    random_split = False
 
    if MODEL_NAME == 'plainvit_base':   
 
        backbone_params = dict(
            img_size=crop_size,
            patch_size=patch_size,
            in_chans=3,
            embed_dim=768,
            depth=12,
            num_heads=12,
            mlp_ratio=4, 
            qkv_bias=True,
        )

        neck_params = dict(
            in_dim = 768,
            out_dims = [128, 256, 512, 1024],
        )

        model = PlainVitModel(
            backbone_params=backbone_params,
            neck_params=neck_params,
            random_split=random_split,
        )
        feats_shape = np.array([1024, 512, 256, 128])


    elif MODEL_NAME == 'plainvit_large':   

        backbone_params = dict(
            img_size=crop_size,
            patch_size=patch_size,
            in_chans=3,
            embed_dim=1024,
            depth=24,
            num_heads=16,
            mlp_ratio=4, 
            qkv_bias=True,
        )

        neck_params = dict(
            in_dim = 1024,
            out_dims = [192, 384, 768, 1536],
        )

        model = PlainVitModel(
            backbone_params=backbone_params,
            neck_params=neck_params,
            random_split=random_split,
        )
        feats_shape = np.array([1536, 768, 384, 192])


    # elif MODEL_NAME == 'plainvit_huge':   
    #     backbone_params = dict(
    #         img_size=crop_size,
    #         patch_size=(14,14),
    #         in_chans=3,
    #         embed_dim=1280,
    #         depth=32,
    #         num_heads=16,
    #         mlp_ratio=4, 
    #         qkv_bias=True,
    #     )

    #     neck_params = dict(
    #         in_dim = 1280,
    #         out_dims = [240, 480, 960, 1920],
    #     )

    #     model = PlainVitModel(
    #         backbone_params=backbone_params,
    #         neck_params=neck_params,
    #         random_split=random_split,
    #     )
    #     feats_shape = np.array([1920, 960, 480, 240])

    model.backbone.init_weights_from_pretrained(backbone_path)

    return model, feats_shape


class SimpleFPN(nn.Module):
    def __init__(self, in_dim=768, out_dims=[128, 256, 512, 1024]):
        super().__init__()
        self.down_4_chan = max(out_dims[0]*2, in_dim // 2)
        self.down_4 = nn.Sequential(
            nn.ConvTranspose2d(in_dim, self.down_4_chan, 2, stride=2),
            nn.GroupNorm(1, self.down_4_chan),
            nn.GELU(),
            nn.ConvTranspose2d(self.down_4_chan, self.down_4_chan // 2, 2, stride=2),
            nn.GroupNorm(1, self.down_4_chan // 2),
            nn.Conv2d(self.down_4_chan // 2, out_dims[0], 1),
            nn.GroupNorm(1, out_dims[0]),
            nn.GELU()
        )
        self.down_8_chan = max(out_dims[1], in_dim // 2)
        self.down_8 = nn.Sequential(
            nn.ConvTranspose2d(in_dim, self.down_8_chan, 2, stride=2),
            nn.GroupNorm(1, self.down_8_chan),
            nn.Conv2d(self.down_8_chan, out_dims[1], 1),
            nn.GroupNorm(1, out_dims[1]),
            nn.GELU()
        )
        self.down_16 = nn.Sequential(
            nn.Conv2d(in_dim, out_dims[2], 1),
            nn.GroupNorm(1, out_dims[2]),
            nn.GELU()
        )
        self.down_32_chan = max(out_dims[3], in_dim * 2)
        self.down_32 = nn.Sequential(
            nn.Conv2d(in_dim, self.down_32_chan, 2, stride=2),
            nn.GroupNorm(1, self.down_32_chan),
            nn.Conv2d(self.down_32_chan, out_dims[3], 1),
            nn.GroupNorm(1, out_dims[3]),
            nn.GELU()
        )

        self.init_weights()

    def init_weights(self):
        pass

    def forward(self, x):
        x_down_4 = self.down_4(x)
        x_down_8 = self.down_8(x)
        x_down_16 = self.down_16(x)
        x_down_32 = self.down_32(x)

        return [x_down_4, x_down_8, x_down_16, x_down_32]
        

class PlainVitModel(nn.Module):
    def __init__(
        self,
        backbone_params={},
        neck_params={}, 
        head_params={},
        random_split=False,
        **kwargs
        ):

        super().__init__()
        self.random_split = random_split
        # if self.with_prev_mask else 2, 

        self.patch_embed_coords = PatchEmbed(
            img_size= backbone_params['img_size'],
            patch_size=backbone_params['patch_size'], 
            in_chans=3,
            embed_dim=backbone_params['embed_dim'],
        )

        self.backbone = VisionTransformer(**backbone_params)
        self.neck = SimpleFPN(**neck_params)
        # self.head = SwinTransfomerSegHead(**head_params)

    def forward(self, image, coord_features=None):
        coord_features = self.patch_embed_coords(coord_features)
        backbone_features = self.backbone.forward_backbone(image, coord_features, self.random_split)

        # Extract 4 stage backbone feature map: 1/4, 1/8, 1/16, 1/32
        B, N, C = backbone_features.shape
        grid_size = self.backbone.patch_embed.grid_size

        backbone_features = backbone_features.transpose(-1,-2).view(B, C, grid_size[0], grid_size[1])
        multi_scale_features = self.neck(backbone_features)

        return multi_scale_features
