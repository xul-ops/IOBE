from .resnet import resnet
from .hrnet_ocr import hrnet
from .resnest.resnest import resnest
from .segformer.segformer_model import segformer
from .swin_transformer import swinformer
from .hrformer import hrformer
from .plainvit_model import plainvit


# source codes copied from https://github.com/uncbiag/SimpleClick/tree/v1.0/isegm/model/modeling
# and https://github.com/zhanghang1989/ResNeSt/tree/master
# etc.