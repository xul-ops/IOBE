# from isegm.utils.exp_imports.default import *
from mtorl.models.losses.isloss import *
# some models here are not working

def init_ritm(cfg):

    MODEL_NAME = cfg.model_name
    loss_type = cfg.aba_loss_type
    backbone_path = cfg.bankbone_pretrain

    if MODEL_NAME == 'ritm_hrnet18':
        model = HRNetModel(width=18, ocr_width=64, with_aux_output=True, use_leaky_relu=True,
                       use_rgb_conv=False, use_disks=True, norm_radius=5,
                       with_prev_mask=True)

    elif MODEL_NAME == 'ritm_hrnet18s':
        model = HRNetModel(width=18, ocr_width=48, small=True, with_aux_output=True, use_leaky_relu=True, 
                        use_rgb_conv=False, use_disks=True, norm_radius=5, with_prev_mask=True)

    elif MODEL_NAME == 'ritm_hrnet32':
        model = HRNetModel(width=32, ocr_width=128, with_aux_output=True, use_leaky_relu=True, 
                        use_rgb_conv=False, use_disks=True, norm_radius=5, with_prev_mask=True)


    model.cuda()
    model.apply(initializer.XavierGluon(rnd_type='gaussian', magnitude=2.0))
    model.feature_extractor.load_pretrained_weights(backbone_path)
    
    # loss_type = "CCE"  # CCE FL AL original
    print()
    print("RITM use ", loss_type, "loss to train the models!")
    print()
    if loss_type != "original":
        criterion = RITM_OccLoss(loss_type=loss_type, boundary_lambda=cfg.boundary_lambda).cuda()
    else:
        criterion = RITMLoss().cuda()
    
    return model, criterion
    

def init_cdnet(cfg):

    MODEL_NAME = cfg.model_name
    loss_type = cfg.aba_loss_type
    backbone_path = cfg.bankbone_pretrain

    # model_cfg.crop_size = (384, 384)
    # model_cfg.num_max_points = 24
    model = DeeplabModel(backbone='resnet34', deeplab_ch=128, aspp_dropout=0.20, use_leaky_relu=True, 
                        use_rgb_conv=False, use_disks=True, norm_radius=5,  with_prev_mask=False)
    model.cuda()
    model.apply(initializer.XavierGluon(rnd_type='gaussian', magnitude=2.0))
    model.feature_extractor.load_pretrained_weights(backbone_path)    
    
    # loss_type = "CCE"  # CCE FL AL original
    print()
    print("CDNet use ", loss_type, "loss to train the models!")
    print()
    if loss_type != "original":
        criterion = CDNet_OccLoss(loss_type=loss_type, use_diversity_loss=True).cuda()
    else:
        criterion = CDNetLoss(use_diversity_loss=True, boundary_lambda=cfg.boundary_lambda).cuda()
    
    return model, criterion

    
def init_focalclick(cfg, backbone_path="", pipeline_version = 's2'):
    # model_cfg.crop_size = (256, 256)
    # model_cfg.num_max_points = 24
    # if self.pipeline_version == 's1':
    #         base_radius = 3
    #     else:
    #         base_radius = 5
    MODEL_NAME = cfg.model_name
    loss_type = cfg.aba_loss_type
    backbone_path = cfg.bankbone_pretrain
    
    if MODEL_NAME == 'focal_segformerB0':

        model = SegFormerModel( pipeline_version = pipeline_version, model_version = 'b0',
                               use_leaky_relu=True, use_rgb_conv=False, use_disks=True, norm_radius=5, binary_prev_mask=False,
                               with_prev_mask=True, with_aux_output=True)
        
    elif MODEL_NAME == 'focal_segformerB3':
        model = SegFormerModel( pipeline_version = pipeline_version, model_version = 'b3',
                       use_leaky_relu=True, use_rgb_conv=False, use_disks=True, norm_radius=5, binary_prev_mask=False,
                       with_prev_mask=True, with_aux_output=True)
    
    elif MODEL_NAME == 'focal_hrnet18s':
        model = HRNetModel(pipeline_version = pipeline_version, width=18, ocr_width=48, small=True, with_aux_output=True, use_leaky_relu=True,
                       use_rgb_conv=False, use_disks=True, norm_radius=5,
                       with_prev_mask=True)
        model.apply(initializer.XavierGluon(rnd_type='gaussian', magnitude=2.0))          

     
    elif MODEL_NAME == 'focal_hrnet32':
        model = HRNetModel(pipeline_version, width=32, ocr_width=128, small=False, with_aux_output=True, use_leaky_relu=True,
                       use_rgb_conv=False, use_disks=True, norm_radius=5,
                       with_prev_mask=True)
        model.apply(initializer.XavierGluon(rnd_type='gaussian', magnitude=2.0))
        
    model.cuda()
    model.feature_extractor.load_pretrained_weights(backbone_path)

    
    print()
    print("Focalclick use ", loss_type, "loss to train the models!")
    print()
    if loss_type != "original":
        criterion = Focal_OccLoss(loss_type=loss_type, boundary_lambda=cfg.boundary_lambda).cuda()
    else:
        criterion = FocalLoss().cuda()
    
    return model, criterion

    
    
def init_simpleclick(cfg): 
    # num_max_points = 24
    from isegm.model.modeling.transformer_helper.cross_entropy_loss import CrossEntropyLoss
    crop_size = (320, 320)
    upsample = "x1"
    random_split = False
    MODEL_NAME = cfg.model_name
    loss_type = cfg.aba_loss_type
    backbone_path = cfg.bankbone_pretrain
 
    if MODEL_NAME == 'plainvit_base448':   
 
        backbone_params = dict(
            img_size=crop_size,
            patch_size=(16,16),
            in_chans=3,
            embed_dim=768,
            depth=12,
            num_heads=12,
            mlp_ratio=4, 
            qkv_bias=True,
        )

        neck_params = dict(
            in_dim = 768,
            out_dims = [128, 256, 512, 1024],
        )

        head_params = dict(
            in_channels=[128, 256, 512, 1024],
            in_index=[0, 1, 2, 3],
            dropout_ratio=0.1,
            num_classes=1,
            loss_decode=CrossEntropyLoss(),
            align_corners=False,
            upsample=upsample,
            channels={'x1':256, 'x2': 128, 'x4': 64}[upsample],
        )


    elif MODEL_NAME == 'plainvit_large448':   

        backbone_params = dict(
            img_size=crop_size,
            patch_size=(16,16),
            in_chans=3,
            embed_dim=1024,
            depth=24,
            num_heads=16,
            mlp_ratio=4, 
            qkv_bias=True,
        )

        neck_params = dict(
            in_dim = 1024,
            out_dims = [192, 384, 768, 1536],
        )

        head_params = dict(
            in_channels=[192, 384, 768, 1536],
            in_index=[0, 1, 2, 3],
            dropout_ratio=0.1,
            num_classes=1,
            loss_decode=CrossEntropyLoss(),
            align_corners=False,
            upsample=upsample,
            channels={'x1': 256, 'x2': 128, 'x4': 64}[upsample],
        )



    elif MODEL_NAME == 'plainvit_huge448':   
        backbone_params = dict(
            img_size=crop_size,
            patch_size=(14,14),
            in_chans=3,
            embed_dim=1280,
            depth=32,
            num_heads=16,
            mlp_ratio=4, 
            qkv_bias=True,
        )

        neck_params = dict(
            in_dim = 1280,
            out_dims = [240, 480, 960, 1920],
        )

        head_params = dict(
            in_channels=[240, 480, 960, 1920],
            in_index=[0, 1, 2, 3],
            dropout_ratio=0.1,
            num_classes=1,
            loss_decode=CrossEntropyLoss(),
            align_corners=False,
            upsample=upsample,
            channels={'x1':256, 'x2': 128, 'x4': 64}[upsample]
        )


    elif MODEL_NAME == 'plainvit_xtiny448':     
        backbone_params = dict(
            img_size=crop_size,
            patch_size=(16,16),
            in_chans=3,
            embed_dim=160,
            depth=8,
            num_heads=4,
            mlp_ratio=4, 
            qkv_bias=True,
        )

        neck_params = dict(
            in_dim = 160,
            out_dims = [96, 192, 288, 384],
        )

        head_params = dict(
            in_channels=[96, 192, 288, 384],
            in_index=[0, 1, 2, 3],
            dropout_ratio=0.1,
            num_classes=1,
            loss_decode=CrossEntropyLoss(),
            align_corners=False,
            upsample=upsample,
            channels=128
        )




    model = PlainVitModel(
        use_disks=True,
        norm_radius=5,
        with_prev_mask=True,
        backbone_params=backbone_params,
        neck_params=neck_params,
        head_params=head_params,
        random_split=random_split,
    )

    model.cuda()
    model.backbone.init_weights_from_pretrained(backbone_path)
    

    print()
    print("Simpleclick use ", loss_type, "loss to train the models!")
    print()
    if loss_type != "original":
        criterion = Simple_OccLoss(loss_type=loss_type, boundary_lambda=cfg.boundary_lambda).cuda()
    else:
        criterion = SimpleLoss().cuda()  
        
    return model, criterion



def init_acc99net(cfg):

    from mtorl.models.acc99net import ModelBuilder, MattingModuleSingleGpu

    MODEL_NAME = cfg.model_name
    loss_type = cfg.aba_loss_type
    backbone_path = cfg.bankbone_pretrain

    builder = ModelBuilder()
    net_encoder = builder.build_encoder(use_mask_input=True)

    net_decoder = builder.build_decoder(use_mask_input=True, use_usr_encoder=True, gf=True)

    model = MattingModuleSingleGpu(net_encoder, net_decoder)

    model.cuda()

    sd = torch.load(backbone_path)
    model.load_state_dict(sd, strict=False)

    criterion = OccLoss(loss_type=loss_type, boundary_lambda=cfg.boundary_lambda).cuda()

    return model, criterion



def init_fcanet(cfg):
    from mtorl.models.fcanet import FCANet
    MODEL_NAME = cfg.model_name
    loss_type = cfg.aba_loss_type
    backbone_path = cfg.bankbone_pretrain

    model = FCANet()
    model.cuda()

    model.backbone_pre._load_pretrained_model(backbone_path)
    model.backbone_last._load_pretrained_model(backbone_path)

    criterion = OccLoss(loss_type=loss_type, boundary_lambda=cfg.boundary_lambda).cuda()

    return model, criterion


def init_deepthin(cfg):
    from mtorl.models.deepthin import TOSNet, Bottleneck
    MODEL_NAME = cfg.model_name
    loss_type = cfg.aba_loss_type
    backbone_path = cfg.bankbone_pretrain

    model = TOSNet(Bottleneck, [3, 4, 23, 3], n_inputs=6, n_classes=1, os=16)
    model.cuda()

    model.load_pretrained_weights(6, 'imagenet', backbone=backbone_path)

    criterion = OccLoss(loss_type=loss_type, boundary_lambda=cfg.boundary_lambda).cuda()


    return model, criterion


def init_adaptiveclick(cfg):
    from isegm.model.is_adaptiveclick_model import AdaptiveClickModel
    MODEL_NAME = cfg.model_name
    loss_type = cfg.aba_loss_type
    backbone_path = cfg.bankbone_pretrain
    

    model_cfg = edict()
    model_cfg.crop_size = (448, 448)
    model_cfg.num_max_points = 24

    model = AdaptiveClickModel(model_cfg)
    model.backbone.init_weights_from_pretrained(backbone_path)
    model.cuda()
    
    
    criterion = Adaptiveclick_OccLoss(loss_type=loss_type, boundary_lambda=cfg.boundary_lambda).cuda()
    
    return model, criterion


    

def init_EMC(cfg):   
    from isegm.model.is_refine_model import HRNetRefineModel
    from isegm.model.is_refine_segformer_model import SegFormerModel

    MODEL_NAME = cfg.model_name
    loss_type = cfg.aba_loss_type
    backbone_path = cfg.bankbone_pretrain

    model_cfg = edict()
    model_cfg.crop_size = (320, 320)
    # model_cfg.num_max_points = 24

    if MODEL_NAME == 'emc_segformerB0':

        refiner_conf = dict(conv_layer='xconv2', mid_dims=64, corr_channel=64)  
        model = SegFormerModel(model_version = 'b0',
                       use_leaky_relu=True, use_rgb_conv=False, use_disks=True, norm_radius=5, binary_prev_mask=False,
                       with_prev_mask=True, with_aux_output=True,
                       refiner_conf=refiner_conf, only_first_click=True)

        
    elif MODEL_NAME == 'emc_segformerB3':
        refiner_conf = dict(conv_layer='xconv2', mid_dims=96, corr_channel=96)
        
        model = SegFormerModel(model_version = 'b3',
                        use_leaky_relu=True, use_rgb_conv=False, use_disks=True, norm_radius=5, binary_prev_mask=False,
                        with_prev_mask=True, with_aux_output=True, refiner_conf=refiner_conf, only_first_click=True)

    
    elif MODEL_NAME == 'emc_hrnet18s':
    
        refiner_conf = dict(conv_layer='xconv2', mid_dims=64, corr_channel=64)
        model = HRNetRefineModel(width=18, ocr_width=48, small=True, with_aux_output=True, use_leaky_relu=True,
                       use_rgb_conv=False, use_disks=True, norm_radius=5,
                       with_prev_mask=True, refiner_conf=refiner_conf, only_first_click=True)

        model.apply(initializer.XavierGluon(rnd_type='gaussian', magnitude=2.0))          
     
    elif MODEL_NAME == 'emc_hrnet18':

        refiner_conf = dict(conv_layer='xconv2', mid_dims=96, corr_channel=96)
    
        model = HRNetRefineModel(width=18, ocr_width=64, small=False, with_aux_output=True, use_leaky_relu=True,
                       use_rgb_conv=False, use_disks=True, norm_radius=5, with_prev_mask=True, refiner_conf=refiner_conf, only_first_click=True)

        model.apply(initializer.XavierGluon(rnd_type='gaussian', magnitude=2.0))


    elif MODEL_NAME == 'emc_hrnet32':
        refiner_conf = dict(conv_layer='xconv2', mid_dims=96, corr_channel=96)
        
        model = HRNetRefineModel(width=32, ocr_width=128, small=False, with_aux_output=True, use_leaky_relu=True,
                        use_rgb_conv=False, use_disks=True, norm_radius=5,
                        with_prev_mask=True,refiner_conf=refiner_conf, only_first_click=True)

        model.apply(initializer.XavierGluon(rnd_type='gaussian', magnitude=2.0))

    model.cuda()
    model.feature_extractor.load_pretrained_weights(backbone_path)

    return 
    
    
def init_interformer(cfg):    

    MODEL_NAME = cfg.model_name
    loss_type = cfg.aba_loss_type
    backbone_path = cfg.bankbone_pretrain
    
    from interformer.segmentors import ClickSegmentor

    # for tiny
    custom_imports = dict(imports=['interformer'], allow_failed_imports=False)

    # model
    norm_cfg = dict(type='SyncBN', requires_grad=True)
    model = dict(
        type='ClickSegmentor',
        pretrained='pretrain/mae_pretrain_vit_large_mmcls.pth',
        backbone=dict(
            type='MAEWithSimpleFPN',
            img_size=(512, 512),
            patch_size=16,
            in_channels=3,
            embed_dims=1024,
            num_layers=24,
            num_heads=16,
            mlp_ratio=4,
            out_indices=-1,
            attn_drop_rate=0.0,
            drop_path_rate=0.1,
            norm_cfg=dict(type='LN', eps=1e-6),
            act_cfg=dict(type='GELU'),
            norm_eval=False,
            init_values=1.0,
            fpn_cfg=dict(
                type='SimpleFPN',
                rescales=(4, 2, 1, 0.5),
                out_dims=(32, 64, 128, 256))),
        neck=dict(
            type='IMSA',
            target_size=(512, 512),
            in_channels=[32, 64, 128, 256],
            num_heads=(1, 2, 4, 8),
            depths=(2, 2, 6, 3),
            refine_start=(1, 1, 2, 1),
            mlp_ratio=(8, 8, 4, 4)),
        decode_head=dict(
            type='UPerHead',
            in_channels=[32, 64, 128, 256],
            in_index=[0, 1, 2, 3],
            pool_scales=(1, 2, 3, 6),
            channels=64,
            dropout_ratio=0.1,
            num_classes=2,
            norm_cfg=norm_cfg,
            align_corners=False,
            loss_decode=[
                dict(type='NormalizedFocalLoss', loss_weight=1.0),
                dict(type='BinaryIoU')]),
        auxiliary_head=dict(
            type='FCNHead',
            in_channels=128,
            in_index=2,
            channels=64,
            num_convs=1,
            concat_input=False,
            dropout_ratio=0.1,
            num_classes=2,
            norm_cfg=norm_cfg,
            align_corners=False,
            loss_decode=dict(type='NormalizedFocalLoss', loss_weight=0.4)),
        train_cfg=dict(
            max_num_clicks=20,
            gamma=0.6,
            inner_radius=5,
            outer_radius=0,
            sfc_inner_k=1.7),
        test_cfg=dict(
            num_clicks=20,
            inner_radius=5,
            outer_radius=0))

    # for light
    # _base_ = ['interformer_tiny.py']
    # model = dict(
    #     pretrained='pretrain/mae_pretrain_vit_base_mmcls.pth',
    #     backbone=dict(embed_dims=768, num_layers=12, num_heads=12),
    #     neck=dict(depths=(1, 1, 2, 1)))

    pass    
    


def init_focuscut(loss_type="CCE"):
    # from nnet.model.hrcnet_base.my_net import MyNet as CutNet
    model = CutNet(input_channel=6, output_stride=16,if_sync_bn=False,
                   special_lr=1.0, size=abs(384), aux_parameter={"backbone":'resnet50'}).cuda()
                   
    # loss_type = "CCE"  # CCE FL AL original
    print()
    print("Focuscut use ", loss_type, "loss to train the models!")
    print()

    return model 
    

def init_gpcis(MODEL_NAME="gpcis_resnet50", loss_type="CCE"):
    import importlib
    # + cfg.gp_model
    GpModel = importlib.import_module('isegm.model.is_gp_resnet50').GpModel
    model = GpModel(backbone = 'resnet50', use_leaky_relu=True, use_disks=True,  binary_prev_mask=False, with_prev_mask=True, weight_dir="../pretrained/gluon_resnet50_v1s-1762acc0.pth")
    model.cuda()
    model.apply(initializer.XavierGluon(rnd_type='gaussian', magnitude=2.0))
    model.model.load_pretrained_weights()
                   
    # loss_type = "CCE"  # CCE FL AL original
    if loss_type != "original":
        criterion = GPCIS_OccLoss(loss_type=loss_type).cuda()
    else:
        criterion = None # since NFL not wotk

    print()
    print("GPCIS use ", loss_type, "loss to train the models!")
    print()

    return model, criterion
    

def init_CRF_ICL(cfg):  
    pass  


def init_piclick(): 
    pass  
    
    
    
    
    
    
