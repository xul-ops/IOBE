function [thresh, cntR, sumR, cntP, sumP, VB, VO] = EvaluateSingle(pb, gt, prFile, varargin)
    % [thresh,cntR,sumR,cntP,sumP, VB, VO] = EvaluateSingle(pb, gt, prFile, varargin)
    %
    % Calculate precision/recall curve.
    %
    % INPUT
    %	pb  :       [N,M,2], prediction results
    %               the first is soft boundary map
    %               the second is occlusion orientation map
    %
    %	gt	:       Corresponding groundtruth
    %               [N,M,2*t], where t is the number of gt annotation
    %
    %   prFile  :   Temporary output for this image.
    %
    % OUTPUT
    %	thresh		Vector of threshold values.
    %	cntR,sumR	Ratio gives recall.
    %	cntP,sumP	Ratio gives precision.
    %   VB, VO      Visulization for Bounadry and Occlusion orientation results.
    
    % 0.0006, 0.0075, 0.003
    opt = struct('nthresh', 99, 'maxDist', 0.0006, 'thinpb', 1, ...,
    'w_occ', 0, 'renormalize', 1, 'rank_score', [], 'debug', 0, 'fastmode', 0);
    opt = CatVarargin(opt, varargin);
    nthresh = opt.nthresh;
    maxDist = opt.maxDist; % 0.0006
    thinpb = opt.thinpb;
    rank_score = opt.rank_score;

    thresh = linspace(1 / (nthresh + 1), 1 - 1 / (nthresh + 1), nthresh)';
    % zero all counts
    if opt.w_occ
        cntR_occ = zeros(size(thresh));
        cntP_occ = zeros(size(thresh));
    end

    cntR = zeros(size(thresh));

    cntP = zeros(size(thresh));
    sumP = zeros(size(thresh));

    pb_num = size(pb, 3);

    if pb_num >= 2 && opt.w_occ
        occ = pb(:, :, 2);
        pb = pb(:, :, 1);
    end

    if size(gt, 3) >= 2 || opt.w_occ
        % first is gt edge, second is gt occ
        gt_occ = gt(:, :, 2:2:end);
        gt = gt(:, :, 1:2:end);
    end
    
    if thinpb && ~strcmp(opt.DataSet, 'synocc_test')
        % perform nms operation
        pb = edge_nms(pb, 0);
        if opt.debug; imshow(1 - pb); pause; end
    end
    
    % if strcmp(opt.DataSet, 'synocc_test')
    %     pb = imresize(pb, 0.5, 'bicubic');
    % end        

    img_name = split(prFile, '.');
    % imwrite(mat2gray(gt), strcat(img_name{1}, '_gt.png'));
    % fprintf(class(pb))
    imwrite(mat2gray(1 - pb), strcat(img_name{1}, '_nms.png'));

    if ~isempty(rank_score);
        pb(pb > 0) = rank_score(pb > 0);
    end

    if opt.renormalize
        id = pb > 0;
        pb(id) = (pb(id) - min(pb(id))) / (max(pb(id)) - min(pb(id)) + eps);
    end

    sumR = 0;
    if (nargout >= 6), VB = zeros([size(pb) 3 nthresh]); end
    if (nargout >= 7), VO = zeros([size(pb) 4 nthresh]); end

    for i = 1:size(gt, 3),
        sumR = sumR + sum(sum(gt(:, :, i)));
    end

    sumR = sumR .* ones(size(thresh));
    % match1_all = zeros(size(gt));

    % Note that: The fastmode written by Peng Wang, which
    % refer to https://github.com/pengwangucla/MatLib/blob/master/Evaluation/EvaluateBoundary/EvaluateSingle.m#L82
    % And the result will drop. You can only use to test.
    % The other statistical method modified by Guoxia Wang from
    % https://github.com/pdollar/edges/blob/master/edgesEvalImg.m#L61

    bins_num = 8;
    bins_cntR = zeros(bins_num, nthresh);
    bins_sumR = zeros(bins_num, nthresh);
    bins_cntP = zeros(bins_num, nthresh);
    bins_sumP = zeros(bins_num, nthresh);
    bins_cntR_occ = zeros(bins_num, nthresh);
    bins_cntP_occ = zeros(bins_num, nthresh);

    if (opt.fastmode)

        for t = nthresh:-1:1,
            % pb(pb<thresh(t)) = 0;
            bmap = pb >= thresh(t);

            if t < nthresh,
                % consider only new boundaries
                bmap = bmap .*~(pb >= thresh(t + 1));
                % these stats accumulate
                cntR(t) = cntR(t + 1);
                cntP(t) = cntP(t + 1);
                sumP(t) = sumP(t + 1);

                if opt.w_occ
                    cntR_occ(t) = cntR_occ(t + 1);
                    cntP_occ(t) = cntP_occ(t + 1);
                end

            end

            % bmap = RmSmallEdge(bmap, 5);
            % accumulate machine matches, since the machine pixels are
            % allowed to match with any segmentation
            accP = zeros(size(bmap));
            if opt.w_occ; accP_occ = accP; end
            % compare to each seg in turn
            for i = 1:size(gt, 3),
                % compute the correspondence
                [match1, match2] = correspondPixels(double(bmap), double(gt(:, :, i)), maxDist);

                if opt.w_occ
                    % match1_all(:,:,i) = match1_all(:,:,i)+match1;
                    % reserver the edge that also correct with directions
                    [match1_occ, match2_occ] = correspondOccPixels(match1, ...,
                    occ, gt_occ(:, :, i));
                end

                gt(:, :, i) = gt(:, :, i) .*~match2;
                % compute recall
                cntR(t) = cntR(t) + sum(match2(:) > 0);
                accP = accP | match1;

                if opt.w_occ
                    gt_occ(:, :, i) = gt_occ(:, :, i) .*~match2;
                    cntR_occ(t) = cntR_occ(t) + sum(match2_occ(:) > 0);
                    accP_occ = accP_occ | match1_occ;
                end

            end

            if opt.w_occ
                cntP_occ(t) = cntP_occ(t) + sum(accP_occ(:));
            end

            % compute precision
            sumP(t) = sumP(t) + sum(bmap(:));
            cntP(t) = cntP(t) + sum(accP(:));
        end

    else
        
        % should start from 51, will save half time?
        for t = 51:nthresh % 51:nthresh  % nthresh:-1:1
            % fprintf('%d\n', t);
            bmap = double(pb >= max(eps, thresh(t)));
            Z = zeros(size(pb)); matchE = Z; matchG = Z; allG = Z;
            if opt.w_occ; matchO = Z; matchGO = Z; end
            n = size(gt, 3);

            for i = 1:n,
                [match1, match2] = correspondPixels(bmap, double(gt(:, :, i)), maxDist);

                if opt.w_occ
                    [match1_occ, match2_occ] = correspondOccPixels(match1, ...,
                    occ, gt_occ(:, :, i));

                    % bins
                    % tmp_len = 2 * pi / bins_num;

                    % for j = 1:bins_num
                    %     tmp_occ = gt_occ(:, :, i);
                    %     tmp_occ(tmp_occ < -pi) = -pi;
                    %     tmp_occ(tmp_occ > pi) = pi;
                    %     tmp_l = -pi + (j - 1) * tmp_len;
                    %     tmp_r = -pi + j * tmp_len;
                    %     tmp_ind = tmp_occ >= tmp_l & tmp_occ < tmp_r & match2 > 0;
                    %     tmp_match = (match2_occ > 0) & tmp_ind;

                    %     bins_cntR(j, t) = sum(tmp_ind(:));
                    %     bins_cntR_occ(j, t) = sum(tmp_match(:));

                    %     tmp_ind = tmp_occ >= tmp_l & tmp_occ < tmp_r & match1 > 0;
                    %     tmp_match = (match1_occ > 0) & tmp_ind;
                    %     bins_cntP(j, t) = bins_cntR(j, t);
                    %     bins_cntP_occ(j, t) = bins_cntR_occ(j, t);
                    % end
                    [bin_cntR, bin_cntR_occ] = correspondOccPixelsBins(match1, occ, gt_occ(:, :, i));

                    bins_cntR(:, t) = bin_cntR(:);
                    bins_cntP(:, t) = bin_cntR(:);
                    bins_cntR_occ(:, t) = bin_cntR_occ(:);
                    bins_cntP_occ(:, t) = bin_cntR_occ(:);

                    matchO = matchO | match1_occ > 0;
                    matchGO = matchGO + double(match2_occ > 0);
                end

                matchE = matchE | match1 > 0;
                matchG = matchG + double(match2 > 0);
                allG = allG + gt(:, :, i);
            end

            if opt.w_occ
                cntP_occ(t) = nnz(matchO(:));
                cntR_occ(t) = sum(matchGO(:));
            end

            sumP(t) = nnz(bmap);
            cntP(t) = nnz(matchE);
            cntR(t) = sum(matchG(:));

            % optinally create visualization of matches
            if (nargout < 6), continue; end
            cs = [1 0 0; 0 .7 0; .7 .8 1]; cs = cs - 1;
            FP = bmap - matchE; TP = matchE; FN = (allG - matchG) / n;
            for g = 1:3, VB(:, :, g, t) = max(0, 1 + FN * cs(1, g) + TP * cs(2, g) + FP * cs(3, g)); end
            VB(:, 2:end, :, t) = min(VB(:, 2:end, :, t), VB(:, 1:end - 1, :, t));
            VB(2:end, :, :, t) = min(VB(2:end, :, :, t), VB(1:end - 1, :, :, t));

            if (nargout < 7), continue; end
            % FN1 are false negative boundaries
            % FN2 are correctly labeled boundaries but incorrect occlusion
            FP = bmap - matchO; TP = matchO;
            FN1 = (allG - matchG) / n - (matchE - matchO);
            FN2 = matchE - matchO;
            VO(:, :, 1, t) = TP; VO(:, :, 2, t) = FP; VO(:, :, 3, t) = FN1; VO(:, :, 4, t) = FN2;
        end

    end

    tmp_len = 2 * pi / bins_num;

    for j = 1:bins_num
        tmp_occ = gt_occ(:, :, 1);
        tmp_occ(tmp_occ < -pi) = -pi;
        tmp_occ(tmp_occ > pi) = pi;
        tmp_l = -pi + (j - 1) * tmp_len;
        tmp_r = -pi + j * tmp_len;
        tmp_ind = tmp_occ >= tmp_l & tmp_occ < tmp_r & gt(:, :, 1) > 0;

        bins_sumR(j, :) = sum(tmp_ind(:));
        % disp(size(bins_sumR(j, :)));
        % disp(size(sumR));
        % disp(size(sumP));
        bins_sumP(j, :) = ceil(bins_sumR(j, :) / sumR' * sumP');
    end

    % output
    fid = fopen(prFile, 'w');

    if fid == -1
        error('Could not open file %s for writing.', prFile);
    end

    if opt.w_occ
        fprintf(fid, '%10g %10g %10g %10g %10g %10g %10g\n', [thresh cntR sumR cntP sumP, cntR_occ, cntP_occ]');
    else
        fprintf(fid, '%10g %10g %10g %10g %10g\n', [thresh cntR sumR cntP sumP]');
    end

    fclose(fid);

    % disp(occ_bins);

    tmp_ind = bins_sumP < bins_cntP;
    bins_sumP(tmp_ind) = bins_cntP(tmp_ind) + 1;
    for j = 1:bins_num
        occ_bins_file = sprintf("%s.%d_%d_bins.txt", prFile, bins_num, j);
        occ_bins_fid = fopen(occ_bins_file, 'w');
        fprintf(occ_bins_fid, '%10g %10g %10g %10g %10g %10g %10g\n', [thresh bins_cntR(j, :)' bins_sumR(j, :)' bins_cntP(j, :)' bins_sumP(j, :)', bins_cntR_occ(j, :)', bins_cntP_occ(j, :)']');
        fclose(occ_bins_fid);
    end

    % occ_bins_file = [prFile, '.occbins.txt'];
    % occ_bins_fid = fopen(occ_bins_file, 'w');
    % fprintf(occ_bins_fid, '%10g %10g\n', occ_bins');
    % fclose(occ_bins_fid);

    % bins_file = [prFile, '.edgebins.txt'];
    % bins_fid = fopen(bins_file, 'w');
    % fprintf(bins_fid, '%10g %10g\n', edge_bins');
    % fclose(bins_fid);
    clear all;
end
