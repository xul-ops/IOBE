 v% script to do edge detection nms 
dataset = 'nyuv2';
res_root_dir = '/home/lintao/Documents/projects/OCC/occdata/other_compare/opnet_res/nyu_noretrain';
addpath(genpath('/home/lintao/Documents/projects/OCC/evaTools/doobscripts'));

switch dataset
    case 'ibims'
        testIdsFilename = fullfile(pwd, '..', '..', '/data/dataset_real/ibims/test_ori_iids.txt');
    case 'nyuv2'
        testIdsFilename = '/home/lintao/Documents/projects/OCC/occdata/NYUv2-OCpp/test.txt';
    case 'DenseDepthNYUDv2'
        testIdsFilename = fullfile(pwd, '..', '..', '/data/DenseDepthNYUDv2/data/test_iids_DenseDepthNYUDv2Train.txt');
end

ImageList = textread(testIdsFilename, '%s');

for ires = 1:length(ImageList)
        prob_in_path  = fullfile(res_root_dir, [ImageList{ires}, '_ob.png']);  
        prob_out_path = fullfile(res_root_dir, [ImageList{ires}, '_ob_nms.png']);  
        
        if ~exist(prob_in_path, 'file')
            disp(prob_in_path);         
        else
        % disp(prob_in_path)   
     
            % read imgs
            edge_prob = imread(prob_in_path);  % uint8
            edge_prob = single(edge_prob) / 255;  % [0~1]
        
            % do nms
            edge_prob_thin = edge_nms(edge_prob, 0);
        
            % output imgs
            edge_prob_thin = cast(edge_prob_thin * 255., 'uint8');
            imwrite(edge_prob_thin, prob_out_path);
        end
end


